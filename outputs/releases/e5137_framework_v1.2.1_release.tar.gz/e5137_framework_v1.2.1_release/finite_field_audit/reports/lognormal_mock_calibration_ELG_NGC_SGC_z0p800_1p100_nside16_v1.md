# Clustered lognormal mock calibration

- Map: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz`
- Mock family: angular lognormal field plus Poisson sampling
- Mocks per sigma: 1000
- Sigma values: auto=0.0427448, 0.08=0.08, 0.12=0.12
- Smoothing scale: 8 deg
- Power-spectrum slope: 1.4
- lmax: 47
- External templates regressed: 11

These mocks preserve the angular selection function encoded by the DESI
random-count map and add correlated angular density structure before
Poisson sampling. They are meant to reduce the overconfidence of
shot-noise-only p-values.

They are not official DESI mocks and do not encode the full DESI
selection, radial evolution, reconstruction, fiber assignment, or survey
covariance model.

## Summary

| mock_family       | map_path                                                                                                                                             | sigma_label   |   sigma_lognormal |   smoothing_deg |   cl_slope |   lmax | stage                              |   n_mocks |   n_templates |   null_amplitude_median |   null_amplitude_p68 |   null_amplitude_p95 |   null_amplitude_p99 |   observed_amplitude |   observed_ra_deg |   observed_dec_deg |   observed_empirical_p_value |
|:------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------|:--------------|------------------:|----------------:|-----------:|-------:|:-----------------------------------|----------:|--------------:|------------------------:|---------------------:|---------------------:|---------------------:|---------------------:|------------------:|-------------------:|-----------------------------:|
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | 0.08          |         0.08      |               8 |        1.4 |     47 | after_external_template_regression |      1000 |            11 |               0.0344158 |            0.0435621 |            0.0751904 |            0.0867019 |            0.0229974 |           222.055 |           -71.6975 |                     0.756244 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | 0.08          |         0.08      |               8 |        1.4 |     47 | raw_no_template_regression         |      1000 |            11 |               0.0786933 |            0.0919946 |            0.138338  |            0.163286  |            0.0326834 |           204.166 |           -72.2818 |                     0.949051 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | 0.12          |         0.12      |               8 |        1.4 |     47 | after_external_template_regression |      1000 |            11 |               0.0498793 |            0.0648382 |            0.110937  |            0.133165  |            0.0229974 |           222.055 |           -71.6975 |                     0.917083 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | 0.12          |         0.12      |               8 |        1.4 |     47 | raw_no_template_regression         |      1000 |            11 |               0.114835  |            0.133252  |            0.190098  |            0.229743  |            0.0326834 |           204.166 |           -72.2818 |                     0.99001  |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | auto          |         0.0427448 |               8 |        1.4 |     47 | after_external_template_regression |      1000 |            11 |               0.0181492 |            0.0231478 |            0.0383748 |            0.0466062 |            0.0229974 |           222.055 |           -71.6975 |                     0.325674 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz | auto          |         0.0427448 |               8 |        1.4 |     47 | raw_no_template_regression         |      1000 |            11 |               0.0421121 |            0.0497506 |            0.0737363 |            0.0906539 |            0.0326834 |           204.166 |           -72.2818 |                     0.732268 |

## Interpretation

- Compare these p-values with the earlier Poisson-only calibration; a large
increase means the old null was too narrow.
- If a signal remains unusual over a plausible sigma grid, the next step is
official DESI-like mocks or a tuned 3D lognormal/mock-catalog generator.
- Template-regressed rows should be read together with injection-recovery
tests, because template regression can suppress real dipole power.
