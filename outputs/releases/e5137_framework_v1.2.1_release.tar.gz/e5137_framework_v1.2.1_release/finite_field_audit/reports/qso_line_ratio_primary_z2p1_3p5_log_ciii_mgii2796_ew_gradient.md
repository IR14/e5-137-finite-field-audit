# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 186114
- finite residual rows: 186114
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0122458
- axis RA: 109.881 deg
- axis DEC: 27.207 deg
- fitted pixels: 968
- block-null p-value: 0.9800399201596807
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    366554 |           7141 |                             173299 |                          0 |    186114 |      180440 | LOG_CIII_MGII2796_EW |       -4.04109 |        10.6895 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.147593    |
| z                     |   1.04423     |
| z2                    |  -1.14203     |
| LOGMSTAR              |   0.0972878   |
| RCHI2_LINE            |  -0.017022    |
| DELTA_LINECHI2        |   0.00162848  |
| FLUX_SYNTH_G          |  -0.000891559 |
| FLUX_SYNTH_R          |   0.0324211   |
| FLUX_SYNTH_Z          |  -0.0423506   |
| FLUX_G                |   0.0684186   |
| FLUX_R                |  -0.0497653   |
| FLUX_Z                |  -0.0403041   |
| FLUX_W1               |   0.0963053   |
| FLUX_W2               |  -0.0600672   |
| template_0_ebv        |   0.00789611  |
| template_1_stardens   |  -0.00425475  |
| template_2_galdepth_g |  -0.00504884  |
| template_3_galdepth_r |  -0.014843    |
| template_4_galdepth_z |   0.00563394  |
| template_5_psfsize_g  |  -0.0119877   |
| template_6_psfsize_r  |   0.00736478  |
| template_7_psfsize_z  |  -0.000638562 |
| template_8_cosky_g    |   0.00260074  |
| template_9_cosky_r    |   0.00197282  |
| template_10_cosky_z   |  -0.00774458  |

## Figures

- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
