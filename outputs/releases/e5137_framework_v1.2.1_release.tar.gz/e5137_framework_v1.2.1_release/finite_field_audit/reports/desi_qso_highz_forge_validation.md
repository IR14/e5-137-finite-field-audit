# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/QSO_NGC_clustering.dat.fits`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 1
- redshift range: `1.5` to `3.5`

## Sample

- joined rows on TARGETID: 90
- finite residual rows: 90
- observable: `DN4000_MODEL`
- controls: `z; z2; LOGMSTAR`

## Dipole Fit

- amplitude: 0.0553802
- axis RA: 169.875 deg
- axis DEC: 2.241 deg
- fitted pixels: 73
- block-null p-value: 0.7744510978043913
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_rchi2_cont |   n_fail_deltachi2 |   n_fail_dn4000_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------:|-------------------:|---------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    518736 |          13116 |               49002 |              14979 |               441549 |                          0 |        90 |      518646 | DN4000_MODEL        |        1.07577 |        1.43954 |

## Residual Model Coefficients

| term      |   coefficient |
|:----------|--------------:|
| intercept |     1.15597   |
| z         |    -0.127919  |
| z2        |     0.129868  |
| LOGMSTAR  |     0.0233413 |

## Figures

- `outputs/figures/desi_qso_highz_forge_validation_residual_vs_z.png`
- `outputs/figures/desi_qso_highz_forge_validation_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
