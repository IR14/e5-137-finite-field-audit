# e-5-137 Empirical Hold Protocol

Дата фиксации: 2026-05-27

Статус: теоретический поиск по модели e-5-137 остановлен. Дальнейший подбор аналитических выражений, знаков после запятой и новых компенсирующих операторов запрещен до появления новой независимой наблюдательной проверки.

## 1. Назначение документа

Этот протокол фиксирует модель e-5-137 как закрытый исследовательский ansatz и переводит дальнейшую работу из режима symbolic/grid-search в режим наблюдательной астрофизики.

Важно: данный документ не утверждает, что модель является доказанной физической теорией. Он фиксирует внутренне согласованный набор проверенных численных операторов и задает строгий следующий эмпирический тест на публичных данных DESI.

## 2. Замороженный базис

Разрешенные базовые константы и операторы:

- `N = 5`
- `D = 26`
- `F_26 = 121393`
- простой базис `P = {2, 3, 5, 13, 137}`
- `alpha`, `alpha^-1`
- `s = alpha / (2*pi)`
- `q = N(N - 2) / (e^4*pi^3)`
- `T5 = 2 / (eN)`
- `delta_phi = cos(1/N) - cos(2/N)`
- цифровой каскад `137_e`, только в уже зафиксированных местах

Запрещено:

- вводить новые свободные численные параметры;
- подбирать гладкие дроби задним числом;
- менять уже замороженные операторы для улучшения ppm;
- объявлять численные совпадения физическим доказательством без независимой наблюдательной проверки.

## 3. Замороженные сектора

Лептонный сектор:

```text
C_e = 1 / [1 - s(N + T5 - q/(3D))]
a_e = s [1 - s(pi/e + T5)]
m_mu / m_e = alpha^-1 [3/2 + q]
m_tau / m_e = alpha^-1 [N^2 + q f_tau]
```

где:

```text
f_tau = I5 + d_-2 e^-2 + d_-7 e^-7
I5 = sum_{k=1..5} k^2 d_-k = 42
```

Барионный и мезонный сектор:

```text
Delta_n = (F_26 / alpha^-1) * 10 e^5 cos(1/N) * [1 + (pi + delta_phi)s]
A_N = N delta_phi (1 - Ns)
mu_p = N/2 + A_N
mu_n = -[N/2 - 2A_N]
m_pi0 / m_e = alpha^-1 [2 - delta_phi - q(1 + 1/N + 1/pi)]
```

Планковский энтропийный слой:

```text
ln(M_Pl / m_e) = DN - N^2*pi + 5N^3 q/(pi D) - pi T5/(D N^3)
```

Космологический слой DESI w0-wa:

```text
w0 = -1 + T5/N + Dq - delta_phi/N
wa = -N delta_phi * (pi + s - Dq + q/pi)
```

## 4. Эмпирический hold

Единственный разрешенный следующий шаг: проверка пространственного и redshift-зависимого градиента на реальных наблюдательных данных DESI.

Научная нулевая гипотеза:

```text
H0: после учета survey mask, random catalogs, selection function,
foreground/systematics templates и galaxy population covariates
остаточные дипольные/градиентные сигналы совместимы с изотропной ΛCDM.
```

Альтернативная гипотеза:

```text
H1: существует устойчивый directional residual, связанный с redshift,
tracer class и population proxies, который не объясняется survey geometry,
stellar contamination, dust/extinction, depth, seeing, target selection,
stellar mass или обычной эволюцией галактик.
```

## 5. DESI/FastSpecFit проверка

Минимальные входные данные:

- DESI LSS clustering catalogs для LRG/ELG/QSO/BGS;
- соответствующие DESI random catalogs;
- DESI FastSpecFit VAC для галактик;
- систематические HEALPix templates: dust/extinction, stellar density, depth, seeing, sky brightness;
- при возможности DESI DR2 BAO/cosmology likelihood summaries.

Ключевые observables:

- `RA`, `DEC`, `Z`
- tracer class
- weights
- `Dn4000`
- stellar mass proxy
- stellar age proxy
- emission-line metallicity proxy, если доступен и калиброван
- redshift bins
- sky-region jackknife labels

Обязательные регрессоры контроля:

- survey mask / random density
- target selection
- imaging depth
- seeing
- sky brightness
- Galactic dust/extinction
- stellar density
- redshift
- stellar mass
- galaxy type / color / SFR proxy

## 6. Протокол анализа

1. Построить weighted overdensity maps по tracer и redshift bins.
2. Построить population maps: `Dn4000`, metallicity proxy, stellar mass proxy.
3. Удалить survey/systematics modes через регрессию по external templates.
4. Оценить residual dipole/axis по density и population residuals.
5. Проверить cross-tracer consistency: LRG, ELG, BGS, QSO.
6. Проверить stability по redshift bins.
7. Проверить связь residual axis с `Dn4000`/metallicity после контроля stellar mass и redshift.
8. Сравнить с official mocks / EZmock ensemble под той же mask/selection.
9. Отдельно проверить, не является ли сигнал продуктом footprint, targeting или foregrounds.

## 7. Критерии разморозки модели

Теоретический поиск может быть возобновлен только если выполнены все условия:

- обнаружен residual directional signal с mock-calibrated p-value ниже заранее заданного порога;
- сигнал устойчив между независимыми tracer-классами или имеет физически объяснимую tracer-зависимость;
- сигнал сохраняется после контроля `Dn4000`, stellar mass, redshift и survey systematics;
- результат воспроизводится на независимом data release или внешнем обзоре;
- до анализа зафиксирован blinded protocol и frozen estimator.

Если эти условия не выполнены, модель остается в standby, а все новые формулы считаются запрещенными.

## 8. Финальная фиксация

Код и аналитический ansatz запечатаны. Дальнейшая работа должна быть только наблюдательной, воспроизводимой и falsification-first.

Следующий допустимый артефакт:

```text
outputs/reports/desi_fastspecfit_gradient_validation.md
```

Он должен содержать реальные результаты DESI/FastSpecFit проверки, а не новые аналитические совпадения.
