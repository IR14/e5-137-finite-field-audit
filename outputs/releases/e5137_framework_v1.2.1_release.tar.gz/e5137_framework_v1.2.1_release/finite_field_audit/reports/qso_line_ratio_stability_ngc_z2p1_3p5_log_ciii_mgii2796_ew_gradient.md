# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 121305
- finite residual rows: 121305
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0103131
- axis RA: 48.428 deg
- axis DEC: -42.053 deg
- fitted pixels: 619
- block-null p-value: 0.998003992015968
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    237300 |           4268 |                             111727 |                          0 |    121305 |      115995 | LOG_CIII_MGII2796_EW |       -3.96086 |        10.6647 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.144857    |
| z                     |   0.964141    |
| z2                    |  -1.059       |
| LOGMSTAR              |   0.0967214   |
| RCHI2_LINE            |  -0.01889     |
| DELTA_LINECHI2        |   0.00217379  |
| FLUX_SYNTH_G          |  -0.0169025   |
| FLUX_SYNTH_R          |   0.0410592   |
| FLUX_SYNTH_Z          |  -0.0246069   |
| FLUX_G                |   0.0771224   |
| FLUX_R                |  -0.0349387   |
| FLUX_Z                |  -0.0770452   |
| FLUX_W1               |   0.112296    |
| FLUX_W2               |  -0.0702272   |
| template_0_ebv        |   0.0136578   |
| template_1_stardens   |  -0.00687075  |
| template_2_galdepth_g |  -0.0110547   |
| template_3_galdepth_r |  -0.0156088   |
| template_4_galdepth_z |   0.00294682  |
| template_5_psfsize_g  |  -0.0101146   |
| template_6_psfsize_r  |   0.00846508  |
| template_7_psfsize_z  |  -0.00209486  |
| template_8_cosky_g    |   0.000319381 |
| template_9_cosky_r    |  -0.00660768  |
| template_10_cosky_z   |  -0.0182481   |

## Figures

- `outputs/figures/qso_line_ratio_stability_ngc_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_ngc_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
