# Toshiba DESI Data Disk Setup

Дата: 2026-05-27

## Summary

Внешний Toshiba-диск был явно разрешен к форматированию пользователем. Старый том `TOSHIBA EXT` был `NTFS` и монтировался macOS только в режиме read-only. Диск отформатирован и настроен как рабочий data-диск для DESI.

## Disk

- Старое имя тома: `TOSHIBA EXT`
- Старый формат: `NTFS`, read-only на macOS
- Физический диск перед форматированием: `/dev/disk6`
- Новый том: `DESI_DATA`
- Новый mount point: `/Volumes/DESI_DATA`
- Новый формат: `APFS`
- Размер: около `2.0 TB`
- Свободно после переноса FastSpecFit: около `1.8 TiB`

## Directory Layout

Создан root:

`/Volumes/DESI_DATA/cosmo_genesis_gradient`

Поддиректории:

- `/Volumes/DESI_DATA/cosmo_genesis_gradient/raw`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/raw/desi_lss`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/raw/mocks`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/raw/vac`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/interim`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/processed`
- `/Volumes/DESI_DATA/cosmo_genesis_gradient/logs`

В репозитории создан удобный symlink:

`/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/DESI_DATA`

который указывает на:

`/Volumes/DESI_DATA/cosmo_genesis_gradient`

## Moved Data

Тяжелый FastSpecFit VAC перенесен с внутреннего диска на Toshiba:

`/Volumes/DESI_DATA/cosmo_genesis_gradient/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`

Размер:

`41340179520` байт

Проверка FITS после переноса:

- `nhdu = 3`
- HDU 1: `FASTSPEC`, `10075557` строк, `907` колонок
- HDU 2: `METADATA`, `10075557` строк, `52` колонки

Старый проектный путь сохранен как symlink, поэтому существующие команды продолжают работать:

`/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`

указывает на:

`/Volumes/DESI_DATA/cosmo_genesis_gradient/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`

## Space After Setup

После удаления внутренней копии FastSpecFit:

- внутренний диск: около `59 GiB` свободно;
- `DESI_DATA`: около `1.8 TiB` свободно;
- `T7 Shield`: около `24 GiB` свободно.

## Operational Notes

- Для новых больших DESI/VAC/mock загрузок использовать `/Volumes/DESI_DATA/cosmo_genesis_gradient/raw`.
- Результаты, манифесты и отчеты продолжать писать в репозиторий `outputs/`.
- Если диск не подключен, старый проектный FastSpecFit path будет broken symlink до повторного подключения `DESI_DATA`.

