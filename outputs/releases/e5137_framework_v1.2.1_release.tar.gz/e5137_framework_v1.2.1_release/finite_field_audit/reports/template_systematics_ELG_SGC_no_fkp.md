# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |             2 |               0.737905 |        0.259506 |         0.00019996 |                 0.394521 |             0.0928712 |                0.0215957 |                      0.285943  |                           0.357877 |                           42.6017 |
| ELG      | SGC      |     1.1 |     1.4 |             2 |               0.69619  |        0.25312  |         0.00019996 |                 0.379324 |             0.0853573 |                0.0835833 |                      0.0323935 |                           0.337221 |                           26.9164 |
| ELG      | SGC      |     1.4 |     1.6 |             2 |               0.583084 |        0.191981 |         0.00459908 |                 0.393521 |             0.0424471 |                0.623675  |                      0.363327  |                           0.221101 |                           88.829  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term             |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------|--------------:|
| ELG      | SGC      |     0.8 |     1.1 | intercept        |  -0.0683989   |
| ELG      | SGC      |     0.8 |     1.1 | ntile            |   0.0148408   |
| ELG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles |   0.148722    |
| ELG      | SGC      |     1.1 |     1.4 | intercept        |  -0.0629209   |
| ELG      | SGC      |     1.1 |     1.4 | ntile            |  -0.000792784 |
| ELG      | SGC      |     1.1 |     1.4 | frac_tlobs_tiles |   0.1512      |
| ELG      | SGC      |     1.4 |     1.6 | intercept        |  -0.0683848   |
| ELG      | SGC      |     1.4 |     1.6 | ntile            |  -0.00924857  |
| ELG      | SGC      |     1.4 |     1.6 | frac_tlobs_tiles |   0.174353    |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
