# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |    ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|----------:|----------:|---------------:|
| LRG      | NGC      |     0.4 |     0.6 |   346761 |    6662611 |  0.0513137  |      0.0294396  |   2.33214 | -28.2682  |       0.363636 |
| LRG      | NGC      |     0.6 |     0.8 |   533955 |   10177952 |  0.0230061  |      0.0169438  | 343.337   | -23.2525  |       0.834711 |
| LRG      | NGC      |     0.8 |     1.1 |   595419 |   11312817 |  0.0194531  |      0.0162957  | 237.339   | -32.1874  |       0.842975 |
| LRG      | SGC      |     0.4 |     0.6 |   160150 |    3535898 |  0.060209   |      0.0284931  |  51.0768  |  15.3623  |       0.793388 |
| LRG      | SGC      |     0.6 |     0.8 |   237939 |    5355083 |  0.0407265  |      0.0231733  | 121.121   |  71.6416  |       0.818182 |
| LRG      | SGC      |     0.8 |     1.1 |   264403 |    5986866 |  0.0505661  |      0.0288067  | 186.089   |   1.03496 |       0.619835 |
| ELG      | NGC      |     0.8 |     1.1 |   766482 |   12306203 |  0.0381955  |      0.0103894  | 189.811   | -12.0654  |       0.413223 |
| ELG      | NGC      |     1.1 |     1.4 |   715801 |   11438144 |  0.0239074  |      0.00796606 | 196.254   | -30.2895  |       0.826446 |
| ELG      | NGC      |     1.4 |     1.6 |   339039 |    5404849 |  0.0193079  |      0.0115847  | 180.226   | -21.5656  |       0.958678 |
| ELG      | SGC      |     0.8 |     1.1 |   249883 |    6305110 |  0.088494   |      0.020122   | 206.398   | -52.8443  |       0.231405 |
| ELG      | SGC      |     1.1 |     1.4 |   242543 |    6047145 |  0.0706358  |      0.0193084  | 195.912   | -35.9585  |       0.380165 |
| ELG      | SGC      |     1.4 |     1.6 |   118324 |    2917069 |  0.0700485  |      0.0312731  |  34.7434  | -37.3782  |       0.595041 |
| QSO      | NGC      |     0.8 |     1.2 |   133606 |    5856626 |  0.0174644  |      0.0132874  | 308.404   |  80.7997  |       0.942149 |
| QSO      | NGC      |     1.2 |     1.6 |   191793 |    8427479 |  0.00657563 |      0.0117732  | 118.738   |  72.2174  |       0.983471 |
| QSO      | NGC      |     1.6 |     2.1 |   230514 |   10120517 |  0.0115775  |      0.00849684 |  12.6628  |  42.595   |       0.975207 |
| QSO      | NGC      |     2.1 |     3.5 |   237306 |   10420346 |  0.0086556  |      0.00766498 | 357.296   |  18.8382  |       0.991736 |
| QSO      | SGC      |     0.8 |     1.2 |    72742 |    3305720 |  0.0199022  |      0.0256364  |  12.1528  |  20.7273  |       0.942149 |
| QSO      | SGC      |     1.2 |     1.6 |   104480 |    4735179 |  0.0486276  |      0.0293492  |  15.8626  | -17.3363  |       0.859504 |
| QSO      | SGC      |     1.6 |     2.1 |   123696 |    5625568 |  0.0230447  |      0.0165402  | 189.55    | -31.4208  |       0.975207 |
| QSO      | SGC      |     2.1 |     3.5 |   129254 |    5871303 |  0.0162607  |      0.0127009  | 262.334   |  -4.06751 |       0.991736 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| LRG 0.400-0.600 | LRG 0.600-0.800 |          17.8046 |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         100.089  |
| LRG 0.400-0.600 | LRG 0.400-0.600 |          64.2429 |
| LRG 0.400-0.600 | LRG 0.600-0.800 |         125.668  |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         152.531  |
| LRG 0.400-0.600 | ELG 0.800-1.100 |         139.022  |
| LRG 0.400-0.600 | ELG 1.100-1.400 |         119.954  |
| LRG 0.400-0.600 | ELG 1.400-1.600 |         130.125  |
| LRG 0.400-0.600 | ELG 0.800-1.100 |          96.2149 |
| LRG 0.400-0.600 | ELG 1.100-1.400 |         114.512  |
| LRG 0.400-0.600 | ELG 1.400-1.600 |          28.5547 |
| LRG 0.400-0.600 | QSO 0.800-1.200 |         112.618  |
| LRG 0.400-0.600 | QSO 1.200-1.600 |         124.792  |
| LRG 0.400-0.600 | QSO 1.600-2.100 |          71.4995 |
| LRG 0.400-0.600 | QSO 2.100-3.500 |          47.3575 |
| LRG 0.400-0.600 | QSO 0.800-1.200 |          49.9057 |
| LRG 0.400-0.600 | QSO 1.200-1.600 |          16.5605 |
| LRG 0.400-0.600 | QSO 1.600-2.100 |         119.916  |
| LRG 0.400-0.600 | QSO 2.100-3.500 |          96.8309 |
| LRG 0.600-0.800 | LRG 0.800-1.100 |          90.2292 |
| LRG 0.600-0.800 | LRG 0.400-0.600 |          76.6431 |
| LRG 0.600-0.800 | LRG 0.600-0.800 |         126.087  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |         148.68   |
| LRG 0.600-0.800 | ELG 0.800-1.100 |         136.198  |
| LRG 0.600-0.800 | ELG 1.100-1.400 |         117.831  |
| LRG 0.600-0.800 | ELG 1.400-1.600 |         132.26   |
| LRG 0.600-0.800 | ELG 0.800-1.100 |          95.2097 |
| LRG 0.600-0.800 | ELG 1.100-1.400 |         113.259  |
| LRG 0.600-0.800 | ELG 1.400-1.600 |          45.9656 |
| LRG 0.600-0.800 | QSO 0.800-1.200 |         105.621  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
