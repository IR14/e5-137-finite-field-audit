# e-5-137 GF(137) hash-archive shootout

Status: Phase 10 semantic hash-archive benchmark. This is a lossy
GF(137) super-vector archive, not a Huffman/LZMA-style reversible text
compressor. The repair test restores the archived super-vectors after
axis erasure; it does not reconstruct arbitrary original prose from the
hash alone.

## Kernel

- C++ source: `src/modular_compression/e5137_extractor.cpp`
- Python binding: `src/cosmo_gradient/modular_compression.py`
- Scenario runner: `scripts/e5137_compressor_shootout.py`
- GF modulus: 137
- axes: 26
- subparticles per axis: 5
- super-vector bytes: 130
- nominal token window: 1500
- book-scale semantic cap: 117 super-vectors

## Size shootout

| scenario   |   tokens |   original_bytes |   supervectors |   archive_bytes |   compression_ratio |   erased_axes |   min_repair_votes | majority_repair_ok   |
|:-----------|---------:|-----------------:|---------------:|----------------:|--------------------:|--------------:|-------------------:|:---------------------|
| A          |      150 |              954 |              1 |             130 |             7.33846 |            10 |                 16 | True                 |
| B          |     1500 |             9571 |              1 |             130 |            73.6231  |            10 |                 16 | True                 |
| C          |   120000 |           765648 |            117 |           15210 |            50.3385  |            10 |                 16 | True                 |

## Book-scale invariant

Scenario C is forced through the archived semantic limit:

```text
tokens = 120000
supervectors = 117
archive_bytes = 15210
expected = 117 * 130 = 15210 bytes
compression_ratio = 50.3385
```

## Repair audit

Ten of twenty-six axes are erased in every archived super-vector. The
kernel reconstructs the erased axes by reducing each surviving axis back
to its five core GF(137) subparticle residues and applying majority
repair. With 10 erased axes, 16 axes remain, so the minimum successful
vote count is expected to be 16.

All three scenarios restore the archived super-vector exactly after
axis erasure. No lossless text restoration claim is made.

## Guardrail

The byte-ratio table is a hash-archive ratio. It is useful for fixed-size
semantic fingerprints, deduplicated archive catalogs, and fault-tolerant
context signatures. It is not a universal compressor for arbitrary text
unless an external generative dictionary or source model is also supplied.
