# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 265126
- finite residual rows: 265126
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00404704
- axis RA: 120.893 deg
- axis DEC: -47.111 deg
- fitted pixels: 633
- block-null p-value: 0.9960079840319361
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    281436 |           8848 |                              7462 |                          0 |    265126 |       16310 | LOG_CIV_MGII2796_EW |       -2.46825 |        8.79858 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.07414     |
| z                     |  -0.861136    |
| z2                    |   0.797309    |
| LOGMSTAR              |  -0.0642449   |
| RCHI2_LINE            |  -0.000211129 |
| DELTA_LINECHI2        |  -0.00386536  |
| FLUX_SYNTH_G          |   0.0576823   |
| FLUX_SYNTH_R          |  -0.19773     |
| FLUX_SYNTH_Z          |   0.113585    |
| FLUX_G                |   0.031898    |
| FLUX_R                |  -0.0378547   |
| FLUX_Z                |   0.0710961   |
| FLUX_W1               |  -0.011738    |
| FLUX_W2               |  -0.0141888   |
| template_0_ebv        |   0.00506017  |
| template_1_stardens   |   0.00647325  |
| template_2_galdepth_g |  -0.0026926   |
| template_3_galdepth_r |  -0.00436556  |
| template_4_galdepth_z |  -0.000702221 |
| template_5_psfsize_g  |   0.00324468  |
| template_6_psfsize_r  |  -0.00756994  |
| template_7_psfsize_z  |   0.00501858  |
| template_8_cosky_g    |  -0.010924    |
| template_9_cosky_r    |  -0.00602227  |
| template_10_cosky_z   |   0.0172927   |

## Figures

- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
