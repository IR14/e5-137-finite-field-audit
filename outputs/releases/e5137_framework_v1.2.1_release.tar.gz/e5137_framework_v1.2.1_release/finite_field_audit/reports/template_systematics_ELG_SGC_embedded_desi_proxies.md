# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |             8 |              0.0356635 |       0.0887852 |           0.29774  |                 0.277861 |             0.0738997 |                 0.45151  |                      0.464768  |                           0.832343 |                           6.87488 |
| ELG      | SGC      |     1.1 |     1.4 |             8 |              0.0456286 |       0.0729452 |           0.386123 |                 0.015992 |             0.0637993 |                 0.487702 |                      0.0649675 |                           0.874619 |                           2.47376 |
| ELG      | SGC      |     1.4 |     1.6 |             8 |              0.0343356 |       0.0627376 |           0.586683 |                 0.134433 |             0.0544384 |                 0.688062 |                      0.287356  |                           0.867716 |                          25.8092  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term             |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------|--------------:|
| ELG      | SGC      |     0.8 |     1.1 | intercept        |  -5.02929e-05 |
| ELG      | SGC      |     0.8 |     1.1 | ntile            |  -0.232667    |
| ELG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles |  -0.00361479  |
| ELG      | SGC      |     0.8 |     1.1 | nx               |   0.237858    |
| ELG      | SGC      |     0.8 |     1.1 | weight_sys       |   0.0071254   |
| ELG      | SGC      |     0.8 |     1.1 | weight_sn        |   0.0071254   |
| ELG      | SGC      |     0.8 |     1.1 | weight_rf        |  -0.00201543  |
| ELG      | SGC      |     0.8 |     1.1 | weight_zfail     |  -0.015078    |
| ELG      | SGC      |     0.8 |     1.1 | weight_comp      |  -0.00181061  |
| ELG      | SGC      |     1.1 |     1.4 | intercept        |   0.00673454  |
| ELG      | SGC      |     1.1 |     1.4 | ntile            |  -0.307668    |
| ELG      | SGC      |     1.1 |     1.4 | frac_tlobs_tiles |  -0.0104942   |
| ELG      | SGC      |     1.1 |     1.4 | nx               |   0.30903     |
| ELG      | SGC      |     1.1 |     1.4 | weight_sys       |   0.00325875  |
| ELG      | SGC      |     1.1 |     1.4 | weight_sn        |   0.00325875  |
| ELG      | SGC      |     1.1 |     1.4 | weight_rf        |  -0.00451383  |
| ELG      | SGC      |     1.1 |     1.4 | weight_zfail     |  -0.0192343   |
| ELG      | SGC      |     1.1 |     1.4 | weight_comp      |  -0.00820475  |
| ELG      | SGC      |     1.4 |     1.6 | intercept        |  -0.00227964  |
| ELG      | SGC      |     1.4 |     1.6 | ntile            |  -0.408687    |
| ELG      | SGC      |     1.4 |     1.6 | frac_tlobs_tiles |   0.0601783   |
| ELG      | SGC      |     1.4 |     1.6 | nx               |   0.352309    |
| ELG      | SGC      |     1.4 |     1.6 | weight_sys       |  -0.00148862  |
| ELG      | SGC      |     1.4 |     1.6 | weight_sn        |  -0.00148862  |
| ELG      | SGC      |     1.4 |     1.6 | weight_rf        |   0.00304417  |
| ELG      | SGC      |     1.4 |     1.6 | weight_zfail     |   0.00438852  |
| ELG      | SGC      |     1.4 |     1.6 | weight_comp      |  -0.0166642   |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
