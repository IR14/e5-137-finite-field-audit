# Look-elsewhere summary

Input: combined NGC+SGC maps for LRG, ELG, and QSO using DESI DR1 LSS catalogs, random catalogs 0..9, nside=32, 5000 permutation nulls, 5000 Poisson mocks, and 5000 block sign-flip nulls.

- Number of tested tracer/region/redshift bins: 10
- Minimum permutation p-value: 0.044991
- Minimum Bonferroni-adjusted p-value: 0.44991
- Minimum BH-FDR adjusted p-value: 0.44991

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |    ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|----------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | ELG      | NGC+SGC  | 0.8-1.1 |  1016365 |   62044406 |  0.0328003  | 204.33    |  -72.2938 |      0.044991  |       0.44991  |   0.44991  |        0.00019996 |                        5.62368 |
|           2 | ELG      | NGC+SGC  | 1.1-1.4 |   958344 |   58283773 |  0.0271119  | 202.82    |  -59.9784 |      0.0991802 |       0.991802 |   0.495901 |        0.00019996 |                        9.94841 |
|           3 | LRG      | NGC+SGC  | 0.8-1.1 |   859822 |   57675156 |  0.0159175  | 245.75    |  -52.2774 |      0.433913  |       1        |   0.95041  |        0.00019996 |                       16.1122  |
|           4 | QSO      | NGC+SGC  | 0.8-1.2 |   206348 |   30543365 |  0.0163706  |   1.0061  |   74.6791 |      0.440712  |       1        |   0.95041  |        0.0617876  |                       11.9405  |
|           5 | ELG      | NGC+SGC  | 1.4-1.6 |   457363 |   27742347 |  0.0173678  | 142.141   |  -59.3849 |      0.589482  |       1        |   0.95041  |        0.0059988  |                       19.1486  |
|           6 | QSO      | NGC+SGC  | 2.1-3.5 |   366560 |   54313268 |  0.00859681 | 331.517   |   20.1035 |      0.717257  |       1        |   0.95041  |        0.221156   |                       18.3908  |
|           7 | LRG      | NGC+SGC  | 0.6-0.8 |   771894 |   51784245 |  0.00824904 | 309.855   |   51.6984 |      0.886023  |       1        |   0.95041  |        0.0679864  |                       35.5913  |
|           8 | QSO      | NGC+SGC  | 1.2-1.6 |   296273 |   43878938 |  0.00635337 |  41.3529  |   21.8061 |      0.89962   |       1        |   0.95041  |        0.5013     |                       30.694   |
|           9 | LRG      | NGC+SGC  | 0.4-0.6 |   506911 |   33993766 |  0.0075235  |  68.9667  |   40.983  |      0.922615  |       1        |   0.95041  |        0.209158   |                       54.3569  |
|          10 | QSO      | NGC+SGC  | 1.6-2.1 |   354210 |   52484417 |  0.00466124 |   9.41935 |   66.3948 |      0.95041   |       1        |   0.95041  |        0.661868   |                       39.7702  |

## Closest axes among overlapping redshift intervals

| region   | left        | right       |   z_overlap |   axis_separation_deg |    left_p |   right_p |
|:---------|:------------|:------------|------------:|----------------------:|----------:|----------:|
| NGC+SGC  | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |               26.7407 | 0.044991  |  0.433913 |
| NGC+SGC  | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |              114.091  | 0.589482  |  0.89962  |
| NGC+SGC  | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |              139.647  | 0.0991802 |  0.89962  |
| NGC+SGC  | LRG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              146.289  | 0.433913  |  0.440712 |
| NGC+SGC  | ELG 1.1-1.4 | QSO 0.8-1.2 |         0.1 |              163.295  | 0.0991802 |  0.440712 |
| NGC+SGC  | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              173.01   | 0.044991  |  0.440712 |

## Interpretation

No directional claim should be made from local p-values without accounting for the
number of tracer, region, redshift, resolution, weight, and split tests that were tried.
Poisson p-values are shot-noise diagnostics only; the permutation p-value is the
first-pass null statistic used for this correction table.
