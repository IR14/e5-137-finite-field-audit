# Multipole diagnostics

- Map: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_SGC_z0p800_1p100_template_regressed_raw_map.npz`

This diagnostic compares the standard dipole-only fit with a fit that also
marginalizes over five quadrupole-like angular templates. If the dipole amplitude
or axis changes strongly, the candidate is likely entangled with broader footprint
or low-order angular structure rather than behaving as an isolated dipole.

## Summary

| model                  |   dipole_amplitude |   ra_deg |   dec_deg |   monopole |   n_pixels |   weighted_r2 |   residual_std |   weighted_design_condition |   quadrupole_norm |   axis_shift_from_dipole_only_deg |   amplitude_ratio_to_dipole_only |
|:-----------------------|-------------------:|---------:|----------:|-----------:|-----------:|--------------:|---------------:|----------------------------:|------------------:|----------------------------------:|---------------------------------:|
| dipole_only            |          0.0898115 |  204.939 |  -51.9442 |  0.0502938 |       1337 |   nan         |     nan        |                     nan     |          0        |                            0      |                          1       |
| dipole_plus_quadrupole |          0.64695   |  204.312 |   32.0787 |  0.27871   |       1337 |     0.0522153 |       0.167289 |                     154.483 |          0.712559 |                           84.0247 |                          7.20342 |

## Coefficients

| model                  | term     |   coefficient |
|:-----------------------|:---------|--------------:|
| dipole_plus_quadrupole | monopole |      0.27871  |
| dipole_plus_quadrupole | dipole_x |     -0.499559 |
| dipole_plus_quadrupole | dipole_y |     -0.225689 |
| dipole_plus_quadrupole | dipole_z |      0.343585 |
| dipole_plus_quadrupole | q_xx     |      0.440315 |
| dipole_plus_quadrupole | q_yy     |      0.232835 |
| dipole_plus_quadrupole | q_xy     |      0.273337 |
| dipole_plus_quadrupole | q_xz     |     -0.395795 |
| dipole_plus_quadrupole | q_yz     |     -0.168178 |
