# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 403644
- finite residual rows: 403644
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00595119
- axis RA: 251.516 deg
- axis DEC: 25.093 deg
- fitted pixels: 988
- block-null p-value: 0.9800399201596807
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    432456 |          13843 |                              14969 |                          0 |    403644 |       28812 | LOG_CIII_MGII2796_EW |       -4.97636 |        7.36572 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.056455    |
| z                     |  -0.660739    |
| z2                    |   0.678719    |
| LOGMSTAR              |   0.0285935   |
| RCHI2_LINE            |  -0.00396961  |
| DELTA_LINECHI2        |  -0.000202335 |
| FLUX_SYNTH_G          |  -0.153381    |
| FLUX_SYNTH_R          |   0.10998     |
| FLUX_SYNTH_Z          |   0.0106465   |
| FLUX_G                |   0.115813    |
| FLUX_R                |  -0.174781    |
| FLUX_Z                |   0.0957402   |
| FLUX_W1               |  -0.0435731   |
| FLUX_W2               |   0.0426408   |
| template_0_ebv        |   0.00178421  |
| template_1_stardens   |   0.00472733  |
| template_2_galdepth_g |   0.00895815  |
| template_3_galdepth_r |  -0.00750562  |
| template_4_galdepth_z |   0.00638451  |
| template_5_psfsize_g  |  -0.00292999  |
| template_6_psfsize_r  |   0.00259387  |
| template_7_psfsize_z  |   0.00317303  |
| template_8_cosky_g    |   0.00345802  |
| template_9_cosky_r    |  -0.00793604  |
| template_10_cosky_z   |   0.0113589   |

## Figures

- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
