# e-5-137 quintom interaction gate

Status: two-component dark-sector reconstruction for the project CPL target.

## Lagrangian class

A minimal effective quintom sector can be written as

```text
L_dark = -1/2 (partial phi)^2 - V_phi(phi)
         +1/2 (partial chi)^2 - V_chi(chi)
         - V_int(phi, chi)
```

where `phi` is non-phantom and `chi` is an effective phantom component.
Equivalently, at the background-fluid level:

```text
rho_+' + 3(1+w_+) rho_+ = I_+
rho_-' + 3(1+w_-) rho_- = -I_+
w_eff = (w_+ rho_+ + w_- rho_-) / (rho_+ + rho_-)
```

The prime denotes d/d ln a. `I_+` is the interaction needed to force the
two components to follow the project CPL target.

## Project target

| quantity | value |
|:--|--:|
| w0 | -0.751994852742 |
| wa | -0.860064969598 |
| w0 + wa | -1.61205982234 |
| phantom crossing redshift | 0.405197561097 |

## Independent two-fluid no-go

For independent constant-w components with positive densities,

```text
dw_eff / d ln a = -3 f(1-f) (w_- - w_+)^2 <= 0
```

but the project CPL target has

```text
dw/d ln a | today = -wa > 0
```

so the sign is wrong before any detailed fitting.

|   w_plus |   w_minus |   f_phantom_today |   target_dw_dln_a_today |   independent_dw_dln_a_today | sign_matches_target   |
|---------:|----------:|------------------:|------------------------:|-----------------------------:|:----------------------|
|     -0.7 |      -1.7 |         0.0519949 |                0.860065 |                    -0.147874 | False                 |
|     -0.5 |      -2   |         0.167997  |                0.860065 |                    -0.943473 | False                 |
|      0   |      -2.5 |         0.300798  |                0.860065 |                    -3.94347  | False                 |

## Best interacting reconstructions

|   w_plus |   w_minus |   f_phantom_today |   f_phantom_z1 |   f_phantom_z10 |   interaction_score |   max_abs_interaction_plus_over_rho_de |   rms_interaction_plus_over_rho_de | dominant_flow              |
|---------:|----------:|------------------:|---------------:|----------------:|--------------------:|---------------------------------------:|-----------------------------------:|:---------------------------|
|     -0.7 |     -1.84 |         0.0456095 |       0.422831 |        0.731467 |             1.4776  |                                1.21715 |                            1.04178 | to_nonphantom_from_phantom |
|     -0.7 |     -1.86 |         0.0448231 |       0.415541 |        0.718855 |             1.47769 |                                1.21589 |                            1.04719 | to_nonphantom_from_phantom |
|     -0.7 |     -1.82 |         0.046424  |       0.430382 |        0.744529 |             1.47985 |                                1.22074 |                            1.03643 | to_nonphantom_from_phantom |
|     -0.7 |     -1.8  |         0.047268  |       0.438207 |        0.758066 |             1.48226 |                                1.22447 |                            1.03118 | to_nonphantom_from_phantom |
|     -0.7 |     -1.88 |         0.0440634 |       0.408498 |        0.706671 |             1.48296 |                                1.2198  |                            1.05264 | to_nonphantom_from_phantom |
|     -0.7 |     -1.78 |         0.0481434 |       0.446322 |        0.772104 |             1.48483 |                                1.22833 |                            1.02603 | to_nonphantom_from_phantom |
|     -0.7 |     -1.76 |         0.0490517 |       0.454743 |        0.786672 |             1.48758 |                                1.23233 |                            1.02102 | to_nonphantom_from_phantom |
|     -0.7 |     -1.9  |         0.043329  |       0.401689 |        0.694893 |             1.4881  |                                1.22357 |                            1.05812 | to_nonphantom_from_phantom |
|     -0.7 |     -1.74 |         0.0499951 |       0.463488 |        0.8018   |             1.49053 |                                1.23649 |                            1.01618 | to_nonphantom_from_phantom |
|     -0.7 |     -1.92 |         0.0426187 |       0.395104 |        0.683502 |             1.49312 |                                1.22721 |                            1.06361 | to_nonphantom_from_phantom |
|     -0.7 |     -1.72 |         0.0509753 |       0.472576 |        0.817522 |             1.4937  |                                1.24081 |                            1.01155 | to_nonphantom_from_phantom |
|     -0.7 |     -1.7  |         0.0519949 |       0.482027 |        0.833872 |             1.4971  |                                1.24531 |                            1.00718 | to_nonphantom_from_phantom |

## Best profile

Best grid row: `w_+ = -0.7`, `w_- = -1.84`.

|     z |     w_eff |   f_phantom |   target_dw_dln_a |   independent_dw_dln_a |   interaction_plus_over_rho_de | energy_flow_direction      |
|------:|----------:|------------:|------------------:|-----------------------:|-------------------------------:|:---------------------------|
|  0    | -0.751995 |   0.0456095 |         0.860065  |              -0.169712 |                       0.903313 | to_nonphantom_from_phantom |
|  0.25 | -0.924008 |   0.196498  |         0.688052  |              -0.615568 |                       1.14353  | to_nonphantom_from_phantom |
|  0.5  | -1.03868  |   0.297091  |         0.573377  |              -0.814178 |                       1.21715  | to_nonphantom_from_phantom |
|  1    | -1.18203  |   0.422831  |         0.430032  |              -0.951482 |                       1.21186  | to_nonphantom_from_phantom |
|  2    | -1.32537  |   0.548571  |         0.286688  |              -0.965502 |                       1.09841  | to_nonphantom_from_phantom |
|  5    | -1.46872  |   0.674312  |         0.143344  |              -0.856236 |                       0.876825 | to_nonphantom_from_phantom |
| 10    | -1.53387  |   0.731467  |         0.0781877 |              -0.765815 |                       0.740353 | to_nonphantom_from_phantom |

## Gate result

The two-field route is mathematically possible only as an interacting
effective sector. Independent positive-density quintom components have
the wrong derivative sign for this project target.

The interaction reconstruction is also not gentle: the best coarse grid
still needs order-unity energy-transfer rates relative to rho_DE across
the tested redshift range. This is acceptable as an effective-fluid toy,
but it is not yet a healthy fundamental Lagrangian.

Next physical gate: replace the constant-w fluid reconstruction by an
explicit two-field dynamical system with a cutoff and check whether
the same interaction profile can arise from a simple potential such as
`V_int = g^2 phi^2 chi^2 / 2` without producing unstable early energy.
