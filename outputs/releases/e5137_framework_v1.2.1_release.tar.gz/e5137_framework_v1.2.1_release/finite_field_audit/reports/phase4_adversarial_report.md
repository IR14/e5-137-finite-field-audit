# Phase 4 adversarial symbolic-regression evaluation

This report estimates how often the same expression grammar hits random
targets of comparable numerical scale. It is a look-elsewhere sanity check
for Phase 4; low numerical error alone is not treated as physical evidence.

## Null Setup

- random targets: `2000`
- seed: `20260527`
- alpha null: `137 + Uniform(0, 0.08)`
- Kp null: `Uniform(1800, 1870)`
- grammar: Phase 4 coefficient bank from GF(137) signed residues and inverses
- strict Kp: up to 3 correction terms
- wide Kp: up to 4 correction terms

## Summary

| target                |   observed_ppm |   threshold_ppm |   n_random_targets |   empirical_p_vs_observed |   random_hit_rate_at_threshold |   random_ppm_median |   random_ppm_p05 |   random_ppm_p01 |   random_ppm_min |
|:----------------------|---------------:|----------------:|-------------------:|--------------------------:|-------------------------------:|--------------------:|-----------------:|-----------------:|-----------------:|
| alpha_inv_local_delta |    0.000147674 |            0.01 |               2000 |                  0.163418 |                          0.98  |         0.000863392 |      4.01663e-05 |      6.27826e-06 |      4.37107e-07 |
| Kp_strict_local       |    0.531225    |            0.5  |               2000 |                  0.989005 |                          0.985 |         0.0358938   |      0.00174837  |      0.000462154 |      2.09312e-05 |
| Kp_wide_local         |    0.0128051   |            0.5  |               2000 |                  0.961519 |                          1     |         0.00168228  |      0.000118215 |      2.36428e-05 |      5.82168e-07 |

## Reading Rule

- `empirical_p_vs_observed` answers: how often a random target is hit at least as well as the real target.
- `random_hit_rate_at_threshold` answers: how often a random target passes the declared ppm cutoff.
- A high random hit rate means the grammar is too dense to support a strong claim.
