# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |            19 |              0.0872292 |       0.0887852 |           0.29774  |                 0.277861 |             0.0660569 |                 0.546491 |                      0.181409  |                           0.744008 |                           44.2167 |
| ELG      | SGC      |     1.1 |     1.4 |            19 |              0.0717318 |       0.0729452 |           0.386123 |                 0.015992 |             0.0510521 |                 0.643871 |                      0.0834583 |                           0.699869 |                           37.154  |
| ELG      | SGC      |     1.4 |     1.6 |            19 |              0.0773342 |       0.0627376 |           0.586683 |                 0.134433 |             0.0138038 |                 0.989402 |                      0.86007   |                           0.220025 |                           79.6625 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| ELG      | SGC      |     0.8 |     1.1 | intercept                          |   0.00221976  |
| ELG      | SGC      |     0.8 |     1.1 | ntile                              |  -0.225345    |
| ELG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles                   |  -0.00553344  |
| ELG      | SGC      |     0.8 |     1.1 | nx                                 |   0.233307    |
| ELG      | SGC      |     0.8 |     1.1 | weight_sys                         |   0.00896388  |
| ELG      | SGC      |     0.8 |     1.1 | weight_sn                          |   0.00896388  |
| ELG      | SGC      |     0.8 |     1.1 | weight_rf                          |  -0.00234191  |
| ELG      | SGC      |     0.8 |     1.1 | weight_zfail                       |  -0.0141568   |
| ELG      | SGC      |     0.8 |     1.1 | weight_comp                        |   0.000809189 |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.0093256   |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_stardens   |   0.00875434  |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00295921  |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |   0.00760138  |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |  -0.00848584  |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |   0.000972206 |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.0117974   |
| ELG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.0107804   |
| ELG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0173348   |
| ELG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0111723   |
| ELG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.00302671  |
| ELG      | SGC      |     1.1 |     1.4 | intercept                          |   0.00800241  |
| ELG      | SGC      |     1.1 |     1.4 | ntile                              |  -0.32847     |
| ELG      | SGC      |     1.1 |     1.4 | frac_tlobs_tiles                   |   0.00213153  |
| ELG      | SGC      |     1.1 |     1.4 | nx                                 |   0.316544    |
| ELG      | SGC      |     1.1 |     1.4 | weight_sys                         |   0.00468172  |
| ELG      | SGC      |     1.1 |     1.4 | weight_sn                          |   0.00468172  |
| ELG      | SGC      |     1.1 |     1.4 | weight_rf                          |  -0.0057815   |
| ELG      | SGC      |     1.1 |     1.4 | weight_zfail                       |  -0.0186633   |
| ELG      | SGC      |     1.1 |     1.4 | weight_comp                        |  -0.00660851  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_ebv        |   0.000974178 |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_stardens   |   0.00261372  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |  -0.00530263  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |   0.0200936   |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.00927493  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |  -0.00133511  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00358201  |
| ELG      | SGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |  -0.00973936  |
| ELG      | SGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |   0.0212736   |
| ELG      | SGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |  -0.0142709   |
| ELG      | SGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |   0.00462196  |
| ELG      | SGC      |     1.4 |     1.6 | intercept                          |  -0.00342552  |
| ELG      | SGC      |     1.4 |     1.6 | ntile                              |  -0.344298    |
| ELG      | SGC      |     1.4 |     1.6 | frac_tlobs_tiles                   |   0.0420565   |
| ELG      | SGC      |     1.4 |     1.6 | nx                                 |   0.303778    |
| ELG      | SGC      |     1.4 |     1.6 | weight_sys                         |   9.808e-05   |
| ELG      | SGC      |     1.4 |     1.6 | weight_sn                          |   9.808e-05   |
| ELG      | SGC      |     1.4 |     1.6 | weight_rf                          |  -0.00333346  |
| ELG      | SGC      |     1.4 |     1.6 | weight_zfail                       |   0.00446538  |
| ELG      | SGC      |     1.4 |     1.6 | weight_comp                        |  -0.0175095   |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_ebv        |   0.021043    |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_stardens   |  -0.0156223   |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.0190322   |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |   0.00238464  |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.0207267   |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.00242377  |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00844482  |
| ELG      | SGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.0137659   |
| ELG      | SGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |  -0.0137364   |
| ELG      | SGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |  -0.0108819   |
| ELG      | SGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |   0.018681    |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
