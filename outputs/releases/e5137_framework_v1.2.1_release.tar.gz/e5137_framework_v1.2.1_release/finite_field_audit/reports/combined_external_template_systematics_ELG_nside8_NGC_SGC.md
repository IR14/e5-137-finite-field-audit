# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |            11 |              0.0647204 |       0.0327367 |           0.282572 |                0.0041632 |            0.0158349  |                 0.712096 |                      0.124063  |                           0.483705 |                           14.1187 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |            11 |              0.0788181 |       0.0262821 |           0.406198 |                0.0283097 |            0.0148221  |                 0.753416 |                      0.0824313 |                           0.563962 |                           16.2063 |
| ELG      | NGC+SGC  |     1.4 |     1.6 |            11 |              0.0995406 |       0.0174337 |           0.848051 |                0.314738  |            0.00507522 |                 0.997667 |                      0.929226  |                           0.291115 |                           87.5362 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 | intercept                          |  -0.00386825  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.000114287 |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00174847  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00347091  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |  -0.00416253  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |   0.000903726 |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.0184703   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.0012556   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.00173575  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0175601   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0295703   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.00561745  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | intercept                          |  -0.00382109  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_ebv        |  -0.00149571  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_stardens   |  -0.00122243  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |  -0.00213885  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |  -0.013071    |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.00027192  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |  -0.00968975  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00617071  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |  -0.00442125  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |  -0.0297157   |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |   0.0312776   |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |  -0.00885954  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | intercept                          |  -0.00346898  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_ebv        |   0.00773956  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_stardens   |   0.000632253 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.0346174   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |  -0.000549419 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.0261473   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.0161483   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.0139395   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.00591796  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |  -0.0163313   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.0117679   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |   0.0117785   |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
