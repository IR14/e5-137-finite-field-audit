# e-5-137 physical-model program

Status: research program, not a verified theory.

## Current Boundary Conditions

The observational DESI branch currently returns active null results for the
tested LRG/QSO cells. The number-theory branch finds dense modular expression
hits, but the adversarial evaluator shows that the present grammar hits random
targets too easily. Therefore, the next viable development is not another
formula search. It is a formal mechanism.

## Candidate Mathematical Object

Start from the finite field `GF(137)` and its multiplicative group:

- `GF(137)^*` is cyclic.
- `|GF(137)^*| = phi(137) = 136`.
- `136 = 26*5 + 6` is an arithmetic partition.
- `26*5 = 130` is not a divisor of `136`, so it is not a subgroup order.

That last point is decisive. If the model uses a `130 + 6` split, it must be a
state-sector decomposition, representation-space decomposition, or operator
rank/nullity split. It cannot be advertised as a direct subgroup split of
`GF(137)^*`.

## Minimal Formal Target

A real physical model needs an explicit tuple:

```text
(G, V, rho, O, M)
```

where:

- `G` is the symmetry object, initially `GF(137)^*` or a finite extension.
- `V` is a finite-dimensional state space.
- `rho: G -> GL(V)` is a representation.
- `O` is a self-adjoint or finite-spectrum operator whose eigenvalues generate observables.
- `M` is a matching map from dimensionless spectra to physical constants.

The model becomes nontrivial only if `O` is fixed without target-specific
fitting and predicts held-out constants.

## Required Gates

1. No target-specific grammar changes after looking at a target.
2. Complexity penalty fixed before scans.
3. Train/test split fixed before scans.
4. Random-target adversarial hit-rate reported beside every numerical hit.
5. At least one out-of-sample success beyond `alpha` and `Kp`.
6. No claim of derivation unless the expression follows from `(G, V, rho, O, M)`.

## Immediate Falsification Pressure

The muon anomaly `a_mu` currently fails the frozen Phase 4 out-of-sample gate by
about `2712 ppm`. This is not a small rounding issue. The finite-field program
must either predict `a_mu` without a new fitted operator, or explicitly narrow
its domain and stop claiming a unified particle-constant network.

## Constructive Next Step

Build a toy representation search that enumerates low-dimensional characters of
`GF(137)^*`, constructs spectra from character sums, and tests whether the same
operator family can predict:

- `alpha^-1`;
- `Kp = Mp/me`;
- `a_mu`;
- one held-out lepton or meson observable.

If random-target hit rates remain high, the theory-number branch should be
treated as a compact numerological coordinate system rather than a physical
model.
