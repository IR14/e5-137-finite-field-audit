# e-5-137 k-essence gate

Status: single-field k-essence no-go check for the project w0-wa target.

## General form

For a single-field k-essence sector,

```text
S = integral d^4x sqrt(-g) [ M_Pl^2 R/2 + P(phi, X) ]
X = -1/2 g^munu partial_mu phi partial_nu phi
p = P
rho = 2 X P_X - P
rho + p = 2 X P_X
c_s^2 = P_X / (P_X + 2 X P_XX)
```

A ghost-free single-field model has `P_X > 0`; with `X >= 0`, this gives
`rho + p >= 0`, therefore `w = p/rho >= -1` when rho is positive.

## Project CPL target

| quantity | value |
|:--|--:|
| w0 | -0.751994852742 |
| wa | -0.860064969598 |
| w(z -> infinity) = w0 + wa | -1.61205982234 |
| phantom crossing redshift | 0.405197561097 |

The target is non-phantom today, but becomes phantom above the crossing
redshift. That is the central obstruction for stable single-field
k-essence.

## CPL background implied by target

|      z |     w_cpl |   rho_de_over_rho_de0 |   E_H_over_H0 |    omega_de | requires_phantom   |
|-------:|----------:|----------------------:|--------------:|------------:|:-------------------|
|   0    | -0.751995 |            1          |       1.00004 | 0.689938    | False              |
|   0.25 | -0.924008 |            1.11216    |       1.17179 | 0.558884    | False              |
|   0.5  | -1.03868  |            1.1225     |       1.34953 | 0.425276    | True               |
|   1    | -1.18203  |            1.01751    |       1.78424 | 0.220536    | True               |
|   2    | -1.32537  |            0.742955   |       2.9816  | 0.0576652   | True               |
|   5    | -1.46872  |            0.319874   |       8.2035  | 0.00327966  | True               |
|  10    | -1.53387  |            0.127794   |      20.3474  | 0.000212982 | True               |
| 100    | -1.60354  |            0.00268643 |     573.375   | 5.63829e-09 | True               |

## Kinetic-sector algebra

| target                | model                               |         w |   y_solution |        cs2 | rho_positive   | ghost_free   | passes_single_field_stable_gate   |
|:----------------------|:------------------------------------|----------:|-------------:|-----------:|:---------------|:-------------|:----------------------------------|
| today_w0              | canonical_F_y_minus_1               | -0.751995 |    0.141556  |   1        | True           | True         | True                              |
| today_w0              | quadratic_F_kappa_0.5               | -0.751995 |    0.126651  |   0.816442 | True           | True         | True                              |
| today_w0              | quadratic_F_kappa_1                 | -0.751995 |    0.116383  |   0.725883 | True           | True         | True                              |
| today_w0              | quadratic_F_kappa_5                 | -0.751995 |    0.0808361 |   0.527976 | True           | True         | True                              |
| today_w0              | tachyon_DBI_F_minus_sqrt_1_minus_2y | -0.751995 |    0.124003  |   0.751995 | True           | True         | True                              |
| z1_cpl                | canonical_F_y_minus_1               | -1.18203  |   -0.0834212 |   1        | True           | False        | False                             |
| z1_cpl                | quadratic_F_kappa_0.5               | -1.18203  |  nan         | nan        | False          | False        | False                             |
| z1_cpl                | quadratic_F_kappa_1                 | -1.18203  |  nan         | nan        | False          | False        | False                             |
| z1_cpl                | quadratic_F_kappa_5                 | -1.18203  |  nan         | nan        | False          | False        | False                             |
| z1_cpl                | tachyon_DBI_F_minus_sqrt_1_minus_2y | -1.18203  |   -0.0910137 |   1.18203  | False          | False        | False                             |
| asymptotic_w0_plus_wa | canonical_F_y_minus_1               | -1.61206  |   -0.234321  |   1        | True           | False        | False                             |
| asymptotic_w0_plus_wa | quadratic_F_kappa_0.5               | -1.61206  |  nan         | nan        | False          | False        | False                             |
| asymptotic_w0_plus_wa | quadratic_F_kappa_1                 | -1.61206  |  nan         | nan        | False          | False        | False                             |
| asymptotic_w0_plus_wa | quadratic_F_kappa_5                 | -1.61206  |  nan         | nan        | False          | False        | False                             |
| asymptotic_w0_plus_wa | tachyon_DBI_F_minus_sqrt_1_minus_2y | -1.61206  |   -0.30603   |   1.61206  | False          | False        | False                             |

## Gate result

A healthy k-essence kinetic sector can reproduce the present-day
`w0` value algebraically. For example, tachyon/DBI-like kinetics need
`y = (1+w0)/2`, with positive sound speed.

But the same single-field stable class cannot reproduce the full
`w0-wa` target, because already by z=1 the CPL value is below -1.
That requires phantom behavior, a ghost, a two-field quintom
construction, or modified gravity/effective-fluid physics.

## Next Lagrangian class

The next honest move is not another single-field `P(X, phi)` scan.
To keep the project `w0-wa` pair, move to a two-component dark sector:

```text
L_dark = -1/2 (partial phi)^2 - V_phi(phi)
         +1/2 (partial chi)^2 - V_chi(chi)
         - g^2 phi^2 chi^2 / 2
```

or replace the phantom component by an explicitly effective modified-gravity
fluid. The two-field route can cross `w=-1`; the price is that the
phantom/negative-kinetic component must be treated as an effective field
with a cutoff, not a fundamental UV-complete scalar.
