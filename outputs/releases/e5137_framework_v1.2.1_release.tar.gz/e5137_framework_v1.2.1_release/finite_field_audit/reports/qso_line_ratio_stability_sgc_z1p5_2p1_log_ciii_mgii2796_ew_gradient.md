# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 140738
- finite residual rows: 140738
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0116669
- axis RA: 10.449 deg
- axis DEC: -36.442 deg
- fitted pixels: 356
- block-null p-value: 0.9920159680638723
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    151020 |           4995 |                               5287 |                          0 |    140738 |       10282 | LOG_CIII_MGII2796_EW |       -5.01066 |        7.41274 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.0546346   |
| z                     |  -0.725899    |
| z2                    |   0.7434      |
| LOGMSTAR              |   0.0184687   |
| RCHI2_LINE            |  -0.0190361   |
| DELTA_LINECHI2        |  -0.00236188  |
| FLUX_SYNTH_G          |  -0.208004    |
| FLUX_SYNTH_R          |   0.171179    |
| FLUX_SYNTH_Z          |   0.0338299   |
| FLUX_G                |   0.133845    |
| FLUX_R                |  -0.216481    |
| FLUX_Z                |   0.0943531   |
| FLUX_W1               |  -0.0457654   |
| FLUX_W2               |   0.0490462   |
| template_0_ebv        |  -0.000458293 |
| template_1_stardens   |   0.0072076   |
| template_2_galdepth_g |   0.0121699   |
| template_3_galdepth_r |   0.000441157 |
| template_4_galdepth_z |  -0.00117826  |
| template_5_psfsize_g  |  -0.00298103  |
| template_6_psfsize_r  |   0.00237614  |
| template_7_psfsize_z  |   0.0036012   |
| template_8_cosky_g    |   0.0121097   |
| template_9_cosky_r    |  -0.00695023  |
| template_10_cosky_z   |   0.00156661  |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
