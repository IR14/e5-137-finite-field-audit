# Master first-pass science report

## Scope

This report summarizes first-pass DESI DR1 LSS directional-density checks for the
genesis-gradient hypothesis. The analysis is framed as a null test against an
isotropic Lambda-CDM-compatible sky after survey-footprint correction with random catalogs.

It is not a claim of evidence for a new cosmology. Low local p-values are treated as
systematics prompts until they survive masking, weighting, tracer, region, redshift,
and look-elsewhere checks.

## Primary all-tracer result

- Input table: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/enhanced_null_poisson_all_tracers_NGC_SGC_ran0_9_look_elsewhere.csv`
- Tested bins: 20
- Minimum raw permutation p-value: 0.0607878
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.981204

| tracer   | region   |   z_min |   z_max |   amplitude |   ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   jackknife_axis_max_shift_deg |
|:---------|:---------|--------:|--------:|------------:|---------:|----------:|---------------:|---------------:|-----------:|-------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |   0.0898115 | 204.939  | -51.9442  |      0.0607878 |              1 |   0.981204 |                        66.2156 |
| ELG      | SGC      |     1.1 |     1.4 |   0.0733176 | 194.738  | -37.1618  |      0.156569  |              1 |   0.981204 |                        13.2065 |
| LRG      | NGC      |     0.4 |     0.6 |   0.0552216 |   2.71   | -28.9237  |      0.203559  |              1 |   0.981204 |                        11.5075 |
| ELG      | NGC      |     0.8 |     1.1 |   0.0367808 | 188.814  | -11.4021  |      0.367726  |              1 |   0.981204 |                        17.614  |
| ELG      | SGC      |     1.4 |     1.6 |   0.0659999 |  37.8017 | -40.4783  |      0.419316  |              1 |   0.981204 |                        57.3935 |
| LRG      | SGC      |     0.8 |     1.1 |   0.052456  | 186.144  |   1.64661 |      0.474305  |              1 |   0.981204 |                        27.7551 |
| QSO      | SGC      |     1.2 |     1.6 |   0.0475859 |  16.7271 | -13.7549  |      0.512298  |              1 |   0.981204 |                        14.0297 |
| LRG      | SGC      |     0.4 |     0.6 |   0.0577945 |  54.3351 |  17.5944  |      0.540492  |              1 |   0.981204 |                        19.6748 |
| ELG      | NGC      |     1.1 |     1.4 |   0.0253917 | 197.441  | -30.0668  |      0.613677  |              1 |   0.981204 |                        19.8923 |
| LRG      | NGC      |     0.6 |     0.8 |   0.0244573 | 344.195  | -24.8758  |      0.692262  |              1 |   0.981204 |                        36.0895 |

## Combined NGC+SGC maps

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/combined_region_all_tracers_NGC_SGC_ran0_9_look_elsewhere.csv`

| tracer   | region   |   z_min |   z_max |   amplitude |    ra_deg |   dec_deg |   null_p_value |   block_null_p_value |   n_data |   n_random |
|:---------|:---------|--------:|--------:|------------:|----------:|----------:|---------------:|---------------------:|---------:|-----------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |  0.0328003  | 204.33    |  -72.2938 |      0.044991  |           0.00179964 |  1016365 |   62044406 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |  0.0271119  | 202.82    |  -59.9784 |      0.0991802 |           0.0229954  |   958344 |   58283773 |
| LRG      | NGC+SGC  |     0.8 |     1.1 |  0.0159175  | 245.75    |  -52.2774 |      0.433913  |           0.187363   |   859822 |   57675156 |
| QSO      | NGC+SGC  |     0.8 |     1.2 |  0.0163706  |   1.0061  |   74.6791 |      0.440712  |           0.179164   |   206348 |   30543365 |
| ELG      | NGC+SGC  |     1.4 |     1.6 |  0.0173678  | 142.141   |  -59.3849 |      0.589482  |           0.269946   |   457363 |   27742347 |
| QSO      | NGC+SGC  |     2.1 |     3.5 |  0.00859681 | 331.517   |   20.1035 |      0.717257  |           0.168766   |   366560 |   54313268 |
| LRG      | NGC+SGC  |     0.6 |     0.8 |  0.00824904 | 309.855   |   51.6984 |      0.886023  |           0.79984    |   771894 |   51784245 |
| QSO      | NGC+SGC  |     1.2 |     1.6 |  0.00635337 |  41.3529  |   21.8061 |      0.89962   |           0.557089   |   296273 |   43878938 |
| LRG      | NGC+SGC  |     0.4 |     0.6 |  0.0075235  |  68.9667  |   40.983  |      0.922615  |           0.930014   |   506911 |   33993766 |
| QSO      | NGC+SGC  |     1.6 |     2.1 |  0.00466124 |   9.41935 |   66.3948 |      0.95041   |           0.777644   |   354210 |   52484417 |

## Nside robustness for ELG SGC

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/nside_axis_stability_ELG_SGC_ran0_9_nside16_32_64_perm5000_pois5000.csv`

| tracer   | region   |   z_min |   z_max |   nside_count |   max_axis_shift_deg |   amplitude_range |   p_value_min |   p_value_max |
|:---------|:---------|--------:|--------:|--------------:|---------------------:|------------------:|--------------:|--------------:|
| ELG      | SGC      |     0.8 |     1.1 |             3 |              2.04786 |       0.00102634  |     0.0261948 |      0.29854  |
| ELG      | SGC      |     1.1 |     1.4 |             3 |              2.25519 |       0.000721698 |     0.0869826 |      0.381324 |
| ELG      | SGC      |     1.4 |     1.6 |             3 |              1.58541 |       0.00326233  |     0.320936  |      0.583483 |

## ELG SGC weight-mode robustness

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/weight_mode_ELG_SGC_summary_ran0_9_nside32_perm5000_pois5000.csv`

|   z_min |   z_max | weight_mode   |   amplitude |   ra_deg |   dec_deg |   null_p_value |   axis_sep_from_desi_deg |
|--------:|--------:|:--------------|------------:|---------:|----------:|---------------:|-------------------------:|
|     0.8 |     1.1 | desi          |   0.0898115 | 204.939  |  -51.9442 |     0.0607878  |              0           |
|     0.8 |     1.1 | no_fkp        |   0.259506  | 169.98   |  -19.9105 |     0.00019996 |             41.9989      |
|     0.8 |     1.1 | uniform       |   0.577399  | 160.571  |  -30.5326 |     0.00019996 |             38.7775      |
|     1.1 |     1.4 | desi          |   0.0733176 | 194.738  |  -37.1618 |     0.156569   |              8.53774e-07 |
|     1.1 |     1.4 | no_fkp        |   0.25312   | 167.997  |  -14.864  |     0.00019996 |             32.5585      |
|     1.1 |     1.4 | uniform       |   0.502607  | 154.425  |  -26.7025 |     0.00019996 |             35.4801      |
|     1.4 |     1.6 | desi          |   0.0659999 |  37.8017 |  -40.4783 |     0.419316   |              0           |
|     1.4 |     1.6 | no_fkp        |   0.191981  | 148.191  |  -15.6157 |     0.00579884 |             94.6162      |
|     1.4 |     1.6 | uniform       |   0.460358  | 145.819  |  -28.3116 |     0.00019996 |             84.2176      |

## ELG SGC template-regression weight-mode summary

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/template_systematics_ELG_SGC_weight_modes_summary.csv`

| template_weight_mode   |   z_min |   z_max |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   corrected_amplitude |   corrected_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |   corrected_block_null_p_value |
|:-----------------------|--------:|--------:|-----------------------:|----------------:|-------------------:|----------------------:|-------------------------:|-----------------------------------:|----------------------------------:|-------------------------------:|
| desi                   |     0.8 |     1.1 |             0.00714767 |       0.0898115 |         0.0607878  |             0.0850716 |               0.0763847  |                           0.947223 |                           8.34483 |                     0.380324   |
| desi                   |     1.1 |     1.4 |             0.00342322 |       0.0733176 |         0.163567   |             0.0775923 |               0.130374   |                           1.0583   |                           2.63864 |                     0.0179964  |
| desi                   |     1.4 |     1.6 |             0.00698961 |       0.0659999 |         0.405719   |             0.0616205 |               0.461908   |                           0.933646 |                           9.14474 |                     0.172765   |
| no_fkp                 |     0.8 |     1.1 |             0.737905   |       0.259506  |         0.00019996 |             0.0928712 |               0.0215957  |                           0.357877 |                          42.6017  |                     0.285943   |
| no_fkp                 |     1.1 |     1.4 |             0.69619    |       0.25312   |         0.00019996 |             0.0853573 |               0.0835833  |                           0.337221 |                          26.9164  |                     0.0323935  |
| no_fkp                 |     1.4 |     1.6 |             0.583084   |       0.191981  |         0.00459908 |             0.0424471 |               0.623675   |                           0.221101 |                          88.829   |                     0.363327   |
| uniform                |     0.8 |     1.1 |             0.899261   |       0.577399  |         0.00019996 |             0.299533  |               0.00019996 |                           0.518763 |                          56.5614  |                     0.00159968 |
| uniform                |     1.1 |     1.4 |             0.900161   |       0.502607  |         0.00019996 |             0.241485  |               0.00019996 |                           0.480464 |                          68.25    |                     0.00579884 |
| uniform                |     1.4 |     1.6 |             0.86151    |       0.460358  |         0.00019996 |             0.255931  |               0.00019996 |                           0.55594  |                          78.631   |                     0.00279944 |

## ELG low-z multipole diagnostics

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/multipole_ELG_lowz_summary.csv`

| map_case                   | model                  |   dipole_amplitude |   ra_deg |   dec_deg |   weighted_r2 |   weighted_design_condition |   quadrupole_norm |   axis_shift_from_dipole_only_deg |   amplitude_ratio_to_dipole_only |
|:---------------------------|:-----------------------|-------------------:|---------:|----------:|--------------:|----------------------------:|------------------:|----------------------------------:|---------------------------------:|
| ELG_SGC_raw                | dipole_only            |          0.0898115 |  204.939 |  -51.9442 |   nan         |                    nan      |         0         |                            0      |                          1       |
| ELG_SGC_raw                | dipole_plus_quadrupole |          0.64695   |  204.312 |   32.0787 |     0.0522153 |                    154.483  |         0.712559  |                           84.0247 |                          7.20342 |
| ELG_SGC_template_corrected | dipole_only            |          0.0850716 |  215.176 |  -57.8849 |   nan         |                    nan      |         0         |                            0      |                          1       |
| ELG_SGC_template_corrected | dipole_plus_quadrupole |          0.58322   |  206.974 |   31.8438 |     0.0481719 |                    154.483  |         0.610972  |                           89.9933 |                          6.85564 |
| ELG_NGC_SGC_combined       | dipole_only            |          0.0328003 |  204.33  |  -72.2938 |   nan         |                    nan      |         0         |                            0      |                          1       |
| ELG_NGC_SGC_combined       | dipole_plus_quadrupole |          0.0609946 |  237.364 |  -79.7118 |     0.0185072 |                     28.2765 |         0.0686588 |                           10.6265 |                          1.85957 |

## ELG SGC systematics splits

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/systematics_audit_ELG_SGC_ran0_9_with_corrections.csv`

| split_variable   | split_name     | tracer   | region   |   z_min |   z_max |   null_p_value |   bonferroni_p |   bh_fdr_p |   amplitude |
|:-----------------|:---------------|:---------|:---------|--------:|--------:|---------------:|---------------:|-----------:|------------:|
| ntile            | 1              | ELG      | SGC      |     0.8 |     1.1 |     0.002997   |       0.107892 |   0.107892 |   0.155293  |
| frac_tlobs_tiles | q1_0.167_0.617 | ELG      | SGC      |     0.8 |     1.1 |     0.00799201 |       0.287712 |   0.143856 |   0.15156   |
| frac_tlobs_tiles | q1_0.167_0.617 | ELG      | SGC      |     1.1 |     1.4 |     0.0509491  |       1        |   0.611389 |   0.100759  |
| ntile            | 1              | ELG      | SGC      |     1.1 |     1.4 |     0.0979021  |       1        |   0.881119 |   0.0915478 |
| ra_sector        | 0_90           | ELG      | SGC      |     0.8 |     1.1 |     0.145854   |       1        |   0.923762 |   0.172826  |
| ra_sector        | 0_90           | ELG      | SGC      |     1.4 |     1.6 |     0.195804   |       1        |   0.923762 |   0.200976  |
| ntile            | 7              | ELG      | SGC      |     1.4 |     1.6 |     0.205794   |       1        |   0.923762 |  27.1911    |
| ntile            | 3              | ELG      | SGC      |     1.4 |     1.6 |     0.264735   |       1        |   0.923762 |   0.238552  |
| ntile            | 2              | ELG      | SGC      |     1.4 |     1.6 |     0.364635   |       1        |   0.923762 |   0.0999685 |
| frac_tlobs_tiles | q2_0.617_0.77  | ELG      | SGC      |     1.4 |     1.6 |     0.450549   |       1        |   0.923762 |   0.0924527 |
| ntile            | 3              | ELG      | SGC      |     1.1 |     1.4 |     0.483516   |       1        |   0.923762 |   0.151627  |
| frac_tlobs_tiles | q3_0.77_1      | ELG      | SGC      |     1.4 |     1.6 |     0.493506   |       1        |   0.923762 |   0.197219  |

## Focused block-null diagnostic

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/enhanced_null_poisson_block_ELG_SGC_ran0_9_nside32_perm5000_pois5000_block5000.csv`

| tracer   | region   |   z_min |   z_max |   amplitude |   null_p_value |   poisson_p_value |   block_null_p_value |   jackknife_axis_max_shift_deg |
|:---------|:---------|--------:|--------:|------------:|---------------:|------------------:|---------------------:|-------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |   0.0898115 |      0.0607878 |        0.00019996 |            0.369726  |                        66.2156 |
| ELG      | SGC      |     1.1 |     1.4 |   0.0733176 |      0.158568  |        0.00039992 |            0.0211958 |                        13.2065 |
| ELG      | SGC      |     1.4 |     1.6 |   0.0659999 |      0.420316  |        0.00359928 |            0.0909818 |                        57.3935 |

## ELG SGC raw-map RA jackknife

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/jackknife_ELG_SGC_z0p800_1p100_raw_template_run.csv`

|   region_index |   removed_ra_min_deg |   removed_ra_max_deg |   removed_dec_min_deg |   removed_dec_max_deg |   leave_one_out_amplitude |   amplitude_change |   axis_shift_deg |
|---------------:|---------------------:|---------------------:|----------------------:|----------------------:|--------------------------:|-------------------:|-----------------:|
|              7 |              70.3125 |             323.438  |              -13.248  |               9.59407 |                 0.0740632 |       -0.0157483   |         66.2156  |
|              6 |              50.625  |              70.3125 |              -19.4712 |               2.38802 |                 0.13357   |        0.0437587   |         19.2616  |
|              2 |              15.4688 |              23.9062 |              -19.4712 |              32.7972  |                 0.0895882 |       -0.000223328 |          8.31209 |
|              3 |              23.9062 |              30.9375 |              -19.4712 |              34.2289  |                 0.094679  |        0.00486748  |          6.73815 |
|              1 |               8.4375 |              15.4688 |              -16.9578 |              32.7972  |                 0.0817072 |       -0.00810439  |          6.14023 |
|              4 |              30.9375 |              39.375  |              -19.4712 |              32.7972  |                 0.0933079 |        0.00349639  |          4.57891 |

## ELG SGC template-corrected RA jackknife

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/jackknife_ELG_SGC_z0p800_1p100_template_corrected.csv`

|   region_index |   removed_ra_min_deg |   removed_ra_max_deg |   removed_dec_min_deg |   removed_dec_max_deg |   leave_one_out_amplitude |   amplitude_change |   axis_shift_deg |
|---------------:|---------------------:|---------------------:|----------------------:|----------------------:|--------------------------:|-------------------:|-----------------:|
|              7 |              70.3125 |             323.438  |              -13.248  |               9.59407 |                 0.0784446 |        -0.006627   |         62.0973  |
|              6 |              50.625  |              70.3125 |              -19.4712 |               2.38802 |                 0.124149  |         0.0390777  |         23.9177  |
|              2 |              15.4688 |              23.9062 |              -19.4712 |              32.7972  |                 0.0829786 |        -0.00209302 |          7.94995 |
|              3 |              23.9062 |              30.9375 |              -19.4712 |              34.2289  |                 0.088247  |         0.00317542 |          7.50353 |
|              1 |               8.4375 |              15.4688 |              -16.9578 |              32.7972  |                 0.0786483 |        -0.00642329 |          7.36678 |
|              9 |             333.281  |             341.719  |              -13.248  |              34.2289  |                 0.0911319 |         0.00606029 |          5.02534 |

## Reference-axis comparison

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/enhanced_null_poisson_all_tracers_NGC_SGC_ran0_9_reference_axes.csv`

| reference       | tracer   | region   |   z_min |   z_max |   axis_separation_deg |   null_p_value |   amplitude |
|:----------------|:---------|:---------|--------:|--------:|----------------------:|---------------:|------------:|
| cmb_dipole_apex | LRG      | SGC      |     0.8 |     1.1 |               20.0944 |       0.474305 |  0.052456   |
| cmb_dipole_apex | ELG      | NGC      |     1.4 |     1.6 |               20.8191 |       0.923615 |  0.0158525  |
| cmb_dipole_apex | ELG      | NGC      |     0.8 |     1.1 |               21.0731 |       0.367726 |  0.0367808  |
| cmb_dipole_apex | QSO      | NGC      |     1.6 |     2.1 |               24.766  |       0.932414 |  0.010364   |
| cmb_dipole_apex | QSO      | NGC      |     2.1 |     3.5 |               25.4848 |       0.946611 |  0.00836338 |
| cmb_dipole_apex | QSO      | SGC      |     1.6 |     2.1 |               25.5681 |       0.833433 |  0.0267847  |
| cmb_dipole_apex | QSO      | SGC      |     0.8 |     1.2 |               25.7166 |       0.846031 |  0.0269636  |
| cmb_dipole_apex | LRG      | NGC      |     0.6 |     0.8 |               32.0284 |       0.692262 |  0.0244573  |
| cmb_dipole_apex | QSO      | SGC      |     1.2 |     1.6 |               35.2832 |       0.512298 |  0.0475859  |
| cmb_dipole_apex | ELG      | NGC      |     1.1 |     1.4 |               36.0699 |       0.613677 |  0.0253917  |
| cmb_dipole_apex | LRG      | NGC      |     0.4 |     0.6 |               38.5862 |       0.203559 |  0.0552216  |
| cmb_dipole_apex | ELG      | SGC      |     1.1 |     1.4 |               38.8153 |       0.156569 |  0.0733176  |

## Region consistency

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/enhanced_null_poisson_all_tracers_NGC_SGC_ran0_9_region_consistency.csv`

| tracer   |   z_min |   z_max | left_region   | right_region   |   axis_separation_deg |   left_p |   right_p |
|:---------|--------:|--------:|:--------------|:---------------|----------------------:|---------:|----------:|
| QSO      |     1.6 |     2.1 | NGC           | SGC            |               4.4252  | 0.932414 | 0.833433  |
| ELG      |     1.1 |     1.4 | NGC           | SGC            |               7.44236 | 0.613677 | 0.156569  |
| ELG      |     0.8 |     1.1 | NGC           | SGC            |              42.5951  | 0.367726 | 0.0607878 |
| LRG      |     0.6 |     0.8 | NGC           | SGC            |              57.8381  | 0.692262 | 0.75125   |
| QSO      |     0.8 |     1.2 | NGC           | SGC            |              66.382   | 0.814637 | 0.846031  |
| LRG      |     0.8 |     1.1 | NGC           | SGC            |              67.3408  | 0.787443 | 0.474305  |
| LRG      |     0.4 |     0.6 | NGC           | SGC            |              68.1761  | 0.203559 | 0.540492  |
| ELG      |     1.4 |     1.6 | NGC           | SGC            |              77.16    | 0.923615 | 0.419316  |
| QSO      |     1.2 |     1.6 | NGC           | SGC            |              77.7125  | 0.981204 | 0.512298  |
| QSO      |     2.1 |     3.5 | NGC           | SGC            |              89.471   | 0.946611 | 0.913217  |

## Cross-tracer consistency

- Source: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/enhanced_null_poisson_all_tracers_NGC_SGC_ran0_9_tracer_consistency.csv`

| region   | left_tracer   | right_tracer   |   left_z_min |   left_z_max |   right_z_min |   right_z_max |   z_overlap |   axis_separation_deg |    left_p |   right_p |
|:---------|:--------------|:---------------|-------------:|-------------:|--------------:|--------------:|------------:|----------------------:|----------:|----------:|
| SGC      | LRG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               15.6582 | 0.474305  |  0.846031 |
| SGC      | ELG           | QSO            |          1.1 |          1.4 |           0.8 |           1.2 |         0.1 |               24.9766 | 0.156569  |  0.846031 |
| SGC      | ELG           | QSO            |          1.4 |          1.6 |           1.2 |           1.6 |         0.2 |               32.4597 | 0.419316  |  0.512298 |
| NGC      | ELG           | QSO            |          1.1 |          1.4 |           1.2 |           1.6 |         0.2 |               37.2549 | 0.613677  |  0.981204 |
| SGC      | ELG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               40.7975 | 0.0607878 |  0.846031 |
| NGC      | ELG           | QSO            |          1.1 |          1.4 |           0.8 |           1.2 |         0.1 |               49.072  | 0.613677  |  0.814637 |
| NGC      | LRG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               49.4816 | 0.787443  |  0.814637 |
| NGC      | ELG           | QSO            |          1.4 |          1.6 |           1.2 |           1.6 |         0.2 |               50.9198 | 0.923615  |  0.981204 |
| SGC      | ELG           | QSO            |          1.1 |          1.4 |           1.2 |           1.6 |         0.2 |               50.9511 | 0.156569  |  0.512298 |
| SGC      | ELG           | LRG            |          0.8 |          1.1 |           0.8 |           1.1 |         0.3 |               55.8963 | 0.0607878 |  0.474305 |
| NGC      | ELG           | LRG            |          0.8 |          1.1 |           0.8 |           1.1 |         0.3 |               56.7154 | 0.367726  |  0.787443 |
| NGC      | ELG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               66.7775 | 0.367726  |  0.814637 |

## Interpretation

- The current all-tracer grid does not reject the isotropic null after look-elsewhere correction.
- The lowest local p-value is the DESI-weighted ELG SGC low-redshift bin, but it is not significant after correction and has large jackknife sensitivity.
- The same feature is not mirrored by LRG or QSO, and the NGC counterpart is weaker.
- ELG SGC is strongly weight-sensitive: removing or simplifying DESI weights produces much larger amplitudes and different axes, which is a survey-selection warning.
- Any future positive claim would require end-to-end survey mocks and deeper systematics modeling beyond this first-pass estimator.

## Recommended next checks

- Replace empirical nulls with official or mock-based DESI clustering mocks when available for this exact catalog selection.
- Add Galactic extinction, stellar density, imaging depth, and redshift-failure maps as explicit regressors.
- Run the same estimator on independent catalog versions or alternative target selections.
