# GF(137) multiplicative-group structure

`137` is prime, so the nonzero residue classes form a cyclic group
`GF(137)^*` of order `phi(137)=136`.

## Basic Facts

- `phi(137) = 136`
- `D*N = 130`
- residual `phi(137) - D*N = 6`
- divisors of `136`: `1, 2, 4, 8, 17, 34, 68, 136`
- first primitive root found: `3`
- number of primitive roots: `64`

## Important Constraint

`D*N = 130` is not a divisor of `136`. Therefore, it cannot be the
order of a subgroup of `GF(137)^*`. A physically meaningful model may still
use a `130 + 6` partition as a state-sector bookkeeping rule, but it is not
a direct subgroup decomposition of the multiplicative group.

## Order Distribution

|   order |   n_elements |
|--------:|-------------:|
|       1 |            1 |
|       2 |            1 |
|       4 |            2 |
|       8 |            4 |
|      17 |           16 |
|      34 |           16 |
|      68 |           32 |
|     136 |           64 |

## Subgroups

|   subgroup_size |   generator | members_preview                                     | preview_truncated   |
|----------------:|------------:|:----------------------------------------------------|:--------------------|
|               1 |           1 | 1                                                   | False               |
|               2 |         136 | 1 136                                               | False               |
|               4 |         100 | 1 100 136 37                                        | False               |
|               8 |         127 | 1 127 100 96 136 10 37 41                           | False               |
|              17 |         122 | 1 122 88 50 72 16 34 38 115 56 119 133 60 59 74 123 | True                |
|              34 |          81 | 1 81 122 18 88 4 50 77 72 78 16 63 34 14 38 64      | True                |
|              68 |           9 | 1 9 81 44 122 2 18 25 88 107 4 36 50 39 77 8        | True                |
|             136 |           3 | 1 3 9 27 81 106 44 132 122 92 2 6 18 54 25 75       | True                |

## Consequence For Model Building

A rigorous finite-group version of the model needs an explicit representation
or operator whose spectrum naturally splits into a 130-dimensional sector and
a 6-dimensional sector. The bare multiplicative group does not provide that
split by subgroup order.
