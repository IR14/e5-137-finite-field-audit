# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |            11 |              0.0150558 |       0.0326834 |           0.117882 |               0.00199601 |             0.0229974 |                 0.31968  |                      0.0199601 |                           0.703641 |                           5.54116 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |            11 |              0.023599  |       0.0267839 |           0.256743 |               0.0359281  |             0.021825  |                 0.428571 |                      0.0179641 |                           0.814855 |                          14.6514  |
| ELG      | NGC+SGC  |     1.4 |     1.6 |            11 |              0.016974  |       0.0178394 |           0.807193 |               0.273453   |             0.00825   |                 0.976024 |                      0.758483  |                           0.462461 |                          13.2413  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 | intercept                          |  -0.00178673  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.00156202  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00449527  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00050953  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |  -0.00437876  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |  -0.00225391  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.00938399  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.00386307  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.0030016   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0130313   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0206439   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.00785007  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | intercept                          |  -0.00197409  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_ebv        |  -0.00427542  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_stardens   |  -0.000245661 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |   0.000850687 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |  -0.00602369  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.00464493  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |  -0.00276068  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00555481  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |  -0.00226605  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |  -0.0115177   |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |   0.00810939  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |  -0.00450959  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | intercept                          |  -0.00186956  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_ebv        |   0.000955616 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_stardens   |  -0.000533982 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.0135967   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |  -0.00611089  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.0155666   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.0109688   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00514629  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.00211423  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |  -0.00286889  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.00704961  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.00021941  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
