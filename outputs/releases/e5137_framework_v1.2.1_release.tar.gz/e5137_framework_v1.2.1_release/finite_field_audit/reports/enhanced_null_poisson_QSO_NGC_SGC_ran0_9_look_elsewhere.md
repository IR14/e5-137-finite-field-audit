# Look-elsewhere summary

Input: QSO over NGC and SGC using DESI DR1 LSS catalogs, random catalogs 0..9, nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

- Number of tested tracer/region/redshift bins: 8
- Minimum permutation p-value: 0.512298
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.981204

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |    ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|----------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | QSO      | SGC      | 1.2-1.6 |   104480 |   15788596 |  0.0475859  |  16.7271  |  -13.7549 |       0.512298 |              1 |   0.981204 |         0.0593881 |                        14.0297 |
|           2 | QSO      | NGC      | 0.8-1.2 |   133606 |   19526917 |  0.0182969  | 349.031   |   77.3898 |       0.814637 |              1 |   0.981204 |         0.390722  |                        55.9849 |
|           3 | QSO      | SGC      | 1.6-2.1 |   123696 |   18745654 |  0.0267847  | 188.904   |  -22.6415 |       0.833433 |              1 |   0.981204 |         0.329734  |                        34.5459 |
|           4 | QSO      | SGC      | 0.8-1.2 |    72742 |   11016448 |  0.0269636  |  13.4851  |   12.2104 |       0.846031 |              1 |   0.981204 |         0.538092  |                        39.9692 |
|           5 | QSO      | SGC      | 2.1-3.5 |   129254 |   19573058 |  0.0164248  | 276.418   |  -14.0358 |       0.913217 |              1 |   0.981204 |         0.659668  |                        76.9017 |
|           6 | QSO      | NGC      | 1.6-2.1 |   230514 |   33738763 |  0.010364   |   5.16799 |   25.4611 |       0.932414 |              1 |   0.981204 |         0.554489  |                        35.3034 |
|           7 | QSO      | NGC      | 2.1-3.5 |   237306 |   34740210 |  0.00836338 | 358.632   |   30.3715 |       0.946611 |              1 |   0.981204 |         0.70186   |                        35.4387 |
|           8 | QSO      | NGC      | 1.2-1.6 |   191793 |   28090342 |  0.00656099 |  53.7285  |   57.7521 |       0.981204 |              1 |   0.981204 |         0.84783   |                        72.5152 |

## Interpretation

No directional claim should be made from local p-values without accounting for the
number of tracer, region, redshift, resolution, weight, and split tests that were tried.
Poisson p-values are shot-noise diagnostics only; the permutation p-value is the
first-pass null statistic used for this correction table.
