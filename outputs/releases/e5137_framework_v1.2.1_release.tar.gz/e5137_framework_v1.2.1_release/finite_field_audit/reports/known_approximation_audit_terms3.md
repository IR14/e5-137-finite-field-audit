# Known-Approximation Audit

This is an anti-numerology diagnostic. It asks whether numerical
agreement can be reproduced by ordinary continued-fraction approximations
or by a small dictionary of common `e`/`pi` expressions with small integer
coefficients.

The audit does not validate or refute a physical model by itself. Its role
is to flag when ppm-level agreement is not surprising under simple
approximation mechanisms.

## Setup

- random targets per range: `2000`
- continued-fraction denominator grid: `[10, 100, 1000, 10000, 100000]`
- dictionary terms per expression: up to `3`
- dictionary basis: `1`, `e`, `pi`, `pi/e`, `e/pi`, `pi-e`, `e*pi`,
  `pi^2`, `e^2`, `e^pi`, `pi^e`, `log(137)`, `sqrt(137)`, `1/e`, `1/pi`
- integer coefficients: `0`, `±1`, `±2`, `±3`, `±5`, `±13`, `±26`, `±137`

## Continued-Fraction Summary

Best rational approximations at the largest tested denominator bound:

| target                        | best_fraction   |   observed_ppm |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p01 |
|:------------------------------|:----------------|---------------:|-----------------------------:|--------------------:|-----------------:|
| alpha_inv                     | 6581702/48029   |    8.2588e-07  |                     0.61919  |         6.28895e-07 |      1.45127e-08 |
| delta_alpha_inv_minus_137     | 1729/48029      |    0.00314392  |                     0.5997   |         0.00226094  |      4.10537e-05 |
| muon_to_electron_mass_ratio   | 18454276/89251  |    7.26322e-07 |                     0.737631 |         4.21414e-07 |      5.85656e-09 |
| tau_to_electron_mass_ratio    | 240568561/69184 |    2.65481e-08 |                     0.532234 |         2.43593e-08 |      6.42766e-10 |
| proton_to_electron_mass_ratio | 33482244/18235  |    1.17888e-07 |                     0.849575 |         4.72855e-08 |      7.51833e-10 |
| q_operator                    | 532/60041       |    0.00461598  |                     0.388806 |         0.00648529  |      0.000155765 |
| T5_operator                   | 1909/12973      |    0.00202889  |                     0.858571 |         0.000605189 |      1.07181e-05 |

## e/pi Dictionary Hits

| target                        |         value | best_expression              |    best_value |   observed_ppm |   max_terms |
|:------------------------------|--------------:|:-----------------------------|--------------:|---------------:|------------:|
| alpha_inv                     |  137.036      | 3*pi^2 + 5*e^pi + -26*1/pi   |  137.036      |        1.60719 |           3 |
| delta_alpha_inv_minus_137     |    0.0359991  | -5*e + -1*e*pi + 3*e^2       |    0.0360249  |      718.013   |           3 |
| muon_to_electron_mass_ratio   |  206.768      | 1*pi^2 + 26*e^2 + 13*1/e     |  206.767      |        3.80619 |           3 |
| tau_to_electron_mass_ratio    | 3477.23       | 137*pi + -26*pi/e + 137*pi^e | 3477.25       |        7.36637 |           3 |
| proton_to_electron_mass_ratio | 1836.15       | 137*pi^2 + 26*e^2 + 13*pi^e  | 1836.22       |       36.837   |           3 |
| q_operator                    |    0.00886061 | -5*1 + 3*pi^2 + -5*log(137)  |    0.00890857 |     5412.97    |           3 |
| T5_operator                   |    0.147152   | -2*e + 3*pi/e + 5*pi-e       |    0.147173   |      140.954   |           3 |

## e/pi Dictionary Random-Target Null

| target                        |   observed_ppm |   random_targets |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p05 |   random_ppm_p01 |   random_ppm_min |
|:------------------------------|---------------:|-----------------:|-----------------------------:|--------------------:|-----------------:|-----------------:|-----------------:|
| alpha_inv                     |        1.60719 |             2000 |                     0.378811 |             2.36644 |         0.208264 |        0.0506145 |       0.00159858 |
| delta_alpha_inv_minus_137     |      718.013   |             2000 |                     0.237881 |          1760.41    |       133.535    |       20.3567    |       1.27098    |
| muon_to_electron_mass_ratio   |        3.80619 |             2000 |                     0.565217 |             3.18455 |         0.233739 |        0.049203  |       0.00333962 |
| tau_to_electron_mass_ratio    |        7.36637 |             2000 |                     0.333833 |            12.472   |         0.926161 |        0.165323  |       0.00566158 |
| proton_to_electron_mass_ratio |       36.837   |             2000 |                     0.761119 |            17.7874  |         1.36545  |        0.357994  |       0.0379146  |
| q_operator                    |     5412.97    |             2000 |                     0.548726 |          4706.01    |       257.421    |       55.615     |       1.96794    |
| T5_operator                   |      140.954   |             2000 |                     0.181409 |           494.015   |        37.6355   |        7.19786   |       0.0612267  |

## Interpretation Rule

- A high `empirical_p_random_as_good` means random targets are hit about as
  well as the real target, so the approximation is not strong evidence.
- A low value means the target is less easily matched by this particular
  simple approximation family. This still does not prove physics; it only
  survives this narrow anti-numerology filter.
- Continued fractions are intentionally a harsh warning: arbitrary rational
  coefficients become very powerful very quickly.

## Practical Consequence

Any future symbolic-regression claim should report a comparable null-rate
against random targets and a complexity penalty. Sub-ppm agreement alone
is not a reliable discovery criterion.
