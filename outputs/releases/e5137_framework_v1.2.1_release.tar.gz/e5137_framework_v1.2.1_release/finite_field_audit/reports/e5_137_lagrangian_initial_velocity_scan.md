# e-5-137 initial-velocity scalar scan

Status: canonical scalar stress test with nonzero initial field velocity.

This scan asks whether the previous thawing failure can be repaired by
starting the scalar with kinetic energy at N = ln(a) = -7, while still
shooting Lambda so Omega_phi0 = 0.69 today.

## Target and scan gates

| quantity | value |
|:--|--:|
| project w0 target | -0.751994852742 |
| project wa target | -0.860064969598 |
| required present mu*x' for project w0 | 0.716498886826 |
| w0 hit window | 0.02 |
| early Omega_phi sanity limit for z > 10 | 0.01 |

The early limit is a project sanity cut, not a quoted external constraint.
It is deliberately simple: cases with percent-level dark-energy fraction
well before low redshift are treated as physically suspect until a full
CMB/BBN analysis is supplied.

## Best rows by w0

| variant               | mu_label       |   initial_mu_xprime |   w0_integrated |   wa_from_present_derivative |   mu_xprime0 |   max_omega_phi_z_gt_10 | passes_early_sanity   |
|:----------------------|:---------------|--------------------:|----------------:|-----------------------------:|-------------:|------------------------:|:----------------------|
| q_delta_137_1over1372 | project_slope  |               -1.8  |       -0.920824 |                  -0.183371   |   -0.404838  |              0.54       | False                 |
| q_delta               | project_slope  |                2.2  |       -0.976997 |                  -0.00995603 |    0.21821   |              0.806667   | False                 |
| q_delta               | soft_curvature |                0    |       -0.995835 |                  -0.00526015 |    0.0928539 |              0.00167082 | True                  |
| q_delta               | soft_curvature |                1.4  |       -0.996206 |                  -0.00482332 |   -0.0886235 |              0.326667   | False                 |
| q_delta               | soft_curvature |               -1.4  |       -0.996316 |                  -0.00470518 |   -0.0873321 |              0.326667   | False                 |
| q_delta               | soft_curvature |               -0.25 |       -0.996434 |                  -0.00465145 |    0.0859114 |              0.0104167  | False                 |
| q_delta               | project_slope  |                0.5  |       -0.996815 |                   0.0416743  |   -0.0812024 |              0.0416667  | False                 |
| q_delta               | soft_curvature |                0.25 |       -0.996998 |                  -0.00365559 |    0.0788361 |              0.0104167  | False                 |
| q_delta               | soft_curvature |               -2.2  |       -0.997075 |                  -0.00387037 |    0.0778127 |              0.806667   | False                 |
| q_delta               | project_slope  |               -0.75 |       -0.997105 |                   0.0520883  |    0.0774179 |              0.09375    | False                 |
| q_delta               | project_slope  |               -1.4  |       -0.997147 |                   0.0417315  |   -0.0768521 |              0.326667   | False                 |
| q_delta               | project_slope  |               -0.25 |       -0.99729  |                   0.0504289  |    0.0748918 |              0.0104167  | False                 |

## Best rows that pass early sanity

| variant               | mu_label       |   initial_mu_xprime |   w0_integrated |   wa_from_present_derivative |   mu_xprime0 |   max_omega_phi_z_gt_10 |   w0_abs_error |
|:----------------------|:---------------|--------------------:|----------------:|-----------------------------:|-------------:|------------------------:|---------------:|
| q_delta               | soft_curvature |                   0 |       -0.995835 |                 -0.00526015  |    0.0928539 |              0.00167082 |       0.24384  |
| q_delta               | project_slope  |                   0 |       -0.997343 |                  0.0263381   |   -0.0741558 |              0.00175852 |       0.245349 |
| q_delta_137_1over1372 | soft_curvature |                   0 |       -0.997489 |                 -0.00311141  |    0.07209   |              0.00166696 |       0.245495 |
| q_delta_137_1over1372 | project_slope  |                   0 |       -0.997642 |                  0.0357462   |   -0.0698691 |              0.00176424 |       0.245647 |
| q_delta_137_1over137  | soft_curvature |                   0 |       -0.999174 |                 -0.00104357  |    0.0413489 |              0.0016628  |       0.247179 |
| q_delta_137_1over137  | project_slope  |                   0 |       -0.999871 |                  6.10946e-05 |   -0.0163373 |              0.00167863 |       0.247876 |

## Rows inside the w0 window

_No rows._

## Gate result

No scanned canonical-scalar case both reaches the project w0 window
and passes the early-Omega sanity cut.

The canonical route therefore remains blocked in this first pass:
adding initial kinetic energy can move w0 away from -1, but the
price is early scalar energy that is too large for a clean
dark-energy interpretation without a much more detailed early-universe
model.

## Next mechanism choice

If this gate stays closed under a finer scan, the next model class should
not be another cosine-only canonical scalar. The natural next candidates
are k-essence, a coupled two-field dark sector, or moving the 137
structure into a massive spectator/vector sector rather than directly
into the quintessence potential.
