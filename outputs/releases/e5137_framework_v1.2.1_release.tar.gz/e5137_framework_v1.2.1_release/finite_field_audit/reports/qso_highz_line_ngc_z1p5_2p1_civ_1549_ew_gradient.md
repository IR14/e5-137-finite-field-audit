# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 266722
- finite residual rows: 266722
- observable: `CIV_1549_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.831954
- axis RA: 23.369 deg
- axis DEC: -26.754 deg
- fitted pixels: 633
- block-null p-value: 0.8163672654690619
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_civ_1549_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    281436 |           8848 |                      5866 |                          0 |    266722 |       14714 | CIV_1549_EW         |       0.946861 |        269.365 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   35.4303     |
| z                     |  -16.6629     |
| z2                    |   15.2052     |
| LOGMSTAR              |   -6.38721    |
| RCHI2_LINE            |   -0.37912    |
| DELTA_LINECHI2        |   -0.304961   |
| FLUX_SYNTH_G          |    4.02092    |
| FLUX_SYNTH_R          |   -9.46196    |
| FLUX_SYNTH_Z          |    3.95766    |
| FLUX_G                |    1.85867    |
| FLUX_R                |   -0.789426   |
| FLUX_Z                |   -0.131257   |
| FLUX_W1               |    3.42395    |
| FLUX_W2               |   -2.82672    |
| template_0_ebv        |   -0.226596   |
| template_1_stardens   |   -0.237325   |
| template_2_galdepth_g |   -0.00968927 |
| template_3_galdepth_r |   -0.0151517  |
| template_4_galdepth_z |    0.249779   |
| template_5_psfsize_g  |    0.765851   |
| template_6_psfsize_r  |    0.197758   |
| template_7_psfsize_z  |   -0.211424   |
| template_8_cosky_g    |    0.391203   |
| template_9_cosky_r    |   -2.06686    |
| template_10_cosky_z   |    0.6446     |

## Figures

- `outputs/figures/qso_highz_line_ngc_z1p5_2p1_civ_1549_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_ngc_z1p5_2p1_civ_1549_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
