# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 142895
- finite residual rows: 142895
- observable: `CIV_1549_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.62578
- axis RA: 341.211 deg
- axis DEC: -0.809 deg
- fitted pixels: 355
- block-null p-value: 0.9880239520958084
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_civ_1549_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    151020 |           4995 |                      3130 |                          0 |    142895 |        8125 | CIV_1549_EW         |       0.954208 |        271.925 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    34.6823    |
| z                     |   -13.1608    |
| z2                    |    11.2222    |
| LOGMSTAR              |    -6.23104   |
| RCHI2_LINE            |    -0.123851  |
| DELTA_LINECHI2        |    -0.381209  |
| FLUX_SYNTH_G          |     5.69053   |
| FLUX_SYNTH_R          |   -13.8121    |
| FLUX_SYNTH_Z          |     6.79028   |
| FLUX_G                |     1.16408   |
| FLUX_R                |     1.48454   |
| FLUX_Z                |    -1.71432   |
| FLUX_W1               |     3.66908   |
| FLUX_W2               |    -2.90757   |
| template_0_ebv        |    -0.0316017 |
| template_1_stardens   |    -0.14714   |
| template_2_galdepth_g |     0.0560859 |
| template_3_galdepth_r |     0.385793  |
| template_4_galdepth_z |    -0.373658  |
| template_5_psfsize_g  |     0.146004  |
| template_6_psfsize_r  |    -0.123782  |
| template_7_psfsize_z  |    -0.0796757 |
| template_8_cosky_g    |    -0.168345  |
| template_9_cosky_r    |     0.20183   |
| template_10_cosky_z   |    -0.148923  |

## Figures

- `outputs/figures/qso_highz_line_sgc_z1p5_2p1_civ_1549_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_sgc_z1p5_2p1_civ_1549_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
