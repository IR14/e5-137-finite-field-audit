# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |             2 |             0.00714767 |       0.0898115 |          0.0607878 |                0.370126  |             0.0850716 |                0.0763847 |                      0.380324  |                           0.947223 |                           8.34483 |
| ELG      | SGC      |     1.1 |     1.4 |             2 |             0.00342322 |       0.0733176 |          0.163567  |                0.0233953 |             0.0775923 |                0.130374  |                      0.0179964 |                           1.0583   |                           2.63864 |
| ELG      | SGC      |     1.4 |     1.6 |             2 |             0.00698961 |       0.0659999 |          0.405719  |                0.090182  |             0.0616205 |                0.461908  |                      0.172765  |                           0.933646 |                           9.14474 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term             |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------|--------------:|
| ELG      | SGC      |     0.8 |     1.1 | intercept        |   -0.00539894 |
| ELG      | SGC      |     0.8 |     1.1 | ntile            |    0.0111359  |
| ELG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles |   -0.00433217 |
| ELG      | SGC      |     1.1 |     1.4 | intercept        |    0.00426612 |
| ELG      | SGC      |     1.1 |     1.4 | ntile            |    0.0111353  |
| ELG      | SGC      |     1.1 |     1.4 | frac_tlobs_tiles |   -0.0169407  |
| ELG      | SGC      |     1.4 |     1.6 | intercept        |   -0.00832854 |
| ELG      | SGC      |     1.4 |     1.6 | ntile            |   -0.0236007  |
| ELG      | SGC      |     1.4 |     1.6 | frac_tlobs_tiles |    0.0351355  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
