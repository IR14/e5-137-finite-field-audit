# DESI FastSpecFit DN4000_MODEL binned residual-gradient sweep

Raw DN4000 has extreme tails in the downloaded FastSpecFit VAC, so this run uses DN4000_MODEL as the cleaner first-pass D4000 proxy. This remains a diagnostic estimator, not a detection claim.

- summary CSV: `outputs/tables/desi_fastspecfit_gradient_bins_dn4000_model_summary.csv`

| tracer   | region   |   z_min |   z_max |   n_joined |   amplitude |    ra_deg |   dec_deg |   n_pixels | report_path                                                                                |
|:---------|:---------|--------:|--------:|-----------:|------------:|----------:|----------:|-----------:|:-------------------------------------------------------------------------------------------|
| LRG      | NGC      |     0.4 |     0.6 |     346759 |  0.0155719  | 346.626   |  74.6462  |        643 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_model_z0p4_0p6.md |
| LRG      | NGC      |     0.6 |     0.8 |     533954 |  0.00374655 |   2.27188 |  19.7909  |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_model_z0p6_0p8.md |
| LRG      | NGC      |     0.8 |     1.1 |     595418 |  0.00600394 | 168.704   |  48.8918  |        644 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_model_z0p8_1p1.md |
| LRG      | SGC      |     0.4 |     0.6 |     160150 |  0.0241498  |  14.9389  |  86.3022  |        362 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_model_z0p4_0p6.md |
| LRG      | SGC      |     0.6 |     0.8 |     237939 |  0.0106073  |  43.61    |  78.9407  |        366 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_model_z0p6_0p8.md |
| LRG      | SGC      |     0.8 |     1.1 |     264403 |  0.0149726  |  14.2216  | -31.4774  |        367 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_model_z0p8_1p1.md |
| ELG      | NGC      |     0.8 |     1.1 |     766480 |  0.00199377 | 300.962   |  73.5989  |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_model_z0p8_1p1.md |
| ELG      | NGC      |     1.1 |     1.3 |     490230 |  0.00239694 | 220.342   |  68.5849  |        638 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_model_z1p1_1p3.md |
| ELG      | NGC      |     1.3 |     1.6 |     564607 |  0.00173559 | 272.177   |  70.809   |        637 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_model_z1p3_1p6.md |
| ELG      | SGC      |     0.8 |     1.1 |     249879 |  0.00309617 | 196.384   |  -6.34484 |        363 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_model_z0p8_1p1.md |
| ELG      | SGC      |     1.1 |     1.3 |     164598 |  0.00450122 | 197.127   |  29.512   |        359 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_model_z1p1_1p3.md |
| ELG      | SGC      |     1.3 |     1.6 |     196263 |  0.00509285 | 192.396   |  33.2879  |        360 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_model_z1p3_1p6.md |

## Figures

- `outputs/figures/desi_fastspecfit_bins_dn4000_model_amplitude_vs_z.png`
