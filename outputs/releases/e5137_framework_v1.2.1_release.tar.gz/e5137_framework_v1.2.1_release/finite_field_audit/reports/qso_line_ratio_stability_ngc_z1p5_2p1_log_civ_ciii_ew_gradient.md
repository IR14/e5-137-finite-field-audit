# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 258497
- finite residual rows: 258497
- observable: `LOG_CIV_CIII_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00922732
- axis RA: 54.478 deg
- axis DEC: -25.906 deg
- fitted pixels: 632
- block-null p-value: 0.9720558882235529
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_ciii_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    281436 |           8848 |                         14091 |                          0 |    258497 |       22939 | LOG_CIV_CIII_EW     |       -2.34514 |        6.06068 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.04694     |
| z                     |  -0.229643    |
| z2                    |   0.158761    |
| LOGMSTAR              |  -0.074908    |
| RCHI2_LINE            |   0.000118814 |
| DELTA_LINECHI2        |  -0.00321792  |
| FLUX_SYNTH_G          |   0.189182    |
| FLUX_SYNTH_R          |  -0.251565    |
| FLUX_SYNTH_Z          |   0.0857558   |
| FLUX_G                |  -0.0440964   |
| FLUX_R                |   0.0756939   |
| FLUX_Z                |  -0.0267223   |
| FLUX_W1               |   0.0368878   |
| FLUX_W2               |  -0.0588503   |
| template_0_ebv        |   0.0020611   |
| template_1_stardens   |  -0.00135923  |
| template_2_galdepth_g |  -0.00264845  |
| template_3_galdepth_r |   0.0103484   |
| template_4_galdepth_z |  -0.00226583  |
| template_5_psfsize_g  |   0.00800149  |
| template_6_psfsize_r  |  -0.00617698  |
| template_7_psfsize_z  |  -0.00189524  |
| template_8_cosky_g    |  -0.00240742  |
| template_9_cosky_r    |   0.00618861  |
| template_10_cosky_z   |  -0.00375832  |

## Figures

- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_civ_ciii_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_civ_ciii_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
