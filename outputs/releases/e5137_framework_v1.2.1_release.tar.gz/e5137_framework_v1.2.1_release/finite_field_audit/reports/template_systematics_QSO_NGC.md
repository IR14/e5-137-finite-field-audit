# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| QSO      | NGC      |     0.8 |     1.2 |            19 |              0.0465223 |      0.0194676  |           0.878624 |                 0.506247 |            0.0046078  |                 0.997401 |                       0.975512 |                           0.236691 |                           81.4331 |
| QSO      | NGC      |     1.2 |     1.6 |            19 |              0.0384154 |      0.00678197 |           0.991002 |                 0.902049 |            0.00738992 |                 0.990802 |                       0.826587 |                           1.08964  |                           35.8714 |
| QSO      | NGC      |     1.6 |     2.1 |            19 |              0.0338321 |      0.0101251  |           0.954409 |                 0.656672 |            0.00256707 |                 0.9998   |                       0.984508 |                           0.253536 |                           84.8475 |
| QSO      | NGC      |     2.1 |     3.5 |            19 |              0.0246013 |      0.00850963 |           0.973005 |                 0.570215 |            0.00177431 |                 0.9996   |                       0.987506 |                           0.208506 |                           86.6568 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| QSO      | NGC      |     0.8 |     1.2 | intercept                          |   0.00505411  |
| QSO      | NGC      |     0.8 |     1.2 | photsys=N                          |   0.42435     |
| QSO      | NGC      |     0.8 |     1.2 | ntile                              |  -0.00328881  |
| QSO      | NGC      |     0.8 |     1.2 | frac_tlobs_tiles                   |  -0.00895119  |
| QSO      | NGC      |     0.8 |     1.2 | nx                                 |  -0.00175738  |
| QSO      | NGC      |     0.8 |     1.2 | weight_sys                         |   0.0672549   |
| QSO      | NGC      |     0.8 |     1.2 | weight_rf                          |   0.0672549   |
| QSO      | NGC      |     0.8 |     1.2 | weight_zfail                       |   0.206831    |
| QSO      | NGC      |     0.8 |     1.2 | weight_comp                        |  -0.0891603   |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_ebv        |  -0.00170555  |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_stardens   |  -0.00893422  |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_g |   0.0130518   |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_r |   0.0191424   |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_z |  -0.00522668  |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_g  |   0.014965    |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_r  |  -0.00793595  |
| QSO      | NGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_z  |   0.00311167  |
| QSO      | NGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_g |   0.0114278   |
| QSO      | NGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_r |   0.0146038   |
| QSO      | NGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_z |  -0.00239946  |
| QSO      | NGC      |     1.2 |     1.6 | intercept                          |   0.00336775  |
| QSO      | NGC      |     1.2 |     1.6 | photsys=N                          |   0.26322     |
| QSO      | NGC      |     1.2 |     1.6 | ntile                              |  -0.00607554  |
| QSO      | NGC      |     1.2 |     1.6 | frac_tlobs_tiles                   |  -0.00978275  |
| QSO      | NGC      |     1.2 |     1.6 | nx                                 |   0.00609713  |
| QSO      | NGC      |     1.2 |     1.6 | weight_sys                         |   0.0153484   |
| QSO      | NGC      |     1.2 |     1.6 | weight_rf                          |   0.0153484   |
| QSO      | NGC      |     1.2 |     1.6 | weight_zfail                       |   0.208991    |
| QSO      | NGC      |     1.2 |     1.6 | weight_comp                        |  -0.0870987   |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_ebv        |   0.00296292  |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_stardens   |  -0.00179446  |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_g |   0.017657    |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_r |  -0.0203384   |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_z |   0.00415893  |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_g  |   0.00962266  |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00243704  |
| QSO      | NGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_z  |  -0.00156541  |
| QSO      | NGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_g |   0.00471307  |
| QSO      | NGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_r |  -0.018802    |
| QSO      | NGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_z |   0.00222698  |
| QSO      | NGC      |     1.6 |     2.1 | intercept                          |   0.00189511  |
| QSO      | NGC      |     1.6 |     2.1 | photsys=N                          |  -0.360673    |
| QSO      | NGC      |     1.6 |     2.1 | ntile                              |  -0.0176716   |
| QSO      | NGC      |     1.6 |     2.1 | frac_tlobs_tiles                   |  -0.00678492  |
| QSO      | NGC      |     1.6 |     2.1 | nx                                 |   0.0160471   |
| QSO      | NGC      |     1.6 |     2.1 | weight_sys                         |   0.0793201   |
| QSO      | NGC      |     1.6 |     2.1 | weight_rf                          |   0.0793201   |
| QSO      | NGC      |     1.6 |     2.1 | weight_zfail                       |  -0.176883    |
| QSO      | NGC      |     1.6 |     2.1 | weight_comp                        |  -0.00107464  |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_ebv        |   0.00255756  |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_stardens   |  -0.0061503   |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_g |  -0.0138644   |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_r |   0.0068936   |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_z |   0.00589428  |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_g  |   0.00862763  |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_r  |  -0.000726011 |
| QSO      | NGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_z  |  -0.00170262  |
| QSO      | NGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_g |   0.0243164   |
| QSO      | NGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_r |   0.00178002  |
| QSO      | NGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_z |  -0.0175838   |
| QSO      | NGC      |     2.1 |     3.5 | intercept                          |   0.00320597  |
| QSO      | NGC      |     2.1 |     3.5 | photsys=N                          |  -0.0402535   |
| QSO      | NGC      |     2.1 |     3.5 | ntile                              |   0.00249681  |
| QSO      | NGC      |     2.1 |     3.5 | frac_tlobs_tiles                   |   0.000546529 |
| QSO      | NGC      |     2.1 |     3.5 | nx                                 |  -0.00692471  |
| QSO      | NGC      |     2.1 |     3.5 | weight_sys                         |   0.0405494   |
| QSO      | NGC      |     2.1 |     3.5 | weight_rf                          |   0.0405494   |
| QSO      | NGC      |     2.1 |     3.5 | weight_zfail                       |  -0.161685    |
| QSO      | NGC      |     2.1 |     3.5 | weight_comp                        |  -0.026343    |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_ebv        |   0.000862332 |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_stardens   |   0.0041045   |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_g |   0.00238992  |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_r |  -0.000549139 |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_z |  -0.00612994  |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_g  |  -0.00506285  |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_r  |   0.00174249  |
| QSO      | NGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_z  |  -0.000100425 |
| QSO      | NGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_g |  -0.0176602   |
| QSO      | NGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_r |  -0.00111677  |
| QSO      | NGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_z |   0.0111768   |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
