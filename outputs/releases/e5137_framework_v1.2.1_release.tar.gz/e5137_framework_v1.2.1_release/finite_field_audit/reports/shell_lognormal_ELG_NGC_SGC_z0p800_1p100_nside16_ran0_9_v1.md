# Redshift-shell lognormal mock calibration

- Tracer: `ELG`
- Regions: `NGC+SGC`
- Redshift range: `0.8-1.1`
- Nside: 16
- Mocks: 1000

This tuned 3D-ish mock backend preserves the DESI random-catalog angular
and redshift selection by generating a lognormal density field in redshift
shells, Poisson sampling each shell, summing the shell maps, and running
the same dipole/template-regression estimator as for the data.

It is stronger than a purely angular or Poisson-only null, but it is still
not an official DESI covariance product.

## Shell selection

|   shell |   z_min |   z_max |   data_rows |   random_rows |     alpha |
|--------:|--------:|--------:|------------:|--------------:|----------:|
|       0 |    0.8  |    0.85 |      139957 |   8.57384e+06 | 0.0209755 |
|       1 |    0.85 |    0.9  |      164133 |   1.00186e+07 | 0.020902  |
|       2 |    0.9  |    0.95 |      178925 |   1.09381e+07 | 0.0208825 |
|       3 |    0.95 |    1    |      179756 |   1.09801e+07 | 0.0208741 |
|       4 |    1    |    1.05 |      180830 |   1.10085e+07 | 0.0208839 |
|       5 |    1.05 |    1.1  |      172764 |   1.05253e+07 | 0.0209054 |

## Summary

| mock_family              | tracer   | regions   |   z_min |   z_max |   nside |   shells | z_edges                      | sigma_label   |   sigma_lognormal |   radial_corr |   smoothing_deg |   cl_slope | stage                              |   n_mocks |   n_templates | external_templates                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | weight_mode   |   n_data |   n_random |   null_amplitude_median |   null_amplitude_p68 |   null_amplitude_p95 |   null_amplitude_p99 |   observed_amplitude |   observed_ra_deg |   observed_dec_deg |   observed_empirical_p_value |
|:-------------------------|:---------|:----------|--------:|--------:|--------:|---------:|:-----------------------------|:--------------|------------------:|--------------:|----------------:|-----------:|:-----------------------------------|----------:|--------------:|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|:--------------|---------:|-----------:|------------------------:|---------------------:|---------------------:|---------------------:|---------------------:|------------------:|-------------------:|-----------------------------:|
| redshift_shell_lognormal | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 |        6 | 0.8,0.85,0.9,0.95,1,1.05,1.1 | auto          |          0.112889 |          0.05 |               8 |        1.4 | after_external_template_regression |      1000 |            11 | pixweight_dark_ebv=data/external/templates/pixweight_dark_ebv_nside16_ring.npz,pixweight_dark_stardens=data/external/templates/pixweight_dark_stardens_nside16_ring.npz,pixweight_dark_galdepth_g=data/external/templates/pixweight_dark_galdepth_g_nside16_ring.npz,pixweight_dark_galdepth_r=data/external/templates/pixweight_dark_galdepth_r_nside16_ring.npz,pixweight_dark_galdepth_z=data/external/templates/pixweight_dark_galdepth_z_nside16_ring.npz,pixweight_dark_psfsize_g=data/external/templates/pixweight_dark_psfsize_g_nside16_ring.npz,pixweight_dark_psfsize_r=data/external/templates/pixweight_dark_psfsize_r_nside16_ring.npz,pixweight_dark_psfsize_z=data/external/templates/pixweight_dark_psfsize_z_nside16_ring.npz,legacy_dr9_bricks_cosky_g=data/external/templates/legacy_dr9_bricks_cosky_g_nside16_ring.npz,legacy_dr9_bricks_cosky_r=data/external/templates/legacy_dr9_bricks_cosky_r_nside16_ring.npz,legacy_dr9_bricks_cosky_z=data/external/templates/legacy_dr9_bricks_cosky_z_nside16_ring.npz | desi          |  1016365 |   62044406 |               0.0260917 |            0.0329456 |            0.0595109 |            0.0737467 |            0.0229974 |           222.055 |           -71.6975 |                     0.592408 |
| redshift_shell_lognormal | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 |        6 | 0.8,0.85,0.9,0.95,1,1.05,1.1 | auto          |          0.112889 |          0.05 |               8 |        1.4 | raw_no_template_regression         |      1000 |            11 | pixweight_dark_ebv=data/external/templates/pixweight_dark_ebv_nside16_ring.npz,pixweight_dark_stardens=data/external/templates/pixweight_dark_stardens_nside16_ring.npz,pixweight_dark_galdepth_g=data/external/templates/pixweight_dark_galdepth_g_nside16_ring.npz,pixweight_dark_galdepth_r=data/external/templates/pixweight_dark_galdepth_r_nside16_ring.npz,pixweight_dark_galdepth_z=data/external/templates/pixweight_dark_galdepth_z_nside16_ring.npz,pixweight_dark_psfsize_g=data/external/templates/pixweight_dark_psfsize_g_nside16_ring.npz,pixweight_dark_psfsize_r=data/external/templates/pixweight_dark_psfsize_r_nside16_ring.npz,pixweight_dark_psfsize_z=data/external/templates/pixweight_dark_psfsize_z_nside16_ring.npz,legacy_dr9_bricks_cosky_g=data/external/templates/legacy_dr9_bricks_cosky_g_nside16_ring.npz,legacy_dr9_bricks_cosky_r=data/external/templates/legacy_dr9_bricks_cosky_r_nside16_ring.npz,legacy_dr9_bricks_cosky_z=data/external/templates/legacy_dr9_bricks_cosky_z_nside16_ring.npz | desi          |  1016365 |   62044406 |               0.0603492 |            0.073256  |            0.109751  |            0.144184  |            0.0326834 |           204.166 |           -72.2818 |                     0.867133 |

## Interpretation

- Use this as a local tuned 3D sanity check while official DESI mocks are
being downloaded or staged.
- A final cosmology-grade p-value should be based on many official EZmock
or AbacusSummit realizations processed through the same pipeline.
