# Phase 4 modular number-theory scan

This report initializes the pure theoretical-number audit requested for Phase 4.
It is an exploratory symbolic-regression scan, not a physical derivation.

## Fixed Constants

- prime modulus: `137`
- Euler phi: `phi(137) = 136`
- decomposition: `136 = 26*5 + 6`
- `q = 0.0088606118742908732`
- `T5 = 0.14715177646857694`
- target `alpha^-1 = 137.035999084000`
- target `Kp = Mp/me = 1836.15267343000`
- out-of-sample target `a_mu = 0.0011659207`

## Best Alpha Candidate

- expression: `137 + (3*q + inv5*T5*s + 13*s^2)`
- value: `137.035999063763`
- ppm error: `0.000147674`
- complexity: `10`
- threshold `<0.01 ppm`: `pass`

## Best Proton-Ratio Candidate: Strict Grammar

- expression: `alpha_inv*(phi/(2N) + -26*q + -inv13*q*T5 + 26*q^2)`
- value: `1836.15169801960`
- ppm error: `0.531225`
- complexity: `14`
- threshold `<0.5 ppm`: `failed`

## Best Proton-Ratio Candidate: Wide Grammar

This allows one additional correction term. It is useful as a boundary test,
but its complexity is high enough that it should be treated as a numerical
hit, not as a derivation.

- expression: `alpha_inv*(13 + inv3*q + -inv26*T5*s + -inv13*q*s + 1*s)`
- value: `1836.15264991785`
- ppm error: `0.0128051`
- complexity: `16`
- threshold `<0.5 ppm`: `pass`

## Out-of-Sample Muon Anomaly

- best pre-declared projection: `s*(1+s)  [alpha=137 + (3*q + inv5*T5*s + 13*s^2); Kp=alpha_inv*(13 + inv3*q + -inv26*T5*s + -inv13*q*s + 1*s)]`
- value: `0.001162758606`
- ppm error: `2712.1`
- threshold `<500 ppm`: `failed`

## Verdict

The Phase 4 grammar did not survive the out-of-sample gate. Alpha and Kp may admit numerical hits in the chosen grammar, but the frozen operators do not predict the muon anomaly at the required level.

## Tables

- `outputs/tables/phase4_modular_alpha_hits.csv`
- `outputs/tables/phase4_modular_kp_hits.csv`
- `outputs/tables/phase4_modular_kp_wide_hits.csv`
- `outputs/tables/phase4_modular_amu_oos.csv`
