# Multipole diagnostics

- Map: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_combined_map.npz`

This diagnostic compares the standard dipole-only fit with a fit that also
marginalizes over five quadrupole-like angular templates. If the dipole amplitude
or axis changes strongly, the candidate is likely entangled with broader footprint
or low-order angular structure rather than behaving as an isolated dipole.

## Summary

| model                  |   dipole_amplitude |   ra_deg |   dec_deg |   monopole |   n_pixels |   weighted_r2 |   residual_std |   weighted_design_condition |   quadrupole_norm |   axis_shift_from_dipole_only_deg |   amplitude_ratio_to_dipole_only |
|:-----------------------|-------------------:|---------:|----------:|-----------:|-----------:|--------------:|---------------:|----------------------------:|------------------:|----------------------------------:|---------------------------------:|
| dipole_only            |          0.0328003 |  204.33  |  -72.2938 | 0.00249846 |       3602 |   nan         |     nan        |                    nan      |         0         |                            0      |                          1       |
| dipole_plus_quadrupole |          0.0609946 |  237.364 |  -79.7118 | 0.0153491  |       3602 |     0.0185072 |       0.182771 |                     28.2765 |         0.0686588 |                           10.6265 |                          1.85957 |

## Coefficients

| model                  | term     |   coefficient |
|:-----------------------|:---------|--------------:|
| dipole_plus_quadrupole | monopole |    0.0153491  |
| dipole_plus_quadrupole | dipole_x |   -0.00587496 |
| dipole_plus_quadrupole | dipole_y |   -0.00917361 |
| dipole_plus_quadrupole | dipole_z |   -0.0600139  |
| dipole_plus_quadrupole | q_xx     |   -0.0347639  |
| dipole_plus_quadrupole | q_yy     |   -0.0415615  |
| dipole_plus_quadrupole | q_xy     |    0.00238863 |
| dipole_plus_quadrupole | q_xz     |   -0.0337822  |
| dipole_plus_quadrupole | q_yz     |    0.0251237  |
