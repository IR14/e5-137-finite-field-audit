# Phase 5 Fourth-Neutrino Final Closure

## Formula

The proposed sterile fourth-generation neutrino benchmark is

```text
m_nu_tau_prime = m_e * (F26 / alpha^-1)
                 * [1 + (DN / pi) * delta_phi * (1 - s)]

delta_phi = cos(1/N) - cos(2/N)
s = alpha / (2*pi)
N = 5
D = 26
F26 = 121393
```

## Numerical Result

| quantity | value |
|---|---:|
| s | 0.001161409732886 |
| delta_phi | 0.059005583838357 |
| bracket | 3.438832111003972 |
| m_nu_tau_prime [eV] | 1556646342.769707 |
| m_nu_tau_prime [keV] | 1556646.342770 |
| m_nu_tau_prime [MeV] | 1556.646342770 |
| m_nu_tau_prime [GeV] | 1.556646342770 |
| m_nu_tau_prime / m_tau_prime | 0.032828360099 |

## Dark-Matter Plausibility Check

The benchmark lies in the broad GeV-scale sterile-particle mass range:

```text
m_nu_tau_prime = 1.556646342770 GeV
```

This is compatible with a cold-matter mass scale in the purely kinematic sense.
It does not, by itself, establish a viable dark-matter model. Relic abundance,
free-streaming, direct/indirect detection, active-sterile mixing, and lifetime
constraints depend on couplings and production history, which are not specified
by this mass formula.

| check | threshold/range | passes |
|---|---:|---:|
| broad sterile keV-to-TeV benchmark window | 1 keV to 1 TeV | True |
| Z-width-scale active-neutrino threshold | 45.0 GeV | False |

The mass is below the Z-width-scale 45 GeV reference. Therefore it cannot be
treated as an ordinary active fourth neutrino with Standard-Model-strength
coupling to the Z boson. If retained, the state must be sterile or otherwise
decoupled from the usual Z-width constraint.

Reference links used for the guardrail:

- PDG Live, stable neutral heavy lepton mass limits:
  https://pdglive.lbl.gov/view/S077MNS
- PDG Live, heavy neutral lepton mass limits:
  https://pdglive.lbl.gov/view/S077MN
- keV sterile-neutrino dark-matter review:
  https://arxiv.org/abs/1602.04816

Status: HARD SHUTDOWN for this extension unless a new pre-registered
experimental or cosmological test is defined.
