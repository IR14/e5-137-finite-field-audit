# DESI FastSpecFit DN4000 gradient validation summary

Status: first observational DN4000 residual-gradient smoke runs completed.

These amplitudes are not detection significances. They are raw residual-map dipole fits after controlling for redshift, redshift squared, and stellar mass, with survey coverage constrained by matching random catalogs. Mock-calibrated p-values are still required.

| run     | tracer   | region   |   n_joined |   amplitude |   ra_deg |   dec_deg | controls      | report_path                                                            |
|:--------|:---------|:---------|-----------:|------------:|---------:|----------:|:--------------|:-----------------------------------------------------------------------|
| elg_ngc | ELG      | NGC      |    1821317 |   0.0514194 |  24.6149 | -34.7469  | z;z2;LOGMSTAR | outputs/reports/desi_fastspecfit_gradient_validation_elg_ngc_dn4000.md |
| elg_sgc | ELG      | SGC      |     610740 |   0.879083  | 359.316  |   4.14711 | z;z2;LOGMSTAR | outputs/reports/desi_fastspecfit_gradient_validation_elg_sgc_dn4000.md |
| lrg_ngc | LRG      | NGC      |    1476131 |   0.0147759 | 199.464  |  -3.05576 | z;z2;LOGMSTAR | outputs/reports/desi_fastspecfit_gradient_validation_lrg_ngc_dn4000.md |
| lrg_sgc | LRG      | SGC      |     662492 |   0.0415953 | 179.047  |  60.6453  | z;z2;LOGMSTAR | outputs/reports/desi_fastspecfit_gradient_validation_lrg_sgc_dn4000.md |

## Immediate scientific read

- LRG NGC and SGC do not point to a common stable axis in this first split-sky check.
- ELG SGC has an unusually large amplitude and should be treated as a systematics/coverage diagnostic target before any physical interpretation.
- The next proper step is to add per-pixel systematics templates and calibrate the estimator on EZmock realizations, using the same join/filter/binning logic.
