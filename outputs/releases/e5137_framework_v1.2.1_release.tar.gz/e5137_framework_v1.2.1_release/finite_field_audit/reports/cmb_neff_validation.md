# CMB N_eff validation and matter-power cutoff

Status: final CMB-facing EFT audit for the sterile fourth-neutrino benchmark.
This report records the arithmetic invariant and its cosmological guardrails;
it does not add a new fitted parameter to the DESI observational pipeline.

## Inputs

| quantity | value |
|:--|--:|
| N | 5 |
| D | 26 |
| q | 0.008860611874290873 |
| delta_phi | 0.05900558383835652 |
| m_nu_tau_prime | 1.5566463427697075 GeV |
| Standard LCDM N_eff | 3.046 |
| comparison window | 2.99 +/- 0.17 |

The comparison window is the Planck 2018 CMB+BAO value quoted for effective
extra relativistic degrees of freedom. ACT DR6 extended-model constraints also
report no evidence for additional free-streaming relativistic species, so the
release criterion is that the model must not require early-Universe reheating.

Sources:

- Planck 2018 cosmological parameters: https://arxiv.org/abs/1807.06209
- Planck Legacy Archive parameter tables: https://wiki.cosmos.esa.int/planck-legacy-archive/index.php/Cosmological_Parameters
- ACT DR6 extended cosmological models: https://arxiv.org/abs/2503.14454

## N_eff invariant

The release invariant is

```text
Delta N_eff = (D / 137) * delta_phi * (1 - q)
```

Numerically:

```text
Delta N_eff = 0.011098917626279356
N_eff_total = 3.046 + Delta N_eff
            = 3.0570989176262793
```

Against the comparison window `2.99 +/- 0.17`,

```text
z_score = (3.0570989176262793 - 2.99) / 0.17
        = 0.39469951544870036
```

Gate result: the contribution is inside one sigma of the release comparison
window and does not produce a large dark-radiation excess.

## Matter power spectrum cutoff

For the sterile benchmark,

```text
m = 1.5566463427697075 GeV
  = 1,556,646.3427697076 keV
```

As a conservative thermal-equivalent scale audit, use

```text
lambda_cut ~= 0.11 * (m / keV)^(-4/3) Mpc
```

which gives

```text
lambda_cut = 6.097325934119188e-10 Mpc
           = 6.097325934119188e-7 kpc
           = 6.097325934119188e-4 pc

k_cut ~= 2*pi/lambda_cut
      = 1.0304821121699224e10 Mpc^-1
```

This cutoff lies far below the release guardrail of `100 kpc`. It is also far
below DESI/BAO and ordinary large-scale-structure wavelengths, so under the
cold or sufficiently nonthermal production assumption the benchmark is
indistinguishable from standard CDM for the DESI null-result scales.

## Guardrail

The mass scale and the `N_eff` invariant do not calculate the relic abundance
or the sterile momentum distribution by themselves. The CDM-like conclusion is
therefore conditional on the already archived sterile/nonthermal-production
guardrail. Within that guardrail, the CMB radiation trace is small and the
free-streaming cutoff is many orders of magnitude below the scales probed by
the DESI DR1 directional-gradient tests.

## Release conclusion

The CMB branch passes the final arithmetic gate:

- `Delta N_eff = 0.011098917626279356`
- `N_eff_total = 3.0570989176262793`
- Planck-window z-score: `0.39469951544870036`
- thermal-equivalent cutoff: `6.097325934119188e-7 kpc`
- LSS/BAO effect: archived as CDM-like under cold/nonthermal production

No new scan branch is opened.
