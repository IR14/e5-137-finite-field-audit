# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 123642
- finite residual rows: 123642
- observable: `CIV_1549_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.541443
- axis RA: 181.244 deg
- axis DEC: 44.024 deg
- fitted pixels: 355
- block-null p-value: 0.9900199600798403
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_civ_1549_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    129254 |           2873 |                      2739 |                          0 |    123642 |        5612 | CIV_1549_EW         |        0.94133 |        192.299 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    30.2781    |
| z                     |   -21.3657    |
| z2                    |    21.0042    |
| LOGMSTAR              |    -4.76662   |
| RCHI2_LINE            |    -0.181831  |
| DELTA_LINECHI2        |     0.0249663 |
| FLUX_SYNTH_G          |     0.59297   |
| FLUX_SYNTH_R          |    -2.12711   |
| FLUX_SYNTH_Z          |    -0.404158  |
| FLUX_G                |     4.45236   |
| FLUX_R                |    -2.07413   |
| FLUX_Z                |    -1.5228    |
| FLUX_W1               |     2.81275   |
| FLUX_W2               |    -1.17599   |
| template_0_ebv        |    -0.263717  |
| template_1_stardens   |    -0.15136   |
| template_2_galdepth_g |    -0.13629   |
| template_3_galdepth_r |    -0.390402  |
| template_4_galdepth_z |     0.0545689 |
| template_5_psfsize_g  |    -0.0874826 |
| template_6_psfsize_r  |     0.240824  |
| template_7_psfsize_z  |    -0.483629  |
| template_8_cosky_g    |    -0.69517   |
| template_9_cosky_r    |     1.26323   |
| template_10_cosky_z   |    -0.350467  |

## Figures

- `outputs/figures/qso_highz_line_sgc_z2p1_3p5_civ_1549_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_sgc_z2p1_3p5_civ_1549_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
