# Clustered lognormal null: ELG NGC+SGC z=0.8-1.1

This report combines the first mask-matched angular lognormal mock runs for the focused ELG low-z case.

## Files

- Combined lognormal summary: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/clustered_lognormal_ELG_NGC_SGC_z0p800_1p100_summary.csv`
- Poisson comparison table: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/clustered_lognormal_vs_poisson_ELG_NGC_SGC_z0p800_1p100.csv`
- Per-nside reports:
  - `outputs/reports/lognormal_mock_calibration_ELG_NGC_SGC_z0p800_1p100_nside16_v1.md`
  - `outputs/reports/lognormal_mock_calibration_ELG_NGC_SGC_z0p800_1p100_nside32_v1.md`

## Lognormal summary

|   nside | sigma_label   |   sigma_lognormal | stage                              |   n_mocks |   null_amplitude_median |   null_amplitude_p95 |   observed_amplitude |   observed_empirical_p_value |
|--------:|:--------------|------------------:|:-----------------------------------|----------:|------------------------:|---------------------:|---------------------:|-----------------------------:|
|      16 | 0.08          |         0.08      | after_external_template_regression |      1000 |               0.0344158 |            0.0751904 |            0.0229974 |                     0.756244 |
|      16 | 0.08          |         0.08      | raw_no_template_regression         |      1000 |               0.0786933 |            0.138338  |            0.0326834 |                     0.949051 |
|      16 | 0.12          |         0.12      | after_external_template_regression |      1000 |               0.0498793 |            0.110937  |            0.0229974 |                     0.917083 |
|      16 | 0.12          |         0.12      | raw_no_template_regression         |      1000 |               0.114835  |            0.190098  |            0.0326834 |                     0.99001  |
|      16 | auto          |         0.0427448 | after_external_template_regression |      1000 |               0.0181492 |            0.0383748 |            0.0229974 |                     0.325674 |
|      16 | auto          |         0.0427448 | raw_no_template_regression         |      1000 |               0.0421121 |            0.0737363 |            0.0326834 |                     0.732268 |
|      32 | 0.08          |         0.08      | after_external_template_regression |      1000 |               0.0393543 |            0.0767632 |            0.0293449 |                     0.716284 |
|      32 | 0.08          |         0.08      | raw_no_template_regression         |      1000 |               0.0783376 |            0.134561  |            0.0328003 |                     0.954046 |
|      32 | 0.12          |         0.12      | after_external_template_regression |      1000 |               0.0581732 |            0.115774  |            0.0293449 |                     0.877123 |
|      32 | 0.12          |         0.12      | raw_no_template_regression         |      1000 |               0.11455   |            0.204303  |            0.0328003 |                     0.979021 |
|      32 | auto          |         0.0640703 | after_external_template_regression |      1000 |               0.0321449 |            0.0657788 |            0.0293449 |                     0.569431 |
|      32 | auto          |         0.0640703 | raw_no_template_regression         |      1000 |               0.064112  |            0.109685  |            0.0328003 |                     0.91009  |

## Poisson versus lognormal-auto

|   nside | stage                              |   observed_amplitude |   poisson_observed_empirical_p_value |   poisson_null_p95 |   lognormal_auto_observed_empirical_p_value |   lognormal_auto_null_p95 |   lognormal_auto_sigma |   p_value_ratio_lognormal_to_poisson |
|--------:|:-----------------------------------|---------------------:|-------------------------------------:|-------------------:|--------------------------------------------:|--------------------------:|-----------------------:|-------------------------------------:|
|      16 | after_external_template_regression |            0.0229974 |                          0.000999001 |         0.00476705 |                                    0.325674 |                 0.0383748 |              0.0427448 |                                  326 |
|      16 | raw_no_template_regression         |            0.0326834 |                          0.000999001 |         0.00815362 |                                    0.732268 |                 0.0737363 |              0.0427448 |                                  733 |
|      32 | after_external_template_regression |            0.0293449 |                          0.000999001 |         0.00547093 |                                    0.569431 |                 0.0657788 |              0.0640703 |                                  570 |
|      32 | raw_no_template_regression         |            0.0328003 |                          0.000999001 |         0.00828715 |                                    0.91009  |                 0.109685  |              0.0640703 |                                  911 |

## Interpretation

- The old Poisson-only calibration produced minimum empirical p-values near 0.001 because it only models shot noise under the survey window.
- The angular lognormal mocks include correlated large-scale structure variance under the same random-catalog selection map.
- Under the auto sigma estimates, the corrected-map p-values are 0.326 at nside16 and 0.569 at nside32.
- Under stronger sigma values 0.08 and 0.12, the observed amplitudes are even more ordinary relative to the null.
- Therefore this focused ELG low-z amplitude is not anomalous under this clustered angular null model.

## Caveat

These are not official DESI mocks. They are a useful intermediate calibration, but a final cosmology-grade statement still needs official DESI-like mocks or a tuned 3D mock pipeline.
