# Axis diagnostics

These diagnostics compare fitted axes with reference directions and with each other.
They are consistency checks only; a small angular separation is not significant unless
the underlying dipole measurement is itself significant under the null model.

## Reference axes

| reference       | tracer   | region   |   z_min |   z_max |   axis_separation_deg |   null_p_value |   amplitude |
|:----------------|:---------|:---------|--------:|--------:|----------------------:|---------------:|------------:|
| cmb_dipole_apex | QSO      | NGC+SGC  |     2.1 |     3.5 |               20.6587 |      0.717257  |  0.00859681 |
| cmb_dipole_apex | QSO      | NGC+SGC  |     1.2 |     1.6 |               53.5393 |      0.89962   |  0.00635337 |
| cmb_dipole_apex | LRG      | NGC+SGC  |     0.6 |     0.8 |               54.6107 |      0.886023  |  0.00824904 |
| cmb_dipole_apex | ELG      | NGC+SGC  |     1.4 |     1.6 |               56.0006 |      0.589482  |  0.0173678  |
| cmb_dipole_apex | ELG      | NGC+SGC  |     1.1 |     1.4 |               59.1949 |      0.0991802 |  0.0271119  |
| cmb_dipole_apex | QSO      | NGC+SGC  |     1.6 |     2.1 |               61.2704 |      0.95041   |  0.00466124 |
| cmb_dipole_apex | QSO      | NGC+SGC  |     0.8 |     1.2 |               68.1547 |      0.440712  |  0.0163706  |
| cmb_dipole_apex | ELG      | NGC+SGC  |     0.8 |     1.1 |               69.0096 |      0.044991  |  0.0328003  |
| cmb_dipole_apex | LRG      | NGC+SGC  |     0.8 |     1.1 |               77.0622 |      0.433913  |  0.0159175  |
| cmb_dipole_apex | LRG      | NGC+SGC  |     0.4 |     0.6 |               78.6853 |      0.922615  |  0.0075235  |

## Cross-tracer consistency

| region   | left_tracer   | right_tracer   |   left_z_min |   left_z_max |   right_z_min |   right_z_max |   z_overlap |   axis_separation_deg |    left_p |   right_p |
|:---------|:--------------|:---------------|-------------:|-------------:|--------------:|--------------:|------------:|----------------------:|----------:|----------:|
| NGC+SGC  | ELG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |                6.9904 | 0.044991  |  0.440712 |
| NGC+SGC  | ELG           | QSO            |          1.1 |          1.4 |           0.8 |           1.2 |         0.1 |               16.7049 | 0.0991802 |  0.440712 |
| NGC+SGC  | LRG           | ELG            |          0.8 |          1.1 |           0.8 |           1.1 |         0.3 |               26.7407 | 0.433913  |  0.044991 |
| NGC+SGC  | LRG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               33.711  | 0.433913  |  0.440712 |
| NGC+SGC  | ELG           | QSO            |          1.1 |          1.4 |           1.2 |           1.6 |         0.2 |               40.3532 | 0.0991802 |  0.89962  |
| NGC+SGC  | ELG           | QSO            |          1.4 |          1.6 |           1.2 |           1.6 |         0.2 |               65.9088 | 0.589482  |  0.89962  |

