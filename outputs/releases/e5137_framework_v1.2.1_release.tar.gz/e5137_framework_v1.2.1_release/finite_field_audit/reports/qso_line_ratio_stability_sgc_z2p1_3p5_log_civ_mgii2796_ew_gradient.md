# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 64977
- finite residual rows: 64977
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0624148
- axis RA: 118.655 deg
- axis DEC: 55.805 deg
- fitted pixels: 349
- block-null p-value: 0.780439121756487
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    129254 |           2873 |                             61404 |                          0 |     64977 |       64277 | LOG_CIV_MGII2796_EW |       -2.34512 |        11.9693 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    1.01241    |
| z                     |    0.664585   |
| z2                    |   -0.790568   |
| LOGMSTAR              |    0.00446813 |
| RCHI2_LINE            |   -0.0124453  |
| DELTA_LINECHI2        |   -0.00162275 |
| FLUX_SYNTH_G          |    0.122291   |
| FLUX_SYNTH_R          |   -0.18012    |
| FLUX_SYNTH_Z          |    0.0330774  |
| FLUX_G                |    0.189783   |
| FLUX_R                |   -0.25347    |
| FLUX_Z                |    0.117479   |
| FLUX_W1               |    0.0180171  |
| FLUX_W2               |   -0.0303255  |
| template_0_ebv        |    0.00646211 |
| template_1_stardens   |   -0.0114688  |
| template_2_galdepth_g |    0.0275845  |
| template_3_galdepth_r |   -0.0655991  |
| template_4_galdepth_z |    0.0342907  |
| template_5_psfsize_g  |    0.00397873 |
| template_6_psfsize_r  |   -0.00268984 |
| template_7_psfsize_z  |   -0.00771401 |
| template_8_cosky_g    |   -0.00521994 |
| template_9_cosky_r    |    0.0231063  |
| template_10_cosky_z   |   -0.00990967 |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
