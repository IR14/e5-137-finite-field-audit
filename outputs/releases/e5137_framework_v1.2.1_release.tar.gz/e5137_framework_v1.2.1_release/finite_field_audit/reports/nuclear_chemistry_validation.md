# Nuclear chemistry validation and Fe-26 running-step audit

Status: Phase 11b nuclear-chemistry audit with the requested running-step
operator. The `Z=26 == D=26` iron resonance is still recorded as a structural
coincidence, but the updated formula does not pass the requested `<10 ppm`
NIST/CODATA mass gate.

## Formula under test

The base grammar is retained:

```text
Delta M(Z,A) = Z^2 * E_step(Z) / c^2
               * [1 + (42 / (137 * D)) * (1 - 13/117)]
```

Running-step operator:

```text
E_step(Z=1)  = 5e eV
E_step(Z>1)  = 5e * (137 * 42) * (1 - D/(137*N)) eV
```

Numerically:

```text
base step = 5e eV = 13.591409142295225 eV
nuclear running scale = 5535.6
nuclear running step = 75236.60444808945 eV
D = 26
N = 5
mirror step = 42
invariant = 117
resonance factor = 1.010481003181733
```

Reference nuclear masses are estimated from neutral isotope masses by
subtracting `Z` electron masses. Electron binding energies are not used as
tunable corrections; they are too small to change the MeV-scale conclusion.

Reference data sources:

- NIST Atomic Weights and Isotopic Compositions:
  https://www.nist.gov/pml/atomic-weights-and-isotopic-compositions
- NIST CODATA 2018 constants wall chart:
  https://pml.nist.gov/cuu/pdf/wall_2018.pdf

## Results

| isotope | Z | A | E_step eV | reference defect MeV | predicted defect MeV | predicted nuclear mass MeV | residual ppm | <10 ppm |
|:--|--:|--:|--:|--:|--:|--:|--:|:--|
| H-1 | 1 | 1 | 13.5914091423 | 0.0000133172 | 0.0000137339 | 938.272074426 | -0.000444074 | True |
| He-4 | 2 | 4 | 75236.6044481 | 28.2956897122 | 0.3041006382 | 3755.370916722 | 7509.72375320 | False |
| C-12 | 6 | 12 | 75236.6044481 | 92.1618167441 | 2.7369057434 | 11264.288146337 | 8002.32710840 | False |
| Fe-56 | 26 | 56 | 75236.6044481 | 492.259569845 | 51.3930078482 | 52530.643899912 | 8463.59083351 | False |

## Iron-26 gate

```text
Fe atomic number Z = 26
bosonic string dimension D = 26
Z == D -> True
```

For Fe-56:

```text
reference mass defect = 492.2595698447403 MeV
predicted mass defect = 51.393007848156245 MeV
defect fraction       = 0.10440225238153461
mass residual         = 8463.590833506674 ppm
```

Compared with the previous eV-only branch, the running step improves the iron
residual from `9450.036281813296 ppm` to `8463.590833506674 ppm`, but it is
still far outside the `<10 ppm` gate.

## Gate result

The running-step operator raises the scale from atomic eV to sub-MeV order, but
the tested `Z^2` grammar still misses the nuclear binding-energy systematics.
It underpredicts Fe-56 binding by almost a factor of ten and fails He-4 and
C-12 as well.

No extra renormalization fit is introduced. The chemistry branch remains a
negative audit: `Z(Fe)=D=26` may be retained as a mnemonic structural resonance,
not as a derivation of nuclear masses or the iron stability peak.
