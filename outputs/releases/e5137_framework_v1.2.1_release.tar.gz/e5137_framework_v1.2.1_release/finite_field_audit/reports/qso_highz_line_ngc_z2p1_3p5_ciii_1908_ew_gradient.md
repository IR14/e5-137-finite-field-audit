# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 228933
- finite residual rows: 228933
- observable: `CIII_1908_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.207706
- axis RA: 125.004 deg
- axis DEC: -79.184 deg
- fitted pixels: 633
- block-null p-value: 0.9421157684630739
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_ciii_1908_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|---------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    237300 |           4268 |                       4099 |                          0 |    228933 |        8367 | CIII_1908_EW        |       0.243222 |        73.8029 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    13.5262    |
| z                     |    -4.79326   |
| z2                    |     5.04998   |
| LOGMSTAR              |    -0.807132  |
| RCHI2_LINE            |    -0.0125261 |
| DELTA_LINECHI2        |     0.0876186 |
| FLUX_SYNTH_G          |     0.195696  |
| FLUX_SYNTH_R          |    -1.25603   |
| FLUX_SYNTH_Z          |    -0.162487  |
| FLUX_G                |     1.52964   |
| FLUX_R                |    -1.40033   |
| FLUX_Z                |     0.558749  |
| FLUX_W1               |     0.277214  |
| FLUX_W2               |     0.180346  |
| template_0_ebv        |    -0.136181  |
| template_1_stardens   |    -0.0626427 |
| template_2_galdepth_g |    -0.174089  |
| template_3_galdepth_r |     0.115044  |
| template_4_galdepth_z |     0.125155  |
| template_5_psfsize_g  |    -0.0666983 |
| template_6_psfsize_r  |     0.101541  |
| template_7_psfsize_z  |    -0.0586182 |
| template_8_cosky_g    |    -0.171214  |
| template_9_cosky_r    |    -0.0595499 |
| template_10_cosky_z   |    -0.0301025 |

## Figures

- `outputs/figures/qso_highz_line_ngc_z2p1_3p5_ciii_1908_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_ngc_z2p1_3p5_ciii_1908_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
