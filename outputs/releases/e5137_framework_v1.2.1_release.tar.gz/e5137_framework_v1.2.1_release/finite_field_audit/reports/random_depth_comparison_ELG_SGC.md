# Random catalog depth comparison: ELG SGC

Comparison of the enhanced ELG SGC nside=32 run using random catalogs 0..2 versus 0..9.

| tracer   | region   |   z_min |   z_max |   amplitude_ran012 |   amplitude_ran0_9 |   amplitude_delta |   p_ran012 |   p_ran0_9 |   p_delta |   axis_ra_ran012 |   axis_dec_ran012 |   axis_ra_ran0_9 |   axis_dec_ran0_9 |   axis_shift_deg |   jackknife_max_shift_ran012 |   jackknife_max_shift_ran0_9 |
|:---------|:---------|--------:|--------:|-------------------:|-------------------:|------------------:|-----------:|-----------:|----------:|-----------------:|------------------:|-----------------:|------------------:|-----------------:|-----------------------------:|-----------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |            0.08952 |            0.08981 |         0.0002881 |    0.05579 |    0.06079 |  0.004999 |            205.2 |            -50.84 |            204.9 |            -51.94 |            1.12  |                        64.51 |                        66.22 |
| ELG      | SGC      |     1.1 |     1.4 |            0.0713  |            0.07332 |         0.00202   |    0.2092  |    0.1566  | -0.05259  |            195.7 |            -33.77 |            194.7 |            -37.16 |            3.482 |                        12.95 |                        13.21 |
| ELG      | SGC      |     1.4 |     1.6 |            0.07313 |            0.066   |        -0.007127  |    0.3573  |    0.4193  |  0.06199  |             33.2 |            -37.33 |             37.8 |            -40.48 |            4.77  |                        53.11 |                        57.39 |

Interpretation: stability under additional random catalogs is necessary but not sufficient. The first redshift bin remains near, but above, the nominal 5% permutation threshold; split audits still point to selection-sensitive structure.