# Clustered lognormal mock calibration

- Map: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz`
- Mock family: angular lognormal field plus Poisson sampling
- Mocks per sigma: 1000
- Sigma values: auto=0.0640703, 0.08=0.08, 0.12=0.12
- Smoothing scale: 8 deg
- Power-spectrum slope: 1.4
- lmax: 95
- External templates regressed: 11

These mocks preserve the angular selection function encoded by the DESI
random-count map and add correlated angular density structure before
Poisson sampling. They are meant to reduce the overconfidence of
shot-noise-only p-values.

They are not official DESI mocks and do not encode the full DESI
selection, radial evolution, reconstruction, fiber assignment, or survey
covariance model.

## Summary

| mock_family       | map_path                                                                                                                                             | sigma_label   |   sigma_lognormal |   smoothing_deg |   cl_slope |   lmax | stage                              |   n_mocks |   n_templates |   null_amplitude_median |   null_amplitude_p68 |   null_amplitude_p95 |   null_amplitude_p99 |   observed_amplitude |   observed_ra_deg |   observed_dec_deg |   observed_empirical_p_value |
|:------------------|:-----------------------------------------------------------------------------------------------------------------------------------------------------|:--------------|------------------:|----------------:|-----------:|-------:|:-----------------------------------|----------:|--------------:|------------------------:|---------------------:|---------------------:|---------------------:|---------------------:|------------------:|-------------------:|-----------------------------:|
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | 0.08          |         0.08      |               8 |        1.4 |     95 | after_external_template_regression |      1000 |            11 |               0.0393543 |            0.0480254 |            0.0767632 |            0.0935451 |            0.0293449 |           219.082 |           -69.2514 |                     0.716284 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | 0.08          |         0.08      |               8 |        1.4 |     95 | raw_no_template_regression         |      1000 |            11 |               0.0783376 |            0.0908305 |            0.134561  |            0.161542  |            0.0328003 |           204.33  |           -72.2938 |                     0.954046 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | 0.12          |         0.12      |               8 |        1.4 |     95 | after_external_template_regression |      1000 |            11 |               0.0581732 |            0.0721049 |            0.115774  |            0.142327  |            0.0293449 |           219.082 |           -69.2514 |                     0.877123 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | 0.12          |         0.12      |               8 |        1.4 |     95 | raw_no_template_regression         |      1000 |            11 |               0.11455   |            0.136579  |            0.204303  |            0.246735  |            0.0328003 |           204.33  |           -72.2938 |                     0.979021 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | auto          |         0.0640703 |               8 |        1.4 |     95 | after_external_template_regression |      1000 |            11 |               0.0321449 |            0.0408166 |            0.0657788 |            0.077476  |            0.0293449 |           219.082 |           -69.2514 |                     0.569431 |
| lognormal_angular | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz | auto          |         0.0640703 |               8 |        1.4 |     95 | raw_no_template_regression         |      1000 |            11 |               0.064112  |            0.0742521 |            0.109685  |            0.135252  |            0.0328003 |           204.33  |           -72.2938 |                     0.91009  |

## Interpretation

- Compare these p-values with the earlier Poisson-only calibration; a large
increase means the old null was too narrow.
- If a signal remains unusual over a plausible sigma grid, the next step is
official DESI-like mocks or a tuned 3D lognormal/mock-catalog generator.
- Template-regressed rows should be read together with injection-recovery
tests, because template regression can suppress real dipole power.
