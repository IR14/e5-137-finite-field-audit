# Embedded DESI proxy systematics: ELG NGC vs SGC

This report is a focused follow-up to the first-pass DESI DR1 ELG directional checks.
It regresses per-pixel templates built from DESI LSS catalog metadata/random-catalog columns, then refits the dipole on the residual map.

Important caveat: these are embedded DESI selection/weight proxies, not external imaging maps such as dust, stellar density, seeing, or depth.
The external-template hook is now implemented, but no validated external maps are present in `data/external` yet.

## Inputs

- Tracer: `ELG` (`ELG_LOPnotqso` files).
- Regions: `NGC`, `SGC`.
- Random catalogs: indices `0..9`.
- Map resolution: `nside=16`.
- Null tests per bin: 5000 valid-pixel permutations and 2000 block sign-flip mocks.
- Template columns requested: `photsys`, `ntile`, `frac_tlobs_tiles`, `nx`, `weight_sys`, `weight_sn`, `weight_rf`, `weight_zfail`, `weight_comp`.

## Raw vs Corrected Dipoles

| region   |   z_min |   z_max |   n_data |   n_random |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |   raw_jackknife_axis_max_shift_deg |   corrected_jackknife_axis_max_shift_deg |
|:---------|--------:|--------:|---------:|-----------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|-----------------------------------:|-----------------------------------------:|
| NGC      |     0.8 |     1.1 |   766482 |   41021824 |             9 |              0.058243  |       0.0370462 |           0.391722 |                 0.073963 |            0.0279186  |                 0.592881 |                      0.186907  |                           0.753615 |                          25.372   |                            16.0027 |                                  15.2776 |
| NGC      |     1.1 |     1.4 |   715801 |   38135105 |             9 |              0.0366502 |       0.0252578 |           0.75165  |                 0.137931 |            0.0233837  |                 0.775445 |                      0.209395  |                           0.925798 |                          48.4943  |                            23.8695 |                                  11.7283 |
| NGC      |     1.4 |     1.6 |   339039 |   18018666 |             9 |              0.0184477 |       0.0156957 |           0.978204 |                 0.773613 |            0.00703162 |                 0.996801 |                      0.971514  |                           0.447998 |                          32.5547  |                            87.8223 |                                  67.0349 |
| SGC      |     0.8 |     1.1 |   249883 |   21022582 |             8 |              0.0356635 |       0.0887852 |           0.29774  |                 0.277861 |            0.0738997  |                 0.45151  |                      0.464768  |                           0.832343 |                           6.87488 |                            55.6709 |                                  64.6035 |
| SGC      |     1.1 |     1.4 |   242543 |   20148668 |             8 |              0.0456286 |       0.0729452 |           0.386123 |                 0.015992 |            0.0637993  |                 0.487702 |                      0.0649675 |                           0.874619 |                           2.47376 |                            11.5582 |                                  11.1654 |
| SGC      |     1.4 |     1.6 |   118324 |    9723681 |             8 |              0.0343356 |       0.0627376 |           0.586683 |                 0.134433 |            0.0544384  |                 0.688062 |                      0.287356  |                           0.867716 |                          25.8092  |                            40.2728 |                                  47.5876 |

## Interpretation

- ELG SGC remains the larger-amplitude region, but the embedded DESI proxies reduce its amplitude in every redshift bin.
- The lowest SGC bin changes from amplitude `0.088785` to `0.073900`; the local permutation p-value rises from `0.297740` to `0.451510` in this focused nside=16 run.
- NGC is weaker from the start and also drops after template regression, especially in the highest ELG bin.
- The dominant fitted proxy coefficients are `ntile` and `nx`, with opposite signs in SGC; that is a survey-selection warning rather than a cosmological signature.
- The corrected ELG SGC low-z jackknife axis remains sensitive to sky-region removal, so it is not a stable axis candidate.

## Next Required Data Step

Add validated external HEALPix templates for Galactic extinction/dust, stellar density, depth/seeing, and sky brightness, then rerun `template-systematics` with `--external-template name=path`.
Until those maps and DESI mocks are included, the correct scientific conclusion is still: no robust evidence for a directional cosmological signal.
