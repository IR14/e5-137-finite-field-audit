# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/LRG_SGC_clustering.dat.fits`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 1
- redshift range: `0.4` to `1.1`

## Sample

- joined rows on TARGETID: 662492
- finite residual rows: 662492
- observable: `DN4000`
- controls: `z; z2; LOGMSTAR`

## Dipole Fit

- amplitude: 0.0415953
- axis RA: 179.047 deg
- axis DEC: 60.645 deg
- fitted pixels: 369

## Residual Model Coefficients

| term      |   coefficient |
|:----------|--------------:|
| intercept |     1.71442   |
| z         |     0.052804  |
| z2        |    -0.0735411 |
| LOGMSTAR  |     0.0028817 |

## Figures

- `outputs/figures/desi_fastspecfit_gradient_validation_lrg_sgc_dn4000_residual_vs_z.png`
- `outputs/figures/desi_fastspecfit_gradient_validation_lrg_sgc_dn4000_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
