# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 141485
- finite residual rows: 141485
- observable: `CIII_1908_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.087681
- axis RA: 13.246 deg
- axis DEC: -65.582 deg
- fitted pixels: 356
- block-null p-value: 0.9960079840319361
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_ciii_1908_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|---------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    151020 |           4995 |                       4540 |                          0 |    141485 |        9535 | CIII_1908_EW        |      0.0774135 |        79.7675 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |  12.1017      |
| z                     |  -2.95018     |
| z2                    |   2.65669     |
| LOGMSTAR              |  -0.688276    |
| RCHI2_LINE            |  -0.059826    |
| DELTA_LINECHI2        |  -0.0557984   |
| FLUX_SYNTH_G          |  -0.459077    |
| FLUX_SYNTH_R          |  -0.679622    |
| FLUX_SYNTH_Z          |   0.163848    |
| FLUX_G                |   0.754129    |
| FLUX_R                |  -0.87689     |
| FLUX_Z                |   0.749336    |
| FLUX_W1               |   0.598997    |
| FLUX_W2               |  -0.211612    |
| template_0_ebv        |  -0.105328    |
| template_1_stardens   |  -0.0452205   |
| template_2_galdepth_g |   0.19215     |
| template_3_galdepth_r |  -0.179617    |
| template_4_galdepth_z |   0.0681598   |
| template_5_psfsize_g  |  -0.0513003   |
| template_6_psfsize_r  |   0.0014785   |
| template_7_psfsize_z  |   0.0262394   |
| template_8_cosky_g    |   0.0429741   |
| template_9_cosky_r    |  -0.0514098   |
| template_10_cosky_z   |  -0.000371888 |

## Figures

- `outputs/figures/qso_highz_line_sgc_z1p5_2p1_ciii_1908_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_sgc_z1p5_2p1_ciii_1908_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
