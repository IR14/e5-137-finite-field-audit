# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |             0 |                    nan |       0.0743992 |                  1 |                      nan |             0.0743992 |                        1 |                            nan |                                  1 |                                 0 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |             0 |                    nan |       0.0567197 |                  1 |                      nan |             0.0567197 |                        1 |                            nan |                                  1 |                                 0 |
| ELG      | NGC+SGC  |     1.4 |     1.6 |             0 |                    nan |       0.0523202 |                  1 |                      nan |             0.0523202 |                        1 |                            nan |                                  1 |                                 0 |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
