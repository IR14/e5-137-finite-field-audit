# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 262906
- finite residual rows: 262906
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00775417
- axis RA: 236.477 deg
- axis DEC: 44.050 deg
- fitted pixels: 632
- block-null p-value: 0.9920159680638723
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    281436 |           8848 |                               9682 |                          0 |    262906 |       18530 | LOG_CIII_MGII2796_EW |       -4.96093 |        7.33152 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.0597904   |
| z                     |  -0.636568    |
| z2                    |   0.655451    |
| LOGMSTAR              |   0.0316206   |
| RCHI2_LINE            |  -0.00121765  |
| DELTA_LINECHI2        |  -0.000348797 |
| FLUX_SYNTH_G          |  -0.14201     |
| FLUX_SYNTH_R          |   0.0938701   |
| FLUX_SYNTH_Z          |   0.0117594   |
| FLUX_G                |   0.118225    |
| FLUX_R                |  -0.168717    |
| FLUX_Z                |   0.0866192   |
| FLUX_W1               |  -0.0372625   |
| FLUX_W2               |   0.0379798   |
| template_0_ebv        |   0.00560827  |
| template_1_stardens   |   0.00431678  |
| template_2_galdepth_g |   0.00728041  |
| template_3_galdepth_r |  -0.0141588   |
| template_4_galdepth_z |   0.00327199  |
| template_5_psfsize_g  |  -0.00422865  |
| template_6_psfsize_r  |   0.000421027 |
| template_7_psfsize_z  |   0.00529788  |
| template_8_cosky_g    |  -0.000199572 |
| template_9_cosky_r    |  -0.013942    |
| template_10_cosky_z   |   0.0150664   |

## Figures

- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_ngc_z1p5_2p1_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
