# Multipole diagnostics

- Map: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/ELG_SGC_z0p800_1p100_template_regressed_corrected_map.npz`

This diagnostic compares the standard dipole-only fit with a fit that also
marginalizes over five quadrupole-like angular templates. If the dipole amplitude
or axis changes strongly, the candidate is likely entangled with broader footprint
or low-order angular structure rather than behaving as an isolated dipole.

## Summary

| model                  |   dipole_amplitude |   ra_deg |   dec_deg |   monopole |   n_pixels |   weighted_r2 |   residual_std |   weighted_design_condition |   quadrupole_norm |   axis_shift_from_dipole_only_deg |   amplitude_ratio_to_dipole_only |
|:-----------------------|-------------------:|---------:|----------:|-----------:|-----------:|--------------:|---------------:|----------------------------:|------------------:|----------------------------------:|---------------------------------:|
| dipole_only            |          0.0850716 |  215.176 |  -57.8849 |  0.0404114 |       1337 |   nan         |      nan       |                     nan     |          0        |                            0      |                          1       |
| dipole_plus_quadrupole |          0.58322   |  206.974 |   31.8438 |  0.26851   |       1337 |     0.0481719 |        0.16699 |                     154.483 |          0.610972 |                           89.9933 |                          6.85564 |

## Coefficients

| model                  | term     |   coefficient |
|:-----------------------|:---------|--------------:|
| dipole_plus_quadrupole | monopole |      0.26851  |
| dipole_plus_quadrupole | dipole_x |     -0.441543 |
| dipole_plus_quadrupole | dipole_y |     -0.224722 |
| dipole_plus_quadrupole | dipole_z |      0.30771  |
| dipole_plus_quadrupole | q_xx     |      0.325963 |
| dipole_plus_quadrupole | q_yy     |      0.143256 |
| dipole_plus_quadrupole | q_xy     |      0.267954 |
| dipole_plus_quadrupole | q_xz     |     -0.378474 |
| dipole_plus_quadrupole | q_yz     |     -0.1774   |
