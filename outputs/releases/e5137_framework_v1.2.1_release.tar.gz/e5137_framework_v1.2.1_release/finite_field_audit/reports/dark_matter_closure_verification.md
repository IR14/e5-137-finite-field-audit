# Dark Matter Closure Verification

## Status

Conditional WIMP-like heavy sterile-neutrino benchmark.

This report does **not** verify the particle as the dominant component of Cold
Dark Matter from mass alone. It verifies only the limited kinematic and
consistency filters that can be evaluated without specifying couplings,
production history, annihilation/decay channels, or active-sterile mixing.

## Input Mass

| quantity | value |
|---|---:|
| m_nu_tau_prime [eV] | 1556646342.769707 |
| m_nu_tau_prime [MeV] | 1556.646342770 |
| m_nu_tau_prime [GeV] | 1.556646342770 |

## Test A: Relic Density

Observed reference:

```text
Omega_c h^2 ~= 0.120
```

For a thermal WIMP-like relic, the required annihilation scale is usually of
order

```text
<sigma v> ~= 2.20e-26 cm^3/s
```

The e-5-137 mass formula does not specify an annihilation cross-section,
freeze-out history, freeze-in coupling, gravitational production amplitude, or
entropy dilution factor. Therefore the relic abundance is not calculable from
the mass formula alone.

| check | result |
|---|---:|
| relic density calculable from mass only | False |
| conditional viability if fully sterile/nonthermal | True |

## Test B: Structure Formation and Free Streaming

The mass is GeV-scale, so a nonrelativistically produced population would behave
as cold dark matter for large-scale-structure purposes. This is a kinematic
classification only. A precise free-streaming scale still depends on the
momentum distribution at production.

| check | result |
|---|---:|
| GeV-scale cold candidate | True |
| active-neutrino Z-width constraint avoided automatically | False |

Because the mass is below 45 GeV, it cannot be an ordinary active fourth
neutrino with Standard-Model-strength Z coupling. It must be sterile or
otherwise decoupled.

## Test C: Decay and Gamma-Ray Bounds

For a heavy sterile neutrino, radiative and cascade decay constraints depend on
the mixing angle and decay operators. The statement `theta^2 -> 0` is an
additional model assumption, not a consequence of the mass value.

| quantity | value |
|---|---:|
| age of Universe [s] | 4.350846e+17 |
| target lifetime for age x 1e12 [s] | 4.350846e+29 |
| gamma lifetime calculable from mass only | False |

If exact sterility is imposed, the particle can be stable by assumption. If any
active mixing or visible decay channel is present, Fermi-LAT and related
X-ray/gamma-ray constraints require a dedicated model-dependent lifetime
calculation.

## Verdict

The benchmark mass

```text
m_nu_tau_prime = 1.556646342770 GeV
```

is compatible with a heavy cold sterile-particle mass scale. It is **not** a
standalone verification of `Omega_c h^2 = 0.120`, nor does it prove gamma-ray
stability. The defensible final status is:

```text
Conditionally viable only as a fully sterile/nonthermal GeV-scale dark-matter
candidate; not verified as a complete cosmological model.
```

## References

- Planck 2018 cosmological parameters: `Omega_c h^2 ~= 0.120`.
- Fermi-LAT gamma-ray line and diffuse-photon searches constrain visible
  annihilation or decay channels.
- Sterile-neutrino dark-matter reviews emphasize that mass alone is not enough;
  production and mixing determine viability.
