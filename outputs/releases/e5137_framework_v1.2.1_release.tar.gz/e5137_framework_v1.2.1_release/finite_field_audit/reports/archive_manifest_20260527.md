# Archive manifest: DESI FastSpecFit gradient validation

Archived: 2026-05-27

Status:

> Cosmological gradient test: Active Null. Vacuum isotropy conserved at z=0.4-0.6.

## Result Summary

- LSS catalog: `data/raw/LRG_NGC_clustering.dat.fits`
- VAC catalog: `data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalog count: 1
- tracer/region: LRG NGC
- redshift range: `0.4 <= z < 0.6`
- observable: `DN4000_MODEL`
- joined rows: 342791
- usable residual rows: 342791
- quality-filter input rows: 346759
- quality-filter removed rows: 3968
- fitted HEALPix pixels: 648
- dipole amplitude: 0.07522013870722569
- dipole axis: RA 247.0564785437394 deg, DEC 38.15027937465149 deg
- spatial block-null p-value: 0.4091816367265469
- spatial block-null mocks: 500
- spatial block-null regions: 48

## Frozen Artifacts

| artifact | sha256 |
|---|---|
| `outputs/reports/desi_fastspecfit_gradient_validation.md` | `e1b4aee73eee66eee73a4ed1b0860b8c9b44217753f64985af5275d08bad5e98` |
| `outputs/tables/production/desi_fastspecfit_gradient_validation.csv` | `d509d43de526477dce21a7119c1b70c17c32ef3dce118f11012fa0bfb61b704f` |
| `outputs/tables/production/desi_fastspecfit_gradient_validation.md` | `e1b4aee73eee66eee73a4ed1b0860b8c9b44217753f64985af5275d08bad5e98` |
| `outputs/figures/desi_fastspecfit_gradient_validation_residual_vs_z.png` | `c06c5baebeb4f12ce8138961dbc113fa71f8b9c8d28df4d3f9a01b76730431ca` |
| `outputs/figures/desi_fastspecfit_gradient_validation_residual_hist.png` | `d6598332de3ee1e8b6798fae04509c6284af7edcf3d38bac7df168530c844c90` |

## Verification

- Test suite at archive time: `34 passed`.
- No `cosmo-gradient`, `fastspecfit-gradient`, `aria2`, `curl`, or FastSpecFit
  tail-monitor processes remained active after shutdown.

## Scientific Hold

The pilot result is an active null result: it does not support a significant
directional DN4000_MODEL residual dipole in LRG NGC at `0.4 <= z < 0.6` under
the Phase 2 quality cuts, IVAR weighting, and spatial block-null validation.
Future claims require reopening the analysis with an explicit new scope,
including multiple tracers, redshift bins, systematics templates, and mock
calibration.
