# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| QSO      | NGC+SGC  |     1.5 |     2.1 |            11 |             0.00397583 |      0.00378379 |           0.991602 |                 0.834633 |            0.00370284 |                 0.992801 |                       0.840432 |                           0.978605 |                           47.8453 |
| QSO      | NGC+SGC  |     2.1 |     3.5 |            11 |             0.0113641  |      0.00860659 |           0.85123  |                 0.240952 |            0.00398731 |                 0.980404 |                       0.780044 |                           0.463285 |                           20.6578 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| QSO      | NGC+SGC  |     1.5 |     2.1 | intercept                          |   0.000583911 |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_ebv        |   0.000534935 |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_stardens   |   0.00167253  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_galdepth_g |  -0.00304084  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_galdepth_r |   0.00382831  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_galdepth_z |   0.00247732  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_psfsize_g  |  -0.00313669  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_psfsize_r  |  -0.00090207  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:pixweight_dark_psfsize_z  |   0.0024202   |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:legacy_dr9_bricks_cosky_g |   0.0148969   |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:legacy_dr9_bricks_cosky_r |  -0.00825948  |
| QSO      | NGC+SGC  |     1.5 |     2.1 | external:legacy_dr9_bricks_cosky_z |  -0.00030742  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | intercept                          |   0.000686563 |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_ebv        |   0.00162045  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_stardens   |   0.00187796  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_g |   0.00286876  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_r |   0.00797765  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_z |  -0.00470253  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_g  |   0.000777698 |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_r  |   0.000271316 |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_z  |   0.00465898  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_g |   0.0038185   |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_r |  -0.0082478   |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_z |   0.00924187  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
