# Project log

## 2026-05-27: Phase 2 production pilot archived

Status:

> Cosmological gradient test: Active Null. Vacuum isotropy conserved at z=0.4-0.6.

The production FastSpecFit gradient validation was completed for LRG NGC,
`0.4 <= z < 0.6`, using `DN4000_MODEL` residuals controlled by `z`, `z^2`, and
`LOGMSTAR`. The spatial block-null result was `p = 0.4091816367` with 500 null
mocks, so the tested pilot cell is compatible with the null hypothesis.

Archived report:

- `outputs/reports/desi_fastspecfit_gradient_validation.md`
- `outputs/reports/archive_manifest_20260527.md`

Code state:

- `uv run pytest`: 34 passed
- production and download processes stopped
- repository placed into archival observational state

Strategy note:

The cosmological gradient contour is closed for this pilot result. Any further
theoretical number-theory work belongs outside the archived observational
pipeline and must not mutate the frozen validation artifacts.

## 2026-05-28: DESI DR1 observational stop condition fixed

Status:

> DESI DR1 observational gradient search: Active Null. Stop condition engaged.

The observational search was extended beyond the LRG pilot into QSO high-redshift
density, raw emission-line residuals, and a preregistered line-ratio family. The
combined result remains null-compatible across all controlled tests.

Primary closure artifacts:

- `outputs/reports/observational_gradient_master_null_report.md`
- `outputs/tables/observational_gradient_master_null_tests.csv`
- `outputs/reports/qso_line_ratio_preregistration.md`
- `outputs/reports/qso_line_ratio_preregistered_results.md`
- `outputs/tables/qso_line_ratio_preregistered_results.csv`
- `outputs/reports/observational_stop_condition.md`

Stop rule:

Further searches on DESI DR1 are stopped unless a new data release, official
mock calibration, documented methodological bug, new external systematic
template set, or a fully preregistered new observable family justifies reopening.

Code state:

- `uv run pytest`: 35 passed
