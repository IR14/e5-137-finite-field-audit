# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 186086
- finite residual rows: 186086
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0177183
- axis RA: 174.848 deg
- axis DEC: -54.049 deg
- fitted pixels: 968
- block-null p-value: 0.8802395209580839
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    366554 |           7141 |                            173327 |                          0 |    186086 |      180468 | LOG_CIV_MGII2796_EW |       -2.27687 |        11.7875 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    1.02739    |
| z                     |    0.361877   |
| z2                    |   -0.480127   |
| LOGMSTAR              |   -0.0165741  |
| RCHI2_LINE            |   -0.0149612  |
| DELTA_LINECHI2        |   -0.00550512 |
| FLUX_SYNTH_G          |    0.17398    |
| FLUX_SYNTH_R          |   -0.257519   |
| FLUX_SYNTH_Z          |    0.0724074  |
| FLUX_G                |    0.164412   |
| FLUX_R                |   -0.177765   |
| FLUX_Z                |    0.0370957  |
| FLUX_W1               |    0.0377177  |
| FLUX_W2               |   -0.0247933  |
| template_0_ebv        |    0.0224261  |
| template_1_stardens   |   -0.00997687 |
| template_2_galdepth_g |   -0.0214044  |
| template_3_galdepth_r |   -0.0212565  |
| template_4_galdepth_z |    0.0165591  |
| template_5_psfsize_g  |   -0.0140357  |
| template_6_psfsize_r  |    0.00978096 |
| template_7_psfsize_z  |   -0.0135329  |
| template_8_cosky_g    |   -0.0352781  |
| template_9_cosky_r    |    0.0114422  |
| template_10_cosky_z   |    0.00641292 |

## Figures

- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
