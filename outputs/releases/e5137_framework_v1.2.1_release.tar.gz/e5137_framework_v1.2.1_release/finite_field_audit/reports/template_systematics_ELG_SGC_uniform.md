# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |             2 |               0.899261 |        0.577399 |         0.00019996 |                 0.346731 |              0.299533 |               0.00019996 |                     0.00159968 |                           0.518763 |                           56.5614 |
| ELG      | SGC      |     1.1 |     1.4 |             2 |               0.900161 |        0.502607 |         0.00019996 |                 0.368526 |              0.241485 |               0.00019996 |                     0.00579884 |                           0.480464 |                           68.25   |
| ELG      | SGC      |     1.4 |     1.6 |             2 |               0.86151  |        0.460358 |         0.00019996 |                 0.372725 |              0.255931 |               0.00019996 |                     0.00279944 |                           0.55594  |                           78.631  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term             |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------|--------------:|
| ELG      | SGC      |     0.8 |     1.1 | intercept        |     -0.148664 |
| ELG      | SGC      |     0.8 |     1.1 | ntile            |      0.172675 |
| ELG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles |      0.188875 |
| ELG      | SGC      |     1.1 |     1.4 | intercept        |     -0.143732 |
| ELG      | SGC      |     1.1 |     1.4 | ntile            |      0.177262 |
| ELG      | SGC      |     1.1 |     1.4 | frac_tlobs_tiles |      0.173026 |
| ELG      | SGC      |     1.4 |     1.6 | intercept        |     -0.148614 |
| ELG      | SGC      |     1.4 |     1.6 | ntile            |      0.151832 |
| ELG      | SGC      |     1.4 |     1.6 | frac_tlobs_tiles |      0.214887 |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
