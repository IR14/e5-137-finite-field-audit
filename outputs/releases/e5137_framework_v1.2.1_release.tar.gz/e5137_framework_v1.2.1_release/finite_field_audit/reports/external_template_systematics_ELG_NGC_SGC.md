# External HEALPix template systematics: ELG NGC vs SGC

This report extends the previous embedded DESI-proxy regression by adding external sky-systematics templates.

## External template sources

- DESI `pixweight-1-dark.fits`: `EBV`, `STARDENS`, `GALDEPTH_G/R/Z`, `PSFSIZE_G/R/Z`.
- Legacy Surveys DR9 brick summaries: `COSKY_G/R/Z` sky-brightness proxies.
- All maps were converted to HEALPix `nside=16`, RING ordering, and passed to `template-systematics` as `.npz` one-dimensional arrays.

## Generated external maps

| name                      | column     |   nside |   n_finite_pixels | path                                                                                                                            |
|:--------------------------|:-----------|--------:|------------------:|:--------------------------------------------------------------------------------------------------------------------------------|
| pixweight_dark_ebv        | EBV        |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_ebv_nside16_ring.npz        |
| pixweight_dark_stardens   | STARDENS   |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_stardens_nside16_ring.npz   |
| pixweight_dark_galdepth_g | GALDEPTH_G |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_galdepth_g_nside16_ring.npz |
| pixweight_dark_galdepth_r | GALDEPTH_R |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_galdepth_r_nside16_ring.npz |
| pixweight_dark_galdepth_z | GALDEPTH_Z |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_galdepth_z_nside16_ring.npz |
| pixweight_dark_psfsize_g  | PSFSIZE_G  |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_psfsize_g_nside16_ring.npz  |
| pixweight_dark_psfsize_r  | PSFSIZE_R  |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_psfsize_r_nside16_ring.npz  |
| pixweight_dark_psfsize_z  | PSFSIZE_Z  |      16 |              1665 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/pixweight_dark_psfsize_z_nside16_ring.npz  |
| legacy_dr9_bricks_cosky_g | cosky_g    |      16 |              1221 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/legacy_dr9_bricks_cosky_g_nside16_ring.npz |
| legacy_dr9_bricks_cosky_r | cosky_r    |      16 |              1221 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/legacy_dr9_bricks_cosky_r_nside16_ring.npz |
| legacy_dr9_bricks_cosky_z | cosky_z    |      16 |              1221 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/external/templates/legacy_dr9_bricks_cosky_z_nside16_ring.npz |

## Regression comparison

| region   |   z_min |   z_max |   raw_amplitude |    raw_p |   embedded_templates |   embedded_r2 |   embedded_corrected_amplitude |   embedded_corrected_p |   external_templates |   external_r2 |   external_corrected_amplitude |   external_corrected_p |   external_block_p |   external_axis_shift_deg |   external_jackknife_axis_max_shift_deg |
|:---------|--------:|--------:|----------------:|---------:|---------------------:|--------------:|-------------------------------:|-----------------------:|---------------------:|--------------:|-------------------------------:|-----------------------:|-------------------:|--------------------------:|----------------------------------------:|
| NGC      |     0.8 |     1.1 |       0.0370462 | 0.391722 |                    9 |     0.058243  |                     0.0279186  |               0.592881 |                   20 |     0.0896887 |                     0.00455422 |               0.994801 |          0.952524  |                  50.9722  |                                 87.992  |
| SGC      |     0.8 |     1.1 |       0.0887852 | 0.29774  |                    8 |     0.0356635 |                     0.0738997  |               0.45151  |                   19 |     0.0872292 |                     0.0660569  |               0.546491 |          0.181409  |                  44.2167  |                                 41.1204 |
| NGC      |     1.1 |     1.4 |       0.0252578 | 0.75165  |                    9 |     0.0366502 |                     0.0233837  |               0.775445 |                   20 |     0.0620863 |                     0.00795293 |               0.984803 |          0.782109  |                   4.84674 |                                 72.4934 |
| SGC      |     1.1 |     1.4 |       0.0729452 | 0.386123 |                    8 |     0.0456286 |                     0.0637993  |               0.487702 |                   19 |     0.0717318 |                     0.0510521  |               0.643871 |          0.0834583 |                  37.154   |                                 25.3689 |
| NGC      |     1.4 |     1.6 |       0.0156957 | 0.978204 |                    9 |     0.0184477 |                     0.00703162 |               0.996801 |                   20 |     0.0474012 |                     0.00579143 |               0.9986   |          0.98051   |                  40.3997  |                                 72.7619 |
| SGC      |     1.4 |     1.6 |       0.0627376 | 0.586683 |                    8 |     0.0343356 |                     0.0544384  |               0.688062 |                   19 |     0.0773342 |                     0.0138038  |               0.989402 |          0.86007   |                  79.6625  |                                 70.5623 |

## Interpretation

- Adding external templates further suppresses all ELG NGC bins and all ELG SGC bins.
- `ELG SGC 0.8-1.1`, the earlier low-p-value prompt, moves from raw amplitude `0.088785` to `0.066062` after embedded+external regression, with p-value `0.545691`.
- `ELG NGC 0.8-1.1` is almost fully absorbed by the templates: `0.037046` to `0.004554`, p-value `0.995001`.
- The external-template regression is diagnostic rather than a final correction model; the covariates are correlated and the sky-brightness maps are brick-level proxies.
- The scientific status remains conservative: no robust directional cosmological signal survives these first-pass external systematics controls.
