# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| LRG      | SGC      |     0.4 |     0.6 |            17 |              0.087853  |       0.0575672 |           0.782244 |                 0.293853 |            0.025737   |                 0.972206 |                       0.603698 |                           0.447077 |                           63.2728 |
| LRG      | SGC      |     0.6 |     0.8 |            17 |              0.0661382 |       0.0368132 |           0.834433 |                 0.648676 |            0.0107976  |                 0.991802 |                       0.978011 |                           0.293308 |                           18.1862 |
| LRG      | SGC      |     0.8 |     1.1 |            17 |              0.0573006 |       0.0486999 |           0.663067 |                 0.336332 |            0.00687437 |                 0.9982   |                       0.98001  |                           0.141158 |                           59.153  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| LRG      | SGC      |     0.4 |     0.6 | intercept                          |  -0.0051563   |
| LRG      | SGC      |     0.4 |     0.6 | ntile                              |   0.0198327   |
| LRG      | SGC      |     0.4 |     0.6 | frac_tlobs_tiles                   |   0.080684    |
| LRG      | SGC      |     0.4 |     0.6 | nx                                 |  -0.0970919   |
| LRG      | SGC      |     0.4 |     0.6 | weight_sys                         |  -0.0137682   |
| LRG      | SGC      |     0.4 |     0.6 | weight_zfail                       |  -0.0291236   |
| LRG      | SGC      |     0.4 |     0.6 | weight_comp                        |  -0.0123723   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_ebv        |  -0.0090925   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_stardens   |  -0.00679903  |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_g |  -0.0319816   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_r |   0.03379     |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_z |   0.0204193   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_g  |  -0.0143715   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_r  |  -0.0121154   |
| LRG      | SGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_z  |   0.00445547  |
| LRG      | SGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_g |   0.0545518   |
| LRG      | SGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_r |   0.0118274   |
| LRG      | SGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_z |  -0.0328199   |
| LRG      | SGC      |     0.6 |     0.8 | intercept                          |  -0.00498898  |
| LRG      | SGC      |     0.6 |     0.8 | ntile                              |   0.0265883   |
| LRG      | SGC      |     0.6 |     0.8 | frac_tlobs_tiles                   |   0.0542413   |
| LRG      | SGC      |     0.6 |     0.8 | nx                                 |  -0.0816131   |
| LRG      | SGC      |     0.6 |     0.8 | weight_sys                         |   0.0107215   |
| LRG      | SGC      |     0.6 |     0.8 | weight_zfail                       |   0.0138912   |
| LRG      | SGC      |     0.6 |     0.8 | weight_comp                        |   0.0128408   |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_ebv        |  -0.0169071   |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_stardens   |  -0.000269906 |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_g |   0.00899988  |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_r |   0.0223643   |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_z |   0.0173758   |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_g  |   0.015929    |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_r  |  -0.010284    |
| LRG      | SGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_z  |   0.00318445  |
| LRG      | SGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_g |   0.0690985   |
| LRG      | SGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_r |  -0.0439514   |
| LRG      | SGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_z |   0.00213887  |
| LRG      | SGC      |     0.8 |     1.1 | intercept                          |  -0.00498144  |
| LRG      | SGC      |     0.8 |     1.1 | ntile                              |  -0.0184223   |
| LRG      | SGC      |     0.8 |     1.1 | frac_tlobs_tiles                   |   0.0284865   |
| LRG      | SGC      |     0.8 |     1.1 | nx                                 |   0.00717754  |
| LRG      | SGC      |     0.8 |     1.1 | weight_sys                         |   0.0149825   |
| LRG      | SGC      |     0.8 |     1.1 | weight_zfail                       |  -0.00798046  |
| LRG      | SGC      |     0.8 |     1.1 | weight_comp                        |   0.00149246  |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.0153432   |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_stardens   |   0.0037999   |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.001336    |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |   0.000915583 |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |  -0.013643    |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.00133338  |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |  -0.00417999  |
| LRG      | SGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.0055341   |
| LRG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0296696   |
| LRG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0033686   |
| LRG      | SGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |   0.0110266   |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
