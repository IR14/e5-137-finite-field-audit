# Phase 5 Anomaly Forge

## Scope

This is an exploratory anomaly and outlier scan. It searches for rare base-e digit patterns and modular coincidences, then reports whether the requested hard thresholds are actually met. Null or weak outcomes are retained.

## Constants and Operators

- N = 5
- D = 26
- I5 = 42
- q = 0.00886061187429
- T5 = 0.147151776469
- f_tau = 42 + 2e^-2 + 2e^-7 = 42.2724943304
- Higgs reference mass used here: 125.250 GeV
- Top reference mass used here: 172.500 GeV

## Vector 1: Brothers 137

Scanned primes in [137, 200000] and selected primes with `d_-2 = 2` and `d_-7 = 2` in the greedy base-e expansion.

- Total primes scanned: 17952
- Collisions found: 717
- Collision fraction: 0.039940

First collision rows:

|   prime |   integer_digits |   fractional_prefix |   d_minus_2 |   d_minus_7 |
|--------:|-----------------:|--------------------:|------------:|------------:|
|     137 |            21100 |        021010200121 |           2 |           2 |
|     139 |            21102 |        021010200121 |           2 |           2 |
|     193 |           102011 |        121010212000 |           2 |           2 |
|     263 |           120012 |        120120200200 |           2 |           2 |
|     571 |          1100211 |        120101211011 |           2 |           2 |
|     577 |          1101012 |        021120201012 |           2 |           2 |
|    1039 |          2111101 |        120021201102 |           2 |           2 |
|    1163 |         10010111 |        120101201102 |           2 |           2 |
|    1213 |         10020021 |        121210210210 |           2 |           2 |
|    1367 |         10120112 |        120011210211 |           2 |           2 |
|    1609 |         11012121 |        021101201000 |           2 |           2 |
|    1811 |         11200121 |        020020201002 |           2 |           2 |
|    1889 |         11211202 |        120011210000 |           2 |           2 |
|    1997 |         12011211 |        021010201012 |           2 |           2 |
|    2273 |         20011012 |        021011201200 |           2 |           2 |

Closest mass-resonance checks after substituting each collision prime as an alpha-like scale in the frozen lepton-generation formulas:

|   prime | formula              | target                   |   predicted_mass_MeV |   target_mass_MeV |   signed_ppm |    abs_ppm | passes_100ppm   |
|--------:|:---------------------|:-------------------------|---------------------:|------------------:|-------------:|-----------:|:----------------|
|  162557 | muon_generation_like | higgs_default_125p25_GeV |               125336 |            125250 |      684.266 |    684.266 | False           |
|    9629 | tau_generation_like  | higgs_default_125p25_GeV |               124853 |            125250 |    -3167.97  |   3167.97  | False           |
|   13789 | tau_generation_like  | top_default_172p5_GeV    |               178793 |            172500 |    36483     |  36483     | False           |
|  199447 | muon_generation_like | top_default_172p5_GeV    |               153779 |            172500 |  -108528     | 108528     | False           |
|  199447 | electron_alpha_like  | higgs_default_125p25_GeV |               101917 |            125250 |  -186290     | 186290     | False           |
|  199447 | electron_alpha_like  | top_default_172p5_GeV    |               101917 |            172500 |  -409176     | 409176     | False           |

No tested collision passed the requested <100 ppm mass-resonance threshold.

## Vector 2: Golden Ratio Base-e DNA Matrix

Golden ratio base-e prefix: `1.1120201211100100200002012001110012010100010201112100020211011202020102101212000011020001000211212020_e`

Block slicing with step I5 = 42:

|   block | positions   |   length |   sum_digits |   sum_mod_5 |   sum_mod_42 |   sum_mod_137 |   weighted_local_mod_5 |   weighted_local_mod_42 |   weighted_local_mod_137 |
|--------:|:------------|---------:|-------------:|------------:|-------------:|--------------:|-----------------------:|------------------------:|-------------------------:|
|       1 | 1-42        |       42 |           29 |           4 |           29 |            29 |                      0 |                      18 |                       28 |
|       2 | 43-84       |       42 |           36 |           1 |           36 |            36 |                      2 |                      31 |                       59 |
|       3 | 85-100      |       16 |           12 |           2 |           12 |            12 |                      4 |                      29 |                      129 |

The block residues do not form a stable repeated residue class across the available 100-digit prefix. This is a null result for a simple Z/42Z stabilizer in this scan.

## Vector 3: 137-adic String Metric

A fixed D=26 by N=5 integer phase lattice was evaluated with the 137-adic valuation v_137(delta) over all pairwise level differences. The level definition does not insert 137 directly, so divisibility by 137 remains a testable property rather than a construction artifact.

- Levels: 130
- Pairwise distances: 8385
- Pairs with v_137(delta) >= 1: 62
- Fraction divisible by 137: 0.007394

|   v137 |   pair_count |   fraction |
|-------:|-------------:|-----------:|
|      0 |         8323 | 0.992606   |
|      1 |           62 | 0.00739416 |

No high-order 137-adic collapse was observed in this fixed lattice. The dominant class is v_137 = 0, as expected for generic integer differences.

## Figures

- Collision residuals: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/figures/phase5_collision_residuals.png`
- Golden-ratio digit trace: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/figures/phase5_phi_base_e_digits.png`
- 137-adic valuation distribution: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/figures/phase5_padic_valuation_distribution.png`

## Output Tables

- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_brothers137_collisions.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_mass_resonance_candidates.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_phi_base_e_digits.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_phi_blocks_i5.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_padic_levels.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_padic_distances.csv`
- `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/phase5_padic_valuation_distribution.csv`

## Verdict

Phase 5 found rare digit collisions by construction, but the downstream tests did not produce a robust physical resonance under the stated thresholds. The golden-ratio and 137-adic branches also returned null results for the simple invariants tested here. The conservative interpretation is that these scans do not currently support a new discrete invariant.
