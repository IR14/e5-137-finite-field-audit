# Minimal Complex Alphabet Audit

Alphabet mode: `model`.

Expression cost is the number of atoms used. Binary operations are
`+`, `-`, `*`, `/`, and tightly bounded exponentiation. Since targets are
real, candidates with non-negligible imaginary parts are excluded from
the nearest-hit table. The imaginary unit remains available through
real reductions such as `i^2 = -1`.

## Setup

- max atom cost: `4`
- alphabet size: `19`
- random targets per range: `2000`
- magnitude bound: `1e+06`
- real-candidate imaginary tolerance: `1e-10`
- total generated candidates: `6994865`
- real generated candidates: `6086118`

## Best Real Hits

| target                        |         value | best_expression       |    best_value |   observed_ppm |   cost |
|:------------------------------|--------------:|:----------------------|--------------:|---------------:|-------:|
| alpha_inv                     |  137.036      | (137+(q*(pi+cos2_5))) |  137.036      |      0.0108501 |      4 |
| delta_alpha_inv_minus_137     |    0.0359991  | (((e^cos2_5)-1)/I5)   |    0.0359989  |      4.88316   |      4 |
| muon_to_electron_mass_ratio   |  206.768      | (I5*(5-(1/13)))       |  206.769      |      4.58514   |      4 |
| tau_to_electron_mass_ratio    | 3477.23       | (I5+((F26/13)/e))     | 3477.23       |      0.473917  |      4 |
| proton_to_electron_mass_ratio | 1836.15       | (pi+(13*(5+phi137)))  | 1836.14       |      6.03478   |      4 |
| q_operator                    |    0.00886061 | q                     |    0.00886061 |      0         |      1 |
| T5_operator                   |    0.147152   | T5                    |    0.147152   |      0         |      1 |

## Random-Target Null

| target                        |   observed_ppm |   random_targets |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p05 |   random_ppm_p01 |   random_ppm_min |
|:------------------------------|---------------:|-----------------:|-----------------------------:|--------------------:|-----------------:|-----------------:|-----------------:|
| alpha_inv                     |      0.0108501 |             2000 |                   0.22089    |           0.0345531 |       0.00215255 |      0.000544866 |      1.05353e-05 |
| delta_alpha_inv_minus_137     |      4.88316   |             2000 |                   0.669165   |           2.83114   |       0.211704   |      0.0345075   |      0.000659118 |
| muon_to_electron_mass_ratio   |      4.58514   |             2000 |                   0.728136   |           2.33776   |       0.157209   |      0.0327976   |      0.00140643  |
| tau_to_electron_mass_ratio    |      0.473917  |             2000 |                   0.110945   |           3.0681    |       0.215814   |      0.0310081   |      9.68117e-05 |
| proton_to_electron_mass_ratio |      6.03478   |             2000 |                   0.722139   |           3.10869   |       0.204092   |      0.054552    |      0.000505083 |
| q_operator                    |      0         |             2000 |                   0.00049975 |           3.76981   |       0.228248   |      0.0646282   |      0.000323934 |
| T5_operator                   |      0         |             2000 |                   0.00049975 |           2.20377   |       0.169361   |      0.0326991   |      1.8524e-06  |

## Reading Rule

- Low ppm error is only interesting if random targets are not hit as well.
- High `empirical_p_random_as_good` means the grammar is dense in that
  target range.
- This audit intentionally restricts the alphabet to avoid importing
  problem-specific constants in `minimal` mode. In `model` mode it
  intentionally measures how much denser the grammar becomes after
  adding the model-specific constants.
