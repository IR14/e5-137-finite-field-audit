# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC      |     0.8 |     1.1 |             9 |              0.058243  |       0.0370462 |           0.391722 |                 0.073963 |            0.0279186  |                 0.592881 |                       0.186907 |                           0.753615 |                           25.372  |
| ELG      | NGC      |     1.1 |     1.4 |             9 |              0.0366502 |       0.0252578 |           0.75165  |                 0.137931 |            0.0233837  |                 0.775445 |                       0.209395 |                           0.925798 |                           48.4943 |
| ELG      | NGC      |     1.4 |     1.6 |             9 |              0.0184477 |       0.0156957 |           0.978204 |                 0.773613 |            0.00703162 |                 0.996801 |                       0.971514 |                           0.447998 |                           32.5547 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term             |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------|--------------:|
| ELG      | NGC      |     0.8 |     1.1 | intercept        |   -0.0063271  |
| ELG      | NGC      |     0.8 |     1.1 | photsys=N        |    0.00879679 |
| ELG      | NGC      |     0.8 |     1.1 | ntile            |   -0.0737383  |
| ELG      | NGC      |     0.8 |     1.1 | frac_tlobs_tiles |   -0.050987   |
| ELG      | NGC      |     0.8 |     1.1 | nx               |    0.130511   |
| ELG      | NGC      |     0.8 |     1.1 | weight_sys       |   -0.00164486 |
| ELG      | NGC      |     0.8 |     1.1 | weight_sn        |   -0.00164486 |
| ELG      | NGC      |     0.8 |     1.1 | weight_rf        |   -0.0210003  |
| ELG      | NGC      |     0.8 |     1.1 | weight_zfail     |   -0.0070773  |
| ELG      | NGC      |     0.8 |     1.1 | weight_comp      |   -0.0361658  |
| ELG      | NGC      |     1.1 |     1.4 | intercept        |   -0.00776558 |
| ELG      | NGC      |     1.1 |     1.4 | photsys=N        |    0.102204   |
| ELG      | NGC      |     1.1 |     1.4 | ntile            |   -0.152566   |
| ELG      | NGC      |     1.1 |     1.4 | frac_tlobs_tiles |   -0.0340764  |
| ELG      | NGC      |     1.1 |     1.4 | nx               |    0.193169   |
| ELG      | NGC      |     1.1 |     1.4 | weight_sys       |    0.0105143  |
| ELG      | NGC      |     1.1 |     1.4 | weight_sn        |    0.0105143  |
| ELG      | NGC      |     1.1 |     1.4 | weight_rf        |   -0.0777233  |
| ELG      | NGC      |     1.1 |     1.4 | weight_zfail     |   -0.00749709 |
| ELG      | NGC      |     1.1 |     1.4 | weight_comp      |   -0.0140597  |
| ELG      | NGC      |     1.4 |     1.6 | intercept        |   -0.0106034  |
| ELG      | NGC      |     1.4 |     1.6 | photsys=N        |    0.156913   |
| ELG      | NGC      |     1.4 |     1.6 | ntile            |    0.0292527  |
| ELG      | NGC      |     1.4 |     1.6 | frac_tlobs_tiles |    0.0370386  |
| ELG      | NGC      |     1.4 |     1.6 | nx               |   -0.0525515  |
| ELG      | NGC      |     1.4 |     1.6 | weight_sys       |    0.0112437  |
| ELG      | NGC      |     1.4 |     1.6 | weight_sn        |    0.0112437  |
| ELG      | NGC      |     1.4 |     1.6 | weight_rf        |   -0.109636   |
| ELG      | NGC      |     1.4 |     1.6 | weight_zfail     |   -0.00192663 |
| ELG      | NGC      |     1.4 |     1.6 | weight_comp      |   -0.0257241  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
