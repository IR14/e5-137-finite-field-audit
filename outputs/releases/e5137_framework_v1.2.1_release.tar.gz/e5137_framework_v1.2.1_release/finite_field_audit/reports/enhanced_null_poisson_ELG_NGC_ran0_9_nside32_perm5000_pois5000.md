# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| ELG      | NGC      |     0.8 |     1.1 |   766482 |   41021824 |   0.0367808 |      0.00833846 |  188.814 |  -11.4021 |       0.367726 |
| ELG      | NGC      |     1.1 |     1.4 |   715801 |   38135105 |   0.0253917 |      0.00727792 |  197.441 |  -30.0668 |       0.613677 |
| ELG      | NGC      |     1.4 |     1.6 |   339039 |   18018666 |   0.0158525 |      0.0109551  |  176.109 |  -26.2552 |       0.923615 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| ELG 0.800-1.100 | ELG 1.100-1.400 |          20.3131 |
| ELG 0.800-1.100 | ELG 1.400-1.600 |          19.0801 |
| ELG 1.100-1.400 | ELG 1.400-1.600 |          19.1584 |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
