# ELG low-z multipole summary

| model                  |   dipole_amplitude |   ra_deg |   dec_deg |   monopole |   n_pixels |   weighted_r2 |   residual_std |   weighted_design_condition |   quadrupole_norm |   axis_shift_from_dipole_only_deg |   amplitude_ratio_to_dipole_only | map_case                   |
|:-----------------------|-------------------:|---------:|----------:|-----------:|-----------:|--------------:|---------------:|----------------------------:|------------------:|----------------------------------:|---------------------------------:|:---------------------------|
| dipole_only            |          0.0898115 |  204.939 |  -51.9442 | 0.0502938  |       1337 |   nan         |     nan        |                    nan      |         0         |                            0      |                          1       | ELG_SGC_raw                |
| dipole_plus_quadrupole |          0.64695   |  204.312 |   32.0787 | 0.27871    |       1337 |     0.0522153 |       0.167289 |                    154.483  |         0.712559  |                           84.0247 |                          7.20342 | ELG_SGC_raw                |
| dipole_only            |          0.0850716 |  215.176 |  -57.8849 | 0.0404114  |       1337 |   nan         |     nan        |                    nan      |         0         |                            0      |                          1       | ELG_SGC_template_corrected |
| dipole_plus_quadrupole |          0.58322   |  206.974 |   31.8438 | 0.26851    |       1337 |     0.0481719 |       0.16699  |                    154.483  |         0.610972  |                           89.9933 |                          6.85564 | ELG_SGC_template_corrected |
| dipole_only            |          0.0328003 |  204.33  |  -72.2938 | 0.00249846 |       3602 |   nan         |     nan        |                    nan      |         0         |                            0      |                          1       | ELG_NGC_SGC_combined       |
| dipole_plus_quadrupole |          0.0609946 |  237.364 |  -79.7118 | 0.0153491  |       3602 |     0.0185072 |       0.182771 |                     28.2765 |         0.0686588 |                           10.6265 |                          1.85957 | ELG_NGC_SGC_combined       |

## Interpretation

- In SGC-only maps, dipole+quadrupole fitting is ill-conditioned and shifts the dipole axis by ~84-90 degrees.
- The combined NGC+SGC map is less ill-conditioned, but the combined signal is not significant after look-elsewhere correction.
- This supports treating the ELG low-z residual as footprint/systematics-sensitive rather than as a stable dipole axis.
