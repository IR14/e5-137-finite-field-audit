# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| LRG      | NGC      |     0.4 |     0.6 |   346761 |   22210337 |   0.0552216 |       0.0242076 |   2.71   | -28.9237  |       0.203559 |
| LRG      | NGC      |     0.6 |     0.8 |   533955 |   33933628 |   0.0244573 |       0.0157228 | 344.195  | -24.8758  |       0.692262 |
| LRG      | NGC      |     0.8 |     1.1 |   595419 |   37718685 |   0.0182226 |       0.0120419 | 245.084  | -38.5796  |       0.787443 |
| LRG      | SGC      |     0.4 |     0.6 |   160150 |   11783429 |   0.0577945 |       0.0249971 |  54.3351 |  17.5944  |       0.540492 |
| LRG      | SGC      |     0.6 |     0.8 |   237939 |   17850617 |   0.0382892 |       0.0220993 | 101.676  |  71.3771  |       0.75125  |
| LRG      | SGC      |     0.8 |     1.1 |   264403 |   19956471 |   0.052456  |       0.0303924 | 186.144  |   1.64661 |       0.474305 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| LRG 0.400-0.600 | LRG 0.600-0.800 |          16.9801 |
| LRG 0.400-0.600 | LRG 0.800-1.100 |          90.8983 |
| LRG 0.400-0.600 | LRG 0.400-0.600 |          68.1761 |
| LRG 0.400-0.600 | LRG 0.600-0.800 |         120.124  |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         152.527  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |          81.3723 |
| LRG 0.600-0.800 | LRG 0.400-0.600 |          80.4078 |
| LRG 0.600-0.800 | LRG 0.600-0.800 |         122.162  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |         148.562  |
| LRG 0.800-1.100 | LRG 0.400-0.600 |         157.014  |
| LRG 0.800-1.100 | LRG 0.600-0.800 |         142.315  |
| LRG 0.800-1.100 | LRG 0.800-1.100 |          67.3408 |
| LRG 0.400-0.600 | LRG 0.600-0.800 |          60.4803 |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         128.794  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |          86.6751 |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
