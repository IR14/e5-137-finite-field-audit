# Look-elsewhere summary

Input: ELG, LRG, and QSO over NGC and SGC using DESI DR1 LSS catalogs, random catalogs 0..9 where available for every tracer/region, nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

- Number of tested tracer/region/redshift bins: 20
- Minimum permutation p-value: 0.0607878
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.981204

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |   ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|---------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | ELG      | SGC      | 0.8-1.1 |   249883 |   21022582 |   0.0898115 | 204.939  | -51.9442  |      0.0607878 |              1 |   0.981204 |        0.00019996 |                        66.2156 |
|           2 | ELG      | SGC      | 1.1-1.4 |   242543 |   20148668 |   0.0733176 | 194.738  | -37.1618  |      0.156569  |              1 |   0.981204 |        0.00039992 |                        13.2065 |
|           3 | LRG      | NGC      | 0.4-0.6 |   346761 |   22210337 |   0.0552216 |   2.71   | -28.9237  |      0.203559  |              1 |   0.981204 |        0.00019996 |                        11.5075 |
|           4 | ELG      | NGC      | 0.8-1.1 |   766482 |   41021824 |   0.0367808 | 188.814  | -11.4021  |      0.367726  |              1 |   0.981204 |        0.00019996 |                        17.614  |
|           5 | ELG      | SGC      | 1.4-1.6 |   118324 |    9723681 |   0.0659999 |  37.8017 | -40.4783  |      0.419316  |              1 |   0.981204 |        0.0029994  |                        57.3935 |
|           6 | LRG      | SGC      | 0.8-1.1 |   264403 |   19956471 |   0.052456  | 186.144  |   1.64661 |      0.474305  |              1 |   0.981204 |        0.00059988 |                        27.7551 |
|           7 | QSO      | SGC      | 1.2-1.6 |   104480 |   15788596 |   0.0475859 |  16.7271 | -13.7549  |      0.512298  |              1 |   0.981204 |        0.0593881  |                        14.0297 |
|           8 | LRG      | SGC      | 0.4-0.6 |   160150 |   11783429 |   0.0577945 |  54.3351 |  17.5944  |      0.540492  |              1 |   0.981204 |        0.0039992  |                        19.6748 |
|           9 | ELG      | NGC      | 1.1-1.4 |   715801 |   38135105 |   0.0253917 | 197.441  | -30.0668  |      0.613677  |              1 |   0.981204 |        0.00119976 |                        19.8923 |
|          10 | LRG      | NGC      | 0.6-0.8 |   533955 |   33933628 |   0.0244573 | 344.195  | -24.8758  |      0.692262  |              1 |   0.981204 |        0.00419916 |                        36.0895 |

## Closest axes among overlapping redshift intervals

| region   | left        | right       |   z_overlap |   axis_separation_deg |    left_p |   right_p |
|:---------|:------------|:------------|------------:|----------------------:|----------:|----------:|
| SGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |               32.4597 | 0.419316  |  0.512298 |
| SGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |               55.8963 | 0.0607878 |  0.474305 |
| NGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |               56.7154 | 0.367726  |  0.787443 |
| NGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              113.222  | 0.367726  |  0.814637 |
| SGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |              129.049  | 0.156569  |  0.512298 |
| NGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |              129.08   | 0.923615  |  0.981204 |
| NGC      | LRG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              130.518  | 0.787443  |  0.814637 |
| NGC      | ELG 1.1-1.4 | QSO 0.8-1.2 |         0.1 |              130.928  | 0.613677  |  0.814637 |
| SGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              139.203  | 0.0607878 |  0.846031 |
| NGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |              142.745  | 0.613677  |  0.981204 |

## Interpretation

No directional claim should be made from local p-values without accounting for the
number of tracer, region, redshift, resolution, weight, and split tests that were tried.
Poisson p-values are shot-noise diagnostics only; the permutation p-value is the
first-pass null statistic used for this correction table.
