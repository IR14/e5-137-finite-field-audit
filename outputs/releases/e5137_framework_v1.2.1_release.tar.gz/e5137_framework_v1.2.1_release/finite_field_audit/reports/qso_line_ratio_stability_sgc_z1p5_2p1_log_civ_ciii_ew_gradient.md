# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 138411
- finite residual rows: 138411
- observable: `LOG_CIV_CIII_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0170763
- axis RA: 20.071 deg
- axis DEC: 49.148 deg
- fitted pixels: 354
- block-null p-value: 0.9720558882235529
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_ciii_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    151020 |           4995 |                          7614 |                          0 |    138411 |       12609 | LOG_CIV_CIII_EW     |       -2.35971 |        6.06359 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.04026     |
| z                     |  -0.0726718   |
| z2                    |   0.00700565  |
| LOGMSTAR              |  -0.0661482   |
| RCHI2_LINE            |   0.00127133  |
| DELTA_LINECHI2        |  -0.000288169 |
| FLUX_SYNTH_G          |   0.237896    |
| FLUX_SYNTH_R          |  -0.429112    |
| FLUX_SYNTH_Z          |   0.213833    |
| FLUX_G                |  -0.0482944   |
| FLUX_R                |   0.21236     |
| FLUX_Z                |  -0.160545    |
| FLUX_W1               |   0.05567     |
| FLUX_W2               |  -0.0721352   |
| template_0_ebv        |   0.0116009   |
| template_1_stardens   |  -0.00109612  |
| template_2_galdepth_g |  -0.0183829   |
| template_3_galdepth_r |   0.00485797  |
| template_4_galdepth_z |  -0.0011132   |
| template_5_psfsize_g  |   0.000288392 |
| template_6_psfsize_r  |   0.00159616  |
| template_7_psfsize_z  |  -0.00432709  |
| template_8_cosky_g    |  -0.0212005   |
| template_9_cosky_r    |   0.0178574   |
| template_10_cosky_z   |  -0.00349543  |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_civ_ciii_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_civ_ciii_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
