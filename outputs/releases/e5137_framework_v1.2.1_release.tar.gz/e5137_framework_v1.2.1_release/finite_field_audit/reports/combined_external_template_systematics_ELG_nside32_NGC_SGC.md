# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |            11 |             0.00553621 |       0.0328003 |          0.0436521 |                0.0041632 |             0.0293449 |                0.0759747 |                     0.00666112 |                           0.894654 |                           5.70944 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |            11 |             0.00943637 |       0.0271119 |          0.113629  |                0.0166528 |             0.0266403 |                0.103965  |                     0.00915903 |                           0.982604 |                          13.3599  |
| ELG      | NGC+SGC  |     1.4 |     1.6 |            11 |             0.00371422 |       0.0173678 |          0.571476  |                0.258951  |             0.0128166 |                0.75908   |                     0.484596   |                           0.737952 |                          12.6005  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 | intercept                          |  -0.000465406 |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_ebv        |  -0.000407409 |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00424232  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |   0.00655619  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |  -0.00348858  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |  -0.00518258  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.00450114  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.00126892  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.00266112  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |   0.00561083  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.00751035  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.0129472   |
| ELG      | NGC+SGC  |     1.1 |     1.4 | intercept                          |  -0.00113886  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_ebv        |  -0.00359357  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_stardens   |  -0.000898772 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |  -0.00360591  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |   0.000837397 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.00642549  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |   0.00210065  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00486872  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |  -0.00286706  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |   0.00430585  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |  -0.00683223  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |  -0.00953482  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | intercept                          |  -0.000535071 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_ebv        |  -0.0046613   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_stardens   |  -0.000278349 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.00173356  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |  -0.00119527  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.00673234  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.0067928   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00313836  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.00286347  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |   0.00574848  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.00273099  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.00334604  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
