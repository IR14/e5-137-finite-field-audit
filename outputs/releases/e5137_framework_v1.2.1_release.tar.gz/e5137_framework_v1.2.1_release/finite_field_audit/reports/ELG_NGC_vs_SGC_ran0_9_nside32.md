# ELG NGC vs SGC comparison, random catalogs 0..9

Both regions use nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

| tracer   |   z_min |   z_max |   amp_NGC |   amp_SGC |   amp_ratio_SGC_over_NGC |   p_NGC |   p_SGC |   ra_NGC |   dec_NGC |   ra_SGC |   dec_SGC |   axis_separation_deg |   jackknife_max_shift_NGC |   jackknife_max_shift_SGC |   n_data_NGC |   n_data_SGC |   n_random_NGC |   n_random_SGC |
|:---------|--------:|--------:|----------:|----------:|-------------------------:|--------:|--------:|---------:|----------:|---------:|----------:|----------------------:|--------------------------:|--------------------------:|-------------:|-------------:|---------------:|---------------:|
| ELG      |     0.8 |     1.1 |   0.03678 |   0.08981 |                    2.442 |  0.3677 | 0.06079 |    188.8 |    -11.4  |    204.9 |    -51.94 |                42.6   |                     17.61 |                     66.22 |       766482 |       249883 |       41021824 |       21022582 |
| ELG      |     1.1 |     1.4 |   0.02539 |   0.07332 |                    2.887 |  0.6137 | 0.1566  |    197.4 |    -30.07 |    194.7 |    -37.16 |                 7.442 |                     19.89 |                     13.21 |       715801 |       242543 |       38135105 |       20148668 |
| ELG      |     1.4 |     1.6 |   0.01585 |   0.066   |                    4.163 |  0.9236 | 0.4193  |    176.1 |    -26.26 |     37.8 |    -40.48 |               102.8   |                     76.88 |                     57.39 |       339039 |       118324 |       18018666 |        9723681 |

Interpretation: the near-threshold ELG SGC z=0.8-1.1 feature is not mirrored in ELG NGC. SGC has a larger amplitude and much lower permutation p-value, while NGC remains compatible with the permutation null. This weakens a whole-sky cosmological-axis interpretation and strengthens the need for survey/systematics checks.
