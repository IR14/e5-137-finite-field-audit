# Control grid look-elsewhere summary

Input: LRG, ELG, and QSO over NGC and SGC using DESI DR1 LSS catalogs, random catalogs 0..2, nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

- Number of tested tracer/region/redshift bins: 20
- Minimum permutation p-value: 0.059988
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.985803

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |   ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|---------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | ELG      | SGC      | 0.8-1.1 |   249883 |    6305110 |     0.08952 |  205.2   |   -50.84  |        0.05999 |              1 |     0.9858 |         0.0002    |                          64.51 |
|           2 | ELG      | SGC      | 1.1-1.4 |   242543 |    6047145 |     0.0713  |  195.7   |   -33.77  |        0.2028  |              1 |     0.9858 |         0.0002    |                          12.95 |
|           3 | LRG      | NGC      | 0.4-0.6 |   346761 |    6662611 |     0.05486 |    2.452 |   -28.92  |        0.2072  |              1 |     0.9858 |         0.0002    |                          13.45 |
|           4 | ELG      | NGC      | 0.8-1.1 |   766482 |   12306203 |     0.03798 |  190     |   -12.47  |        0.3367  |              1 |     0.9858 |         0.0002    |                          17.26 |
|           5 | ELG      | SGC      | 1.4-1.6 |   118324 |    2917069 |     0.07313 |   33.2   |   -37.33  |        0.3573  |              1 |     0.9858 |         0.0009998 |                          53.11 |
|           6 | LRG      | SGC      | 0.8-1.1 |   264403 |    5986866 |     0.05474 |  186.5   |     2.232 |        0.4461  |              1 |     0.9858 |         0.0003999 |                          24.97 |
|           7 | LRG      | SGC      | 0.4-0.6 |   160150 |    3535898 |     0.0604  |   51.54  |    16.83  |        0.4861  |              1 |     0.9858 |         0.002999  |                          17.19 |
|           8 | QSO      | SGC      | 1.2-1.6 |   104480 |    4735179 |     0.04782 |   16.19  |   -15.87  |        0.5287  |              1 |     0.9858 |         0.06059   |                          16.36 |
|           9 | ELG      | NGC      | 1.1-1.4 |   715801 |   11438144 |     0.02407 |  196.6   |   -32.87  |        0.6617  |              1 |     0.9858 |         0.002999  |                          26.07 |
|          10 | LRG      | NGC      | 0.6-0.8 |   533955 |   10177952 |     0.02482 |  345     |   -23.94  |        0.6929  |              1 |     0.9858 |         0.004599  |                          48.25 |

## Closest axes among overlapping redshift intervals

| region   | left        | right       |   z_overlap |   axis_separation_deg |   left_p |   right_p |
|:---------|:------------|:------------|------------:|----------------------:|---------:|----------:|
| SGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |                 26.2  |  0.3573  |    0.5287 |
| NGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |                 47.56 |  0.3367  |    0.7461 |
| SGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |                 55.43 |  0.05999 |    0.4461 |
| NGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |                 97.41 |  0.856   |    0.9858 |
| NGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |                113    |  0.3367  |    0.8582 |
| NGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |                118.8  |  0.6617  |    0.9858 |
| NGC      | LRG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |                120.6  |  0.7461  |    0.8582 |
| SGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |                130.4  |  0.2028  |    0.5287 |
| NGC      | ELG 1.1-1.4 | QSO 0.8-1.2 |         0.1 |                131.7  |  0.6617  |    0.8582 |
| SGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |                145    |  0.05999 |    0.9298 |

## Interpretation

No bin survives Bonferroni correction over this control grid. The strongest case is ELG SGC z=0.8-1.1, but it remains near-threshold and does not repeat in LRG or QSO as a shared robust axis.

Poisson p-values are reported as shot-noise diagnostics only. They are not a full cosmological null because they do not include cosmic variance, survey-window uncertainty, target-selection residuals, depth, dust, stellar contamination, or tiling/fiber assignment effects.
