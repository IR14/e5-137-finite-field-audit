# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| LRG      | NGC+SGC  |     0.4 |     0.6 |            11 |             0.00407282 |      0.00765366 |           0.964607 |               0.887556   |            0.00912375 |                 0.946411 |                      0.842579  |                           1.19208  |                          23.2445  |
| LRG      | NGC+SGC  |     0.6 |     0.8 |            11 |             0.00611957 |      0.00792218 |           0.943211 |               0.830085   |            0.00660526 |                 0.965407 |                      0.876062  |                           0.833767 |                           2.80984 |
| LRG      | NGC+SGC  |     0.8 |     1.1 |            11 |             0.0202889  |      0.0159111  |           0.589482 |               0.212894   |            0.00464025 |                 0.977804 |                      0.833583  |                           0.291637 |                          47.2604  |
| ELG      | NGC+SGC  |     0.8 |     1.1 |            11 |             0.0150558  |      0.0326834  |           0.125375 |               0.00149925 |            0.0229974  |                 0.329534 |                      0.0164918 |                           0.703641 |                           5.54116 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |            11 |             0.023599   |      0.0267839  |           0.256949 |               0.0169915  |            0.021825   |                 0.411718 |                      0.0209895 |                           0.814855 |                          14.6514  |
| ELG      | NGC+SGC  |     1.4 |     1.6 |            11 |             0.016974   |      0.0178394  |           0.788642 |               0.235382   |            0.00825    |                 0.969806 |                      0.754123  |                           0.462461 |                          13.2413  |
| QSO      | NGC+SGC  |     0.8 |     1.2 |            11 |             0.0155991  |      0.0169211  |           0.615077 |               0.176912   |            0.00749427 |                 0.942412 |                      0.605197  |                           0.442895 |                          32.9989  |
| QSO      | NGC+SGC  |     1.2 |     1.6 |            11 |             0.00865352 |      0.00624834 |           0.973605 |               0.543728   |            0.0062314  |                 0.967806 |                      0.487756  |                           0.99729  |                          85.8139  |
| QSO      | NGC+SGC  |     1.6 |     2.1 |            11 |             0.00605549 |      0.00486161 |           0.964607 |               0.724638   |            0.00059115 |                 0.9998   |                      0.9995    |                           0.121595 |                          47.6424  |
| QSO      | NGC+SGC  |     2.1 |     3.5 |            11 |             0.0101286  |      0.00862052 |           0.856629 |               0.157421   |            0.00317136 |                 0.991402 |                      0.897551  |                           0.367886 |                          19.6681  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| LRG      | NGC+SGC  |     0.4 |     0.6 | intercept                          |  -0.000694172 |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_ebv        |  -0.00166123  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_stardens   |   0.00435022  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_galdepth_g |  -0.00340859  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_galdepth_r |  -0.0113589   |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_galdepth_z |   0.01388     |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_psfsize_g  |   0.00303568  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_psfsize_r  |  -0.0015468   |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:pixweight_dark_psfsize_z  |   0.000201324 |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_g |  -0.00390446  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_r |  -0.00151379  |
| LRG      | NGC+SGC  |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_z |  -0.00218163  |
| LRG      | NGC+SGC  |     0.6 |     0.8 | intercept                          |   0.0007172   |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_ebv        |   0.00447979  |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_stardens   |  -0.000998647 |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_galdepth_g |  -0.0269      |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_galdepth_r |   0.0259741   |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_galdepth_z |  -0.0011972   |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_psfsize_g  |   0.00287065  |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_psfsize_r  |   0.00256253  |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:pixweight_dark_psfsize_z  |  -0.000863333 |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_g |   0.0136976   |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_r |  -0.019404    |
| LRG      | NGC+SGC  |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_z |  -0.00292898  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | intercept                          |  -0.00107212  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.0093174   |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00215954  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00457198  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |  -0.00651921  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |   0.00249718  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.0175845   |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.010711    |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.00186282  |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0557108   |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0537689   |
| LRG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |   0.00487993  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | intercept                          |  -0.00178673  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.00156202  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00449527  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00050953  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |  -0.00437876  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |  -0.00225391  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.00938399  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.00386307  |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |  -0.0030016   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0130313   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0206439   |
| ELG      | NGC+SGC  |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.00785007  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | intercept                          |  -0.00197409  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_ebv        |  -0.00427542  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_stardens   |  -0.000245661 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |   0.000850687 |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |  -0.00602369  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.00464493  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |  -0.00276068  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00555481  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |  -0.00226605  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |  -0.0115177   |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |   0.00810939  |
| ELG      | NGC+SGC  |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |  -0.00450959  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | intercept                          |  -0.00186956  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_ebv        |   0.000955616 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_stardens   |  -0.000533982 |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.0135967   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |  -0.00611089  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.0155666   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.0109688   |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00514629  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.00211423  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |  -0.00286889  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.00704961  |
| ELG      | NGC+SGC  |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.00021941  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | intercept                          |   0.00123332  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_ebv        |  -0.00122497  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_stardens   |  -0.00130145  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_galdepth_g |   0.014671    |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_galdepth_r |   0.0102452   |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_galdepth_z |  -0.0173372   |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_psfsize_g  |   0.00772241  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_psfsize_r  |  -0.00566915  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:pixweight_dark_psfsize_z  |   0.0042907   |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_g |  -0.00099614  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_r |   0.00902856  |
| QSO      | NGC+SGC  |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_z |   0.00214603  |
| QSO      | NGC+SGC  |     1.2 |     1.6 | intercept                          |   8.98621e-05 |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_ebv        |  -9.33698e-05 |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_stardens   |  -0.00400555  |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_galdepth_g |   0.0122718   |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_galdepth_r |  -0.0102725   |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_galdepth_z |  -0.000905469 |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_psfsize_g  |   0.0117071   |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.000998277 |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:pixweight_dark_psfsize_z  |  -0.000923189 |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_g |   0.00255473  |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_r |  -0.00438992  |
| QSO      | NGC+SGC  |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.00353343  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | intercept                          |   0.000473022 |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_ebv        |  -0.000203296 |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_stardens   |   0.00361121  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_galdepth_g |  -0.007339    |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_galdepth_r |   0.0043267   |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_galdepth_z |   0.00401202  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_psfsize_g  |  -0.00301779  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_psfsize_r  |  -0.00126494  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:pixweight_dark_psfsize_z  |   0.00221922  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_g |   0.0145011   |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_r |  -0.00700664  |
| QSO      | NGC+SGC  |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_z |  -0.00468723  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | intercept                          |   0.000655303 |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_ebv        |   0.00187864  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_stardens   |   0.00216364  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_g |   0.00331825  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_r |   0.00616424  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_galdepth_z |  -0.0035761   |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_g  |   0.0022928   |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_r  |  -0.000888858 |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:pixweight_dark_psfsize_z  |   0.0043757   |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_g |   0.00103378  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_r |  -0.00501275  |
| QSO      | NGC+SGC  |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_z |   0.00804283  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
