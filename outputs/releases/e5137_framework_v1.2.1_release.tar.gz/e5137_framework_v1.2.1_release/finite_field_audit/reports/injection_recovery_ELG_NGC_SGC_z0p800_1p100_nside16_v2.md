# Injection recovery

- Map: `data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz`
- External templates: 11

This diagnostic injects a known dipole into a fixed observed map. Recovery is measured
by subtracting the baseline fitted vector before and after injection, so the table
reports
the recovered injected component rather than the map's pre-existing residual.

| axis_name    |   axis_ra_deg |   axis_dec_deg | stage                              |   injected_amplitude |   baseline_amplitude |   absolute_fit_amplitude |   recovered_amplitude |   recovery_fraction |   recovered_ra_deg |   recovered_dec_deg |   axis_error_deg |
|:-------------|--------------:|---------------:|:-----------------------------------|---------------------:|---------------------:|-------------------------:|----------------------:|--------------------:|-------------------:|--------------------:|-----------------:|
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.01 |            0.0326834 |                0.0328959 |            0.01       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.01 |            0.0229974 |                0.0258966 |            0.00460451 |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.02 |            0.0326834 |                0.036001  |            0.02       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.02 |            0.0229974 |                0.0292369 |            0.00920903 |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.03 |            0.0326834 |                0.0413522 |            0.03       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.03 |            0.0229974 |                0.032884  |            0.0138135  |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.05 |            0.0326834 |                0.0560168 |            0.05       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.05 |            0.0229974 |                0.0407638 |            0.0230226  |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.01 |            0.0326834 |                0.0426834 |            0.01       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.01 |            0.0229974 |                0.0260438 |            0.00310753 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.02 |            0.0326834 |                0.0526834 |            0.02       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.02 |            0.0229974 |                0.0291031 |            0.00621506 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.03 |            0.0326834 |                0.0626834 |            0.03       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.03 |            0.0229974 |                0.0321716 |            0.00932259 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.05 |            0.0326834 |                0.0826834 |            0.05       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.05 |            0.0229974 |                0.0383276 |            0.0155376  |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
