# Known-Approximation Audit

This is an anti-numerology diagnostic. It asks whether numerical
agreement can be reproduced by ordinary continued-fraction approximations
or by a small dictionary of common `e`/`pi` expressions with small integer
coefficients.

The audit does not validate or refute a physical model by itself. Its role
is to flag when ppm-level agreement is not surprising under simple
approximation mechanisms.

## Setup

- random targets per range: `2000`
- continued-fraction denominator grid: `[10, 100, 1000, 10000, 100000]`
- dictionary terms per expression: up to `2`
- dictionary basis: `1`, `e`, `pi`, `pi/e`, `e/pi`, `pi-e`, `e*pi`,
  `pi^2`, `e^2`, `e^pi`, `pi^e`, `log(137)`, `sqrt(137)`, `1/e`, `1/pi`
- integer coefficients: `0`, `±1`, `±2`, `±3`, `±5`, `±13`, `±26`, `±137`

## Continued-Fraction Summary

Best rational approximations at the largest tested denominator bound:

| target                        | best_fraction   |   observed_ppm |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p01 |
|:------------------------------|:----------------|---------------:|-----------------------------:|--------------------:|-----------------:|
| alpha_inv                     | 6581702/48029   |    8.2588e-07  |                     0.61919  |         6.28895e-07 |      1.45127e-08 |
| delta_alpha_inv_minus_137     | 1729/48029      |    0.00314392  |                     0.5997   |         0.00226094  |      4.10537e-05 |
| muon_to_electron_mass_ratio   | 18454276/89251  |    7.26322e-07 |                     0.737631 |         4.21414e-07 |      5.85656e-09 |
| tau_to_electron_mass_ratio    | 240568561/69184 |    2.65481e-08 |                     0.532234 |         2.43593e-08 |      6.42766e-10 |
| proton_to_electron_mass_ratio | 33482244/18235  |    1.17888e-07 |                     0.849575 |         4.72855e-08 |      7.51833e-10 |
| q_operator                    | 532/60041       |    0.00461598  |                     0.388806 |         0.00648529  |      0.000155765 |
| T5_operator                   | 1909/12973      |    0.00202889  |                     0.858571 |         0.000605189 |      1.07181e-05 |

## e/pi Dictionary Hits

| target                        |         value | best_expression         |   best_value |   observed_ppm |   max_terms |
|:------------------------------|--------------:|:------------------------|-------------:|---------------:|------------:|
| alpha_inv                     |  137.036      | 26*1 + 13*e*pi          |  137.017     |        141.964 |           2 |
| delta_alpha_inv_minus_137     |    0.0359991  | 26*e/pi + -1*pi^e       |    0.0374977 |      41630.6   |           2 |
| muon_to_electron_mass_ratio   |  206.768      | 26*e^2 + 3*log(137)     |  206.875     |        518.061 |           2 |
| tau_to_electron_mass_ratio    | 3477.23       | 137*e^pi + 26*sqrt(137) | 3474.6       |        756.691 |           2 |
| proton_to_electron_mass_ratio | 1836.15       | 137*e*pi + 137*log(137) | 1843.98      |       4263.43  |           2 |
| q_operator                    |    0.00886061 | 0                       |    0         |          1e+06 |           2 |
| T5_operator                   |    0.147152   | 3*1/e + -3*1/pi         |    0.148709  |      10580.2   |           2 |

## e/pi Dictionary Random-Target Null

| target                        |   observed_ppm |   random_targets |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p05 |   random_ppm_p01 |   random_ppm_min |
|:------------------------------|---------------:|-----------------:|-----------------------------:|--------------------:|-----------------:|-----------------:|-----------------:|
| alpha_inv                     |        141.964 |             2000 |                     0.463768 |             165.823 |          10.6282 |          2.43954 |        0.0895206 |
| delta_alpha_inv_minus_137     |      41630.6   |             2000 |                     0.371314 |           63181     |        5428.2    |       1782.02    |        1.27098   |
| muon_to_electron_mass_ratio   |        518.061 |             2000 |                     0.744628 |             263.072 |          20.57   |          5.32706 |        0.210903  |
| tau_to_electron_mass_ratio    |        756.691 |             2000 |                     0.25987  |            1726.85  |         145.649  |         45.9587  |        0.663482  |
| proton_to_electron_mass_ratio |       4263.43  |             2000 |                     0.821589 |            2535.03  |         248.044  |         48.6222  |        0.862902  |
| q_operator                    |          1e+06 |             2000 |                     1        |          211625     |       11272.9    |       1693.01    |      130.785     |
| T5_operator                   |      10580.2   |             2000 |                     0.54023  |            9410.39  |         788.531  |        143.994   |        5.35299   |

## Interpretation Rule

- A high `empirical_p_random_as_good` means random targets are hit about as
  well as the real target, so the approximation is not strong evidence.
- A low value means the target is less easily matched by this particular
  simple approximation family. This still does not prove physics; it only
  survives this narrow anti-numerology filter.
- Continued fractions are intentionally a harsh warning: arbitrary rational
  coefficients become very powerful very quickly.

## Practical Consequence

Any future symbolic-regression claim should report a comparable null-rate
against random targets and a complexity penalty. Sub-ppm agreement alone
is not a reliable discovery criterion.
