# Краткий отчет: official EZmock ELG NGC+SGC, mock1..500

Дата прогона: 2026-05-26.

## Конфигурация

- Dataset: DESI DR1 official EZmock, `dark/v1`, `ffa`.
- Tracer: ELG.
- Regions: NGC + SGC.
- Realizations: 1..500.
- Random catalog: index 0.
- Redshift shell: 0.8 <= z <= 1.1.
- HEALPix: nside=16, ring ordering.
- External templates in regression: 11 maps.
- Observed map: `data/processed/ELG_NGC_SGC_z0p800_1p100_nside16_combined_template_regressed_raw_map.npz`.

## Data QA note

During the first full attempt, `mock434/ELG_LOP_ffa_NGC_clustering.dat.fits`
was found to be corrupted locally: its size exceeded the server `Content-Length`
and it produced impossible weights and an artificial dipole. The single file was
quarantined, redownloaded, size-checked against the server, smoke-tested, and
then the full 1..500 ensemble was rerun.

## Results

| Stage | Observed amplitude | Mock median | Mock p95 | Mock p99 | Mock max | Empirical p |
|---|---:|---:|---:|---:|---:|---:|
| Raw map | 0.032683 | 0.006976 | 0.014188 | 0.018052 | 0.023665 | 0.001996 |
| After external-template regression | 0.022997 | 0.004587 | 0.008814 | 0.011401 | 0.015681 | 0.001996 |

Observed corrected axis:

- RA = 222.055 deg
- DEC = -71.697 deg

Top corrected mock amplitude:

- realization 43: corrected amplitude = 0.015681

No mock out of 500 exceeded the observed amplitude. Therefore the p-value is
not an extrapolated tail estimate; it is the finite-sample empirical upper
resolution `(0 + 1) / (500 + 1) = 0.001996`.

## Interpretation

This strengthens the specific ELG NGC+SGC, z=0.8..1.1, nside=16 result relative
to the 370-realization run. It still does not prove the genesis-gradient
hypothesis. The scientific next checks are axis stability across redshift bins,
tracer consistency, nside/weighting robustness, and stronger file-size/checksum
validation for downloaded mocks.

