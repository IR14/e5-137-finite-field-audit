# Fermi-LAT GCE Resonance Audit

## Status

Gamma appendix for the fourth sterile-neutrino benchmark.

This report does not claim a Fermi-LAT detection or a catalog-level p-value.
It checks whether the mass and phase-modulated annihilation scale are compatible
with broad Galactic Center GeV Excess (GCE) expectations.

## Input Benchmark

| quantity | value |
|---|---:|
| m_nu_tau_prime [GeV] | 1.556646342770 |
| q | 0.008860611874291 |
| delta_phi | 0.059005583838357 |
| q * delta_phi | 5.228255768076074e-04 |

## Test 1: Annihilation Cross-Section

The reference GCE/WIMP-like scale is taken as

```text
<sigma v>_ref = 2.00e-26 cm^3/s
```

Two simple phase-modulated estimates were evaluated:

| model | formula | value [cm^3/s] | fraction of reference |
|---|---|---:|---:|
| linear rate modulation | sigma_ref * (q delta_phi) | 1.045651e-29 | 5.228256e-04 |
| quadratic amplitude modulation | sigma_ref * (q delta_phi)^2 | 5.466932e-33 | 2.733466e-07 |

Both estimates are far below the canonical `~2e-26 cm^3/s` GCE scale. The
phase operator alone therefore does not generate enough annihilation rate to
explain the GCE.

## Test 2: Decoupled vs Induced Coupling

The fully sterile limit gives no visible gamma-ray annihilation or decay signal.
A toy induced-mixing proxy was computed as

```text
theta2_toy = (q * delta_phi / D)^2 = 4.043589e-10
```

This is only a dimensional toy proxy. It is not a physical mixing calculation,
because the model does not specify a mediator, coupling, density-dependent
operator, or Galactic Center baryonic-environment response. Sagittarius A* is
therefore not enough, by itself, to activate a calculable mixing angle.

## Test 3: Spectral/Kinematic Compatibility

| check | result |
|---|---:|
| gamma line energy if annihilation/decay produces a monochromatic line [GeV] | 1.556646342770 |
| line lies in 1--4 GeV photon band | True |
| DM mass lies in common GCE annihilation mass window, roughly 7--200 GeV | False |
| Fermi-LAT catalog/likelihood p-value available | False |

The line energy is in the broad GeV photon band, but the particle mass is below
the common GCE dark-matter mass windows reported for continuum annihilation
fits. In particular, the usual `b bbar` interpretation is inaccessible at this
mass, and even tau/leptonic interpretations generally use heavier dark matter
than 1.56 GeV.

## Verdict

The benchmark does **not** pass the GCE resonance audit as a standalone
explanation:

```text
mass: GeV-scale, but below common continuum-fit DM mass windows
cross-section: phase-modulated estimates are too small
p-value: not computed because no Fermi-LAT likelihood data/model channel was supplied
```

The defensible status is:

```text
No Fermi-LAT/GCE confirmation. The state remains a conditional sterile
dark-matter benchmark, not an explanation of the Galactic Center GeV Excess.
```

## References

- NASA/Fermi public summaries report GCE-compatible dark matter masses around
  31--40 GeV in early analyses.
- Reviews of the GCE typically quote masses of tens of GeV and annihilation
  cross sections near `1e-26 cm^3/s`, depending on channel.
- Fermi-LAT gamma-ray line and diffuse-photon searches constrain visible
  annihilation or decay channels; a p-value requires the actual likelihood and
  spectral model.
