# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 123698
- finite residual rows: 123698
- observable: `CIII_1908_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.267788
- axis RA: 175.376 deg
- axis DEC: 52.217 deg
- fitted pixels: 355
- block-null p-value: 0.9660678642714571
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_ciii_1908_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|---------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    129254 |           2873 |                       2683 |                          0 |    123698 |        5556 | CIII_1908_EW        |       0.172451 |        77.7755 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |  13.0684      |
| z                     |  -3.09062     |
| z2                    |   3.32037     |
| LOGMSTAR              |  -0.775972    |
| RCHI2_LINE            |  -0.0360749   |
| DELTA_LINECHI2        |   0.045514    |
| FLUX_SYNTH_G          |  -0.0192851   |
| FLUX_SYNTH_R          |  -1.22851     |
| FLUX_SYNTH_Z          |  -0.10661     |
| FLUX_G                |   2.00503     |
| FLUX_R                |  -1.18854     |
| FLUX_Z                |  -0.230886    |
| FLUX_W1               |   0.489753    |
| FLUX_W2               |   0.360881    |
| template_0_ebv        |  -0.102264    |
| template_1_stardens   |   0.076285    |
| template_2_galdepth_g |  -0.0291795   |
| template_3_galdepth_r |   0.0469056   |
| template_4_galdepth_z |   0.224003    |
| template_5_psfsize_g  |  -0.0248055   |
| template_6_psfsize_r  |  -0.043146    |
| template_7_psfsize_z  |  -0.0581687   |
| template_8_cosky_g    |   0.296464    |
| template_9_cosky_r    |   0.000365842 |
| template_10_cosky_z   |  -0.0379559   |

## Figures

- `outputs/figures/qso_highz_line_sgc_z2p1_3p5_ciii_1908_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_sgc_z2p1_3p5_ciii_1908_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
