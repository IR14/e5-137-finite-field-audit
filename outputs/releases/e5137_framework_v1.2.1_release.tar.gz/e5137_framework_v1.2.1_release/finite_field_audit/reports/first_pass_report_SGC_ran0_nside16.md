# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |    dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|-----------:|---------------:|
| LRG      | SGC      |     0.4 |     0.6 |   160150 |    1177401 |   0.0690917 |       0.0317686 |  46.9575 |  20.253    |       0.669421 |
| LRG      | SGC      |     0.6 |     0.8 |   237939 |    1786229 |   0.0442626 |       0.0264255 | 124.353  |  72.8501   |       0.826446 |
| LRG      | SGC      |     0.8 |     1.1 |   264403 |    1995903 |   0.0548003 |       0.0377657 | 184.996  |   5.01388  |       0.628099 |
| ELG      | SGC      |     0.8 |     1.1 |   249883 |    2101655 |   0.0863959 |       0.0211089 | 204.24   | -51.2755   |       0.338843 |
| ELG      | SGC      |     1.1 |     1.4 |   242543 |    2015860 |   0.0624252 |       0.0202362 | 196.395  | -44.7698   |       0.528926 |
| ELG      | SGC      |     1.4 |     1.6 |   118324 |     972687 |   0.0540365 |       0.0250802 |  39.3452 | -36.8335   |       0.85124  |
| QSO      | SGC      |     0.8 |     1.2 |    72742 |    1102839 |   0.0196163 |       0.0188506 |   9.3924 |  36.3187   |       0.966942 |
| QSO      | SGC      |     1.2 |     1.6 |   104480 |    1577445 |   0.05144   |       0.0290798 |  17.7737 | -10.0954   |       0.578512 |
| QSO      | SGC      |     1.6 |     2.1 |   123696 |    1874214 |   0.0213089 |       0.018359  | 190.935  | -45.0937   |       0.975207 |
| QSO      | SGC      |     2.1 |     3.5 |   129254 |    1957439 |   0.0171247 |       0.0143593 | 263.096  |  -0.889751 |       0.958678 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| LRG 0.400-0.600 | LRG 0.600-0.800 |         66.9745  |
| LRG 0.400-0.600 | LRG 0.800-1.100 |        131.659   |
| LRG 0.400-0.600 | ELG 0.800-1.100 |        144.236   |
| LRG 0.400-0.600 | ELG 1.100-1.400 |        144.816   |
| LRG 0.400-0.600 | ELG 1.400-1.600 |         57.5369  |
| LRG 0.400-0.600 | QSO 0.800-1.200 |         36.4656  |
| LRG 0.400-0.600 | QSO 1.200-1.600 |         41.7789  |
| LRG 0.400-0.600 | QSO 1.600-2.100 |        141.337   |
| LRG 0.400-0.600 | QSO 2.100-3.500 |        139.725   |
| LRG 0.600-0.800 | LRG 0.800-1.100 |         76.8489  |
| LRG 0.600-0.800 | ELG 0.800-1.100 |        135.486   |
| LRG 0.600-0.800 | ELG 1.100-1.400 |        127.474   |
| LRG 0.600-0.800 | ELG 1.400-1.600 |        123.525   |
| LRG 0.600-0.800 | QSO 0.800-1.200 |         62.2459  |
| LRG 0.600-0.800 | QSO 1.200-1.600 |        104.497   |
| LRG 0.600-0.800 | QSO 1.600-2.100 |        126.444   |
| LRG 0.600-0.800 | QSO 2.100-3.500 |        103.679   |
| LRG 0.800-1.100 | ELG 0.800-1.100 |         58.6558  |
| LRG 0.800-1.100 | ELG 1.100-1.400 |         50.8224  |
| LRG 0.800-1.100 | ELG 1.400-1.600 |        135.29    |
| LRG 0.800-1.100 | QSO 0.800-1.200 |        138.463   |
| LRG 0.800-1.100 | QSO 1.200-1.600 |        166.357   |
| LRG 0.800-1.100 | QSO 1.600-2.100 |         50.3888  |
| LRG 0.800-1.100 | QSO 2.100-3.500 |         78.2266  |
| ELG 0.800-1.100 | ELG 1.100-1.400 |          8.34825 |
| ELG 0.800-1.100 | ELG 1.400-1.600 |         90.8996  |
| ELG 0.800-1.100 | QSO 0.800-1.200 |        161.675   |
| ELG 0.800-1.100 | QSO 1.200-1.600 |        118.374   |
| ELG 0.800-1.100 | QSO 1.600-2.100 |         10.7867  |
| ELG 0.800-1.100 | QSO 2.100-3.500 |         70.3897  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
