# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/LRG_NGC_clustering.dat.fits`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 1
- redshift range: `0.4` to `0.6`

## Sample

- joined rows on TARGETID: 49453
- finite residual rows: 49453
- observable: `DN4000_MODEL`
- controls: `z; z2; LOGMSTAR`

## Dipole Fit

- amplitude: 0.217658
- axis RA: 161.503 deg
- axis DEC: -9.200 deg
- fitted pixels: 76
- block-null p-value: 0.23809523809523808
- block-null mocks: 20

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_rchi2_cont |   n_fail_deltachi2 |   n_fail_dn4000_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------:|-------------------:|---------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |     50000 |              2 |                  69 |                189 |                  287 |                          0 |     49453 |         547 | DN4000_MODEL        |        1.23249 |         2.2263 |

## Residual Model Coefficients

| term      |   coefficient |
|:----------|--------------:|
| intercept |    1.67427    |
| z         |    0.305152   |
| z2        |   -0.378383   |
| LOGMSTAR  |    0.00584287 |

## Figures

- `outputs/figures/fastspecfit_phase2_smoke_lrg_ngc_dn4000_model_z0p4_0p6_residual_vs_z.png`
- `outputs/figures/fastspecfit_phase2_smoke_lrg_ngc_dn4000_model_z0p4_0p6_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
