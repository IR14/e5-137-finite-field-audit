# Look-elsewhere summary

Input: LRG, ELG, and QSO over NGC and SGC using DESI DR1 LSS catalogs, random catalogs 0..2, nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

- Number of tested tracer/region/redshift bins: 20
- Minimum permutation p-value: 0.059988
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.985803

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |    ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|----------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | ELG      | SGC      | 0.8-1.1 |   249883 |    6305110 |   0.0895234 | 205.204   | -50.8367  |       0.059988 |              1 |   0.985803 |        0.00019996 |                        64.5112 |
|           2 | ELG      | SGC      | 1.1-1.4 |   242543 |    6047145 |   0.0712978 | 195.697   | -33.7683  |       0.202759 |              1 |   0.985803 |        0.00019996 |                        12.9547 |
|           3 | LRG      | NGC      | 0.4-0.6 |   346761 |    6662611 |   0.0548598 |   2.45243 | -28.9195  |       0.207159 |              1 |   0.985803 |        0.00019996 |                        13.454  |
|           4 | ELG      | NGC      | 0.8-1.1 |   766482 |   12306203 |   0.037979  | 189.991   | -12.465   |       0.336733 |              1 |   0.985803 |        0.00019996 |                        17.2636 |
|           5 | ELG      | SGC      | 1.4-1.6 |   118324 |    2917069 |   0.0731271 |  33.1967  | -37.3276  |       0.357329 |              1 |   0.985803 |        0.0009998  |                        53.1112 |
|           6 | LRG      | SGC      | 0.8-1.1 |   264403 |    5986866 |   0.0547439 | 186.462   |   2.23186 |       0.446111 |              1 |   0.985803 |        0.00039992 |                        24.9732 |
|           7 | LRG      | SGC      | 0.4-0.6 |   160150 |    3535898 |   0.0604041 |  51.5389  |  16.8271  |       0.486103 |              1 |   0.985803 |        0.0029994  |                        17.189  |
|           8 | QSO      | SGC      | 1.2-1.6 |   104480 |    4735179 |   0.047816  |  16.1903  | -15.8744  |       0.528694 |              1 |   0.985803 |        0.0605879  |                        16.3641 |
|           9 | ELG      | NGC      | 1.1-1.4 |   715801 |   11438144 |   0.0240728 | 196.627   | -32.873   |       0.661668 |              1 |   0.985803 |        0.0029994  |                        26.0671 |
|          10 | LRG      | NGC      | 0.6-0.8 |   533955 |   10177952 |   0.0248201 | 345.016   | -23.9449  |       0.692861 |              1 |   0.985803 |        0.00459908 |                        48.2517 |

## Closest axes among overlapping redshift intervals

| region   | left        | right       |   z_overlap |   axis_separation_deg |   left_p |   right_p |
|:---------|:------------|:------------|------------:|----------------------:|---------:|----------:|
| SGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |               26.1983 | 0.357329 |  0.528694 |
| NGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |               47.5556 | 0.336733 |  0.746051 |
| SGC      | ELG 0.8-1.1 | LRG 0.8-1.1 |         0.3 |               55.4312 | 0.059988 |  0.446111 |
| NGC      | ELG 1.4-1.6 | QSO 1.2-1.6 |         0.2 |               97.405  | 0.856029 |  0.985803 |
| NGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              113.014  | 0.336733 |  0.858228 |
| NGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |              118.829  | 0.661668 |  0.985803 |
| NGC      | LRG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              120.583  | 0.746051 |  0.858228 |
| SGC      | ELG 1.1-1.4 | QSO 1.2-1.6 |         0.2 |              130.355  | 0.202759 |  0.528694 |
| NGC      | ELG 1.1-1.4 | QSO 0.8-1.2 |         0.1 |              131.682  | 0.661668 |  0.858228 |
| SGC      | ELG 0.8-1.1 | QSO 0.8-1.2 |         0.3 |              145.047  | 0.059988 |  0.929814 |

## Interpretation

No directional claim should be made from local p-values without accounting for the
number of tracer, region, redshift, resolution, weight, and split tests that were tried.
Poisson p-values are shot-noise diagnostics only; the permutation p-value is the
first-pass null statistic used for this correction table.
