# Injection recovery

- Map: `data/processed/ELG_NGC_SGC_z0p800_1p100_nside32_combined_template_regressed_raw_map.npz`
- External templates: 11

This diagnostic injects a known dipole into a fixed observed map. Recovery is measured
by subtracting the baseline fitted vector before and after injection, so the table
reports
the recovered injected component rather than the map's pre-existing residual.

| axis_name    |   axis_ra_deg |   axis_dec_deg | stage                              |   injected_amplitude |   baseline_amplitude |   absolute_fit_amplitude |   recovered_amplitude |   recovery_fraction |   recovered_ra_deg |   recovered_dec_deg |   axis_error_deg |
|:-------------|--------------:|---------------:|:-----------------------------------|---------------------:|---------------------:|-------------------------:|----------------------:|--------------------:|-------------------:|--------------------:|-----------------:|
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.01 |            0.0328003 |                0.0330068 |            0.01       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.01 |            0.0293449 |                0.0330178 |            0.00544238 |            0.544238 |            238.252 |            -19.2606 |          49.7083 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.02 |            0.0328003 |                0.0360976 |            0.02       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.02 |            0.0293449 |                0.0371276 |            0.0108848  |            0.544238 |            238.252 |            -19.2606 |          49.7083 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.03 |            0.0328003 |                0.0414322 |            0.03       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.03 |            0.0293449 |                0.041545  |            0.0163271  |            0.544238 |            238.252 |            -19.2606 |          49.7083 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.05 |            0.0328003 |                0.0560696 |            0.05       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.05 |            0.0293449 |                0.050978  |            0.0272119  |            0.544238 |            238.252 |            -19.2606 |          49.7083 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.01 |            0.0328003 |                0.0428003 |            0.01       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.01 |            0.0293449 |                0.0331731 |            0.00386293 |            0.386293 |            230.712 |            -62.5571 |          13.8696 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.02 |            0.0328003 |                0.0528003 |            0.02       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.02 |            0.0293449 |                0.0370085 |            0.00772587 |            0.386293 |            230.712 |            -62.5571 |          13.8696 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.03 |            0.0328003 |                0.0628003 |            0.03       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.03 |            0.0293449 |                0.0408491 |            0.0115888  |            0.386293 |            230.712 |            -62.5571 |          13.8696 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.05 |            0.0328003 |                0.0828003 |            0.05       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.05 |            0.0293449 |                0.048541  |            0.0193147  |            0.386293 |            230.712 |            -62.5571 |          13.8696 |
