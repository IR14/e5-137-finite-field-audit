# Nside robustness report

This report checks whether first-pass dipole axes are stable under changes
to the HEALPix map resolution. Stable axes are not by themselves evidence
for a cosmological signal; unstable axes are a warning sign for pixelization,
noise, footprint, or selection effects.

## Grid

|   nside | tracer   | region   |   z_min |   z_max |   amplitude |   ra_deg |   dec_deg |   null_p_value |
|--------:|:---------|:---------|--------:|--------:|------------:|---------:|----------:|---------------:|
|      16 | ELG      | SGC      |     0.8 |     1.1 |   0.0887852 | 206.126  |  -53.8629 |      0.29854   |
|      16 | ELG      | SGC      |     1.1 |     1.4 |   0.0729452 | 194.958  |  -39.4103 |      0.381324  |
|      16 | ELG      | SGC      |     1.4 |     1.6 |   0.0627376 |  39.8861 |  -40.5158 |      0.583483  |
|      32 | ELG      | SGC      |     0.8 |     1.1 |   0.0898115 | 204.939  |  -51.9442 |      0.0607878 |
|      32 | ELG      | SGC      |     1.1 |     1.4 |   0.0733176 | 194.738  |  -37.1618 |      0.156569  |
|      32 | ELG      | SGC      |     1.4 |     1.6 |   0.0659999 |  37.8017 |  -40.4783 |      0.419316  |
|      64 | ELG      | SGC      |     0.8 |     1.1 |   0.089502  | 204.881  |  -52.2179 |      0.0261948 |
|      64 | ELG      | SGC      |     1.1 |     1.4 |   0.0736669 | 194.862  |  -37.7024 |      0.0869826 |
|      64 | ELG      | SGC      |     1.4 |     1.6 |   0.0649257 |  38.517  |  -41.0587 |      0.320936  |

## Axis stability

| tracer   | region   |   z_min |   z_max |   nside_count |   max_axis_shift_deg |   median_axis_shift_deg |   amplitude_min |   amplitude_max |   amplitude_range |   p_value_min |   p_value_max |
|:---------|:---------|--------:|--------:|--------------:|---------------------:|------------------------:|----------------:|----------------:|------------------:|--------------:|--------------:|
| ELG      | SGC      |     0.8 |     1.1 |             3 |              2.04786 |                 1.80713 |       0.0887852 |       0.0898115 |       0.00102634  |     0.0261948 |      0.29854  |
| ELG      | SGC      |     1.1 |     1.4 |             3 |              2.25519 |                 1.70958 |       0.0729452 |       0.0736669 |       0.000721698 |     0.0869826 |      0.381324 |
| ELG      | SGC      |     1.4 |     1.6 |             3 |              1.58541 |                 1.17017 |       0.0627376 |       0.0659999 |       0.00326233  |     0.320936  |      0.583483 |

## Interpretation rule

- Large axis shifts across nside weaken any directional interpretation.
- High p-values remain compatible with the isotropic null model.
- A bin that is stable in nside still needs random-catalog, NGC/SGC, and systematics checks.

