# DESI FastSpecFit binned residual-gradient sweep

Status: completed local binned sweep over LRG/ELG, NGC/SGC, DN4000/ZZSUN/AGE.

This is still an estimator/diagnostic report, not a detection claim. The amplitudes below need null calibration and systematics-template regression before physical interpretation.

- VAC: `data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- summary CSV: `outputs/tables/desi_fastspecfit_gradient_bins_summary.csv`
- successful runs: 36 / 36

## Successful Runs

| tracer   | region   | observable   |   z_min |   z_max |   n_joined |   amplitude |    ra_deg |    dec_deg |   n_pixels | report_path                                                                          |
|:---------|:---------|:-------------|--------:|--------:|-----------:|------------:|----------:|-----------:|-----------:|:-------------------------------------------------------------------------------------|
| LRG      | NGC      | DN4000       |     0.4 |     0.6 |     346759 |   0.0296349 | 359.767   | -12.6002   |        643 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_z0p4_0p6.md |
| LRG      | NGC      | DN4000       |     0.6 |     0.8 |     533954 |   0.0744719 | 193.31    |   8.13639  |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_z0p6_0p8.md |
| LRG      | NGC      | DN4000       |     0.8 |     1.1 |     595418 |   0.0144046 |   7.77    | -17.3711   |        644 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_dn4000_z0p8_1p1.md |
| LRG      | NGC      | ZZSUN        |     0.4 |     0.6 |     346759 |   0         | nan       | nan        |        643 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_zzsun_z0p4_0p6.md  |
| LRG      | NGC      | ZZSUN        |     0.6 |     0.8 |     533954 |   0         | nan       | nan        |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_zzsun_z0p6_0p8.md  |
| LRG      | NGC      | ZZSUN        |     0.8 |     1.1 |     595418 |   0         | nan       | nan        |        644 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_zzsun_z0p8_1p1.md  |
| LRG      | NGC      | AGE          |     0.4 |     0.6 |     346759 |   0.21763   |   1.81222 |  48.776    |        643 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_age_z0p4_0p6.md    |
| LRG      | NGC      | AGE          |     0.6 |     0.8 |     533954 |   0.272881  | 356.971   |  64.3093   |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_age_z0p6_0p8.md    |
| LRG      | NGC      | AGE          |     0.8 |     1.1 |     595418 |   0.209663  | 343.102   |  61.2636   |        644 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_ngc_age_z0p8_1p1.md    |
| LRG      | SGC      | DN4000       |     0.4 |     0.6 |     160150 |   0.0663233 | 178.552   |  64.0837   |        362 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_z0p4_0p6.md |
| LRG      | SGC      | DN4000       |     0.6 |     0.8 |     237939 |   0.0433357 | 179.176   |  58.7124   |        366 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_z0p6_0p8.md |
| LRG      | SGC      | DN4000       |     0.8 |     1.1 |     264403 |   0.0265244 | 178.143   |  57.8851   |        367 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_dn4000_z0p8_1p1.md |
| LRG      | SGC      | ZZSUN        |     0.4 |     0.6 |     160150 |   0         | nan       | nan        |        362 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_zzsun_z0p4_0p6.md  |
| LRG      | SGC      | ZZSUN        |     0.6 |     0.8 |     237939 |   0         | nan       | nan        |        366 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_zzsun_z0p6_0p8.md  |
| LRG      | SGC      | ZZSUN        |     0.8 |     1.1 |     264403 |   0         | nan       | nan        |        367 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_zzsun_z0p8_1p1.md  |
| LRG      | SGC      | AGE          |     0.4 |     0.6 |     160150 |   0.216541  |  87.6513  |  69.9322   |        362 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_age_z0p4_0p6.md    |
| LRG      | SGC      | AGE          |     0.6 |     0.8 |     237939 |   0.284021  | 184.825   |  59.87     |        366 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_age_z0p6_0p8.md    |
| LRG      | SGC      | AGE          |     0.8 |     1.1 |     264403 |   0.20819   | 185.549   |  41.3753   |        367 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_lrg_sgc_age_z0p8_1p1.md    |
| ELG      | NGC      | DN4000       |     0.8 |     1.1 |     766480 |   0.0622043 |  33.7662  | -48.9779   |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_z0p8_1p1.md |
| ELG      | NGC      | DN4000       |     1.1 |     1.3 |     490230 |   0.213556  |  17.5423  | -34.4368   |        638 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_z1p1_1p3.md |
| ELG      | NGC      | DN4000       |     1.3 |     1.6 |     564607 |   0.101509  | 194.156   |  47.4622   |        637 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_dn4000_z1p3_1p6.md |
| ELG      | NGC      | ZZSUN        |     0.8 |     1.1 |     766480 |   0         | nan       | nan        |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_zzsun_z0p8_1p1.md  |
| ELG      | NGC      | ZZSUN        |     1.1 |     1.3 |     490230 |   0         | nan       | nan        |        638 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_zzsun_z1p1_1p3.md  |
| ELG      | NGC      | ZZSUN        |     1.3 |     1.6 |     564607 |   0         | nan       | nan        |        637 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_zzsun_z1p3_1p6.md  |
| ELG      | NGC      | AGE          |     0.8 |     1.1 |     766480 |   0.313193  | 186.07    |  85.9864   |        640 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_age_z0p8_1p1.md    |
| ELG      | NGC      | AGE          |     1.1 |     1.3 |     490230 |   0.240621  | 342.461   |  67.5202   |        638 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_age_z1p1_1p3.md    |
| ELG      | NGC      | AGE          |     1.3 |     1.6 |     564607 |   0.358335  | 343.703   |  77.2123   |        637 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_ngc_age_z1p3_1p6.md    |
| ELG      | SGC      | DN4000       |     0.8 |     1.1 |     249879 |   0.112389  | 185.153   |   8.16235  |        363 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_z0p8_1p1.md |
| ELG      | SGC      | DN4000       |     1.1 |     1.3 |     164598 |   2.49448   | 354.734   |   0.778532 |        359 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_z1p1_1p3.md |
| ELG      | SGC      | DN4000       |     1.3 |     1.6 |     196263 |   0.790125  |  12.9957  |  11.6205   |        360 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_dn4000_z1p3_1p6.md |
| ELG      | SGC      | ZZSUN        |     0.8 |     1.1 |     249879 |   0         | nan       | nan        |        363 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_zzsun_z0p8_1p1.md  |
| ELG      | SGC      | ZZSUN        |     1.1 |     1.3 |     164598 |   0         | nan       | nan        |        359 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_zzsun_z1p1_1p3.md  |
| ELG      | SGC      | ZZSUN        |     1.3 |     1.6 |     196263 |   0         | nan       | nan        |        360 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_zzsun_z1p3_1p6.md  |
| ELG      | SGC      | AGE          |     0.8 |     1.1 |     249879 |   0.479276  | 167.05    |  80.2484   |        363 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_age_z0p8_1p1.md    |
| ELG      | SGC      | AGE          |     1.1 |     1.3 |     164598 |   0.419318  | 168.809   |  74.4176   |        359 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_age_z1p1_1p3.md    |
| ELG      | SGC      | AGE          |     1.3 |     1.6 |     196263 |   0.508344  | 186.823   |  67.3122   |        360 | outputs/tables/fastspecfit_bins/desi_fastspecfit_gradient_elg_sgc_age_z1p3_1p6.md    |

## Failed Runs

_No failed runs._

## Figures

- `outputs/figures/desi_fastspecfit_bins_dn4000_amplitude_vs_z.png`
- `outputs/figures/desi_fastspecfit_bins_zzsun_amplitude_vs_z.png`
- `outputs/figures/desi_fastspecfit_bins_age_amplitude_vs_z.png`
- `outputs/figures/desi_fastspecfit_bins_axis_scatter.png`

## Next Checks

- Treat large SGC amplitudes as systematics/coverage diagnostics until null tests are attached.
- Add imaging templates where available: dust/extinction, stellar density, depth, seeing, sky brightness.
- Calibrate density-like estimator on EZmock ensemble; population residuals require permutation/block bootstrap or a mock population assignment model because EZmocks do not contain FastSpecFit stellar-population observables.
