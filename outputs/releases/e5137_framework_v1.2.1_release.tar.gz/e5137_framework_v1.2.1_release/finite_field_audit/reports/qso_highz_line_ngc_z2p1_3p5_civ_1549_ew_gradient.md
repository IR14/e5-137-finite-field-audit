# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 228136
- finite residual rows: 228136
- observable: `CIV_1549_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.452652
- axis RA: 32.986 deg
- axis DEC: -45.106 deg
- fitted pixels: 633
- block-null p-value: 0.9540918163672655
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_civ_1549_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    237300 |           4268 |                      4896 |                          0 |    228136 |        9164 | CIV_1549_EW         |        1.11785 |        187.891 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   30.771      |
| z                     |  -22.8466     |
| z2                    |   22.7624     |
| LOGMSTAR              |   -5.71312    |
| RCHI2_LINE            |   -0.177026   |
| DELTA_LINECHI2        |    0.0248039  |
| FLUX_SYNTH_G          |    0.168904   |
| FLUX_SYNTH_R          |   -1.71439    |
| FLUX_SYNTH_Z          |    0.655433   |
| FLUX_G                |    3.54239    |
| FLUX_R                |   -2.55826    |
| FLUX_Z                |   -0.00982483 |
| FLUX_W1               |    1.96251    |
| FLUX_W2               |   -1.41699    |
| template_0_ebv        |    0.0356153  |
| template_1_stardens   |    0.0982029  |
| template_2_galdepth_g |    0.0293776  |
| template_3_galdepth_r |    0.12311    |
| template_4_galdepth_z |    0.361902   |
| template_5_psfsize_g  |   -0.870024   |
| template_6_psfsize_r  |    0.55637    |
| template_7_psfsize_z  |   -0.387626   |
| template_8_cosky_g    |   -2.47996    |
| template_9_cosky_r    |    1.88966    |
| template_10_cosky_z   |    0.662771   |

## Figures

- `outputs/figures/qso_highz_line_ngc_z2p1_3p5_civ_1549_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_ngc_z2p1_3p5_civ_1549_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
