# e-5-137 Lagrangian first-pass audit

Status: local effective-field-theory bookkeeping, not a completed physical model.

## Trial Lagrangian

Use a dimensionless phase x = phi / f and mu = f / M_Pl.

```text
L = (M_Pl^2 / 2) R - 1/2 (partial phi)^2 - Lambda^4 U(phi/f)
U(x) = 1 + sum_i a_i cos(k_i x)
lambda(phi) = M_Pl V_phi / V = (1/mu) U_x / U
m_eff^2 / H0^2 = 3 Omega_DE0 (1/mu^2) U_xx / U
local 1 + w ~= Omega_DE0 lambda^2 / 3
```

This is a local slow-roll/slope audit. It does not integrate the full
background equation of motion, so the `wa` target is recorded but not fitted.

## Frozen project numbers

| quantity | value |
|:--|--:|
| q | 0.00886061187429 |
| delta_phi | 0.0590055838384 |
| s | 0.00116140973289 |
| T5 | 0.147151776469 |
| project w0 target | -0.751994852742 |
| project wa target | -0.860064969598 |
| lambda needed for project w0 at Omega_DE0=0.69 | 1.03840418381 |

## Variant summary

| variant               |    u_min |   u_max |   max_abs_ux_over_u |   mu_required_for_project_w0 |   m2_over_h0_sq_at_mu_required |   mu_min_for_worst_curvature_below_h0 |
|:----------------------|---------:|--------:|--------------------:|-----------------------------:|-------------------------------:|--------------------------------------:|
| q_delta               | 0.932134 | 1.06787 |            0.304468 |                     0.293207 |                        2.23247 |                               1.81536 |
| q_delta_137_1over137  | 0.924835 | 1.07517 |            1.31674  |                     1.26804  |                        2.30535 |                              17.6057  |
| q_delta_137_1over1372 | 0.932081 | 1.06792 |            0.31122  |                     0.29971  |                        2.23439 |                               2.34874 |

Reading rule: `mu_required_for_project_w0` is the field-range scale needed
at the steepest phase point to reproduce the project-level `w0` target.
`mu_min_for_worst_curvature_below_h0` is a conservative softness check:
if mu is lower than that value, some parts of the potential are heavier
than H0 in curvature units.

## Fixed-mu scan

| variant               |   mu_f_over_mpl |   best_local_w0 |   phase_x |   lambda_mpl_vprime_over_v |   m2_over_h0_sq |   target_abs_error |
|:----------------------|----------------:|----------------:|----------:|---------------------------:|----------------:|-------------------:|
| q_delta               |             0.3 |       -0.763099 |   1.58331 |                -1.01489    |     2.13252     |        0.0111038   |
| q_delta               |             1   |       -0.978679 |   1.58331 |                -0.304468   |     0.191926    |        0.226684    |
| q_delta               |             5   |       -0.999147 |   1.58331 |                -0.0608935  |     0.00767706  |        0.247152    |
| q_delta               |            10   |       -0.999787 |   1.58331 |                -0.0304468  |     0.00191926  |        0.247792    |
| q_delta               |            20   |       -0.999947 |   1.58331 |                -0.0152234  |     0.000479816 |        0.247952    |
| q_delta               |            50   |       -0.999991 |   1.58331 |                -0.00608935 |     7.67706e-05 |        0.247997    |
| q_delta_137_1over137  |             0.3 |       -0.751997 |   2.88951 |                -1.0384     | -3201.46        |        1.73141e-06 |
| q_delta_137_1over137  |             1   |       -0.751995 |   1.65714 |                -1.0384     |  -193.35        |        1.4114e-07  |
| q_delta_137_1over137  |             5   |       -0.984049 |   2.90088 |                -0.263348   |     0.148274    |        0.232054    |
| q_delta_137_1over137  |            10   |       -0.996012 |   2.90088 |                -0.131674   |     0.0370685   |        0.244017    |
| q_delta_137_1over137  |            20   |       -0.999003 |   2.90088 |                -0.0658371  |     0.00926712  |        0.247008    |
| q_delta_137_1over137  |            50   |       -0.99984  |   2.90088 |                -0.0263348  |     0.00148274  |        0.247846    |
| q_delta_137_1over1372 |             0.3 |       -0.752474 |   1.57147 |                -1.0374     |     2.23008     |        0.000478953 |
| q_delta_137_1over1372 |             1   |       -0.977723 |   1.57147 |                -0.31122    |     0.200707    |        0.225728    |
| q_delta_137_1over1372 |             5   |       -0.999109 |   1.57147 |                -0.0622441  |     0.00802828  |        0.247114    |
| q_delta_137_1over1372 |            10   |       -0.999777 |   1.57147 |                -0.031122   |     0.00200707  |        0.247782    |
| q_delta_137_1over1372 |            20   |       -0.999944 |   1.57147 |                -0.015561   |     0.000501768 |        0.247949    |
| q_delta_137_1over1372 |            50   |       -0.999991 |   1.57147 |                -0.00622441 |     8.02828e-05 |        0.247996    |

## First physical readout

- The low-frequency `q_delta` potential is naturally soft for mu above
  roughly 1.8, but then it stays extremely close to w = -1. To reproduce
  the project's w0 ~= -0.752 locally, it needs mu ~= 0.293 and an
  effective curvature of order 2.23 H0^2 at the steepest phase point.
- A literal `cos(137 x)/137` term can produce the required slope with
  mu of order 1, but its worst-case curvature is severe; keeping all
  such modes softer than H0 requires mu ~= 17.6.
- Replacing the literal 137 amplitude by 1/137^2 tames curvature, but the
  model again behaves much like the low-frequency case and needs
  sub-Planckian mu to reach the project w0 target.
- Therefore the first Lagrangian gate is clear: the 137 structure cannot
  be inserted as a naive high-frequency dark-energy harmonic unless the
  model accepts a very large field range, suppresses the harmonic, or
  moves the 137 sector into another field/operator rather than directly
  into the quintessence potential.
