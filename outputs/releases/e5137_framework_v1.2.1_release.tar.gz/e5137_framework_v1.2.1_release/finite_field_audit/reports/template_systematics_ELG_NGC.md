# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| ELG      | NGC      |     0.8 |     1.1 |            20 |              0.0896887 |       0.0370462 |           0.391722 |                 0.073963 |            0.00455422 |                 0.994801 |                       0.952524 |                           0.122933 |                          50.9722  |
| ELG      | NGC      |     1.1 |     1.4 |            20 |              0.0620863 |       0.0252578 |           0.75165  |                 0.137931 |            0.00795293 |                 0.984803 |                       0.782109 |                           0.31487  |                           4.84674 |
| ELG      | NGC      |     1.4 |     1.6 |            20 |              0.0474012 |       0.0156957 |           0.978204 |                 0.773613 |            0.00579143 |                 0.9986   |                       0.98051  |                           0.368983 |                          40.3997  |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| ELG      | NGC      |     0.8 |     1.1 | intercept                          |  -0.00659992  |
| ELG      | NGC      |     0.8 |     1.1 | photsys=N                          |  -0.00730485  |
| ELG      | NGC      |     0.8 |     1.1 | ntile                              |  -0.125596    |
| ELG      | NGC      |     0.8 |     1.1 | frac_tlobs_tiles                   |  -0.0570704   |
| ELG      | NGC      |     0.8 |     1.1 | nx                                 |   0.187516    |
| ELG      | NGC      |     0.8 |     1.1 | weight_sys                         |  -0.000625118 |
| ELG      | NGC      |     0.8 |     1.1 | weight_sn                          |  -0.000625118 |
| ELG      | NGC      |     0.8 |     1.1 | weight_rf                          |  -0.0369239   |
| ELG      | NGC      |     0.8 |     1.1 | weight_zfail                       |  -0.00196157  |
| ELG      | NGC      |     0.8 |     1.1 | weight_comp                        |  -0.0221318   |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_ebv        |  -1.4349e-05  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00875855  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |   0.00450508  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |   0.00123803  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |   0.000126828 |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.00706401  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |  -0.00291474  |
| ELG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |   0.00409202  |
| ELG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |   0.00808971  |
| ELG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.00445285  |
| ELG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |  -0.00815727  |
| ELG      | NGC      |     1.1 |     1.4 | intercept                          |  -0.00816027  |
| ELG      | NGC      |     1.1 |     1.4 | photsys=N                          |   0.110134    |
| ELG      | NGC      |     1.1 |     1.4 | ntile                              |  -0.178125    |
| ELG      | NGC      |     1.1 |     1.4 | frac_tlobs_tiles                   |  -0.0355765   |
| ELG      | NGC      |     1.1 |     1.4 | nx                                 |   0.219812    |
| ELG      | NGC      |     1.1 |     1.4 | weight_sys                         |   0.0124288   |
| ELG      | NGC      |     1.1 |     1.4 | weight_sn                          |   0.0124288   |
| ELG      | NGC      |     1.1 |     1.4 | weight_rf                          |  -0.0965637   |
| ELG      | NGC      |     1.1 |     1.4 | weight_zfail                       |  -0.012662    |
| ELG      | NGC      |     1.1 |     1.4 | weight_comp                        |  -0.012313    |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_ebv        |  -0.00564325  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_stardens   |  -0.00405695  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_g |   0.00376342  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_r |   0.00166975  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_galdepth_z |  -0.000579202 |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_g  |   0.00706715  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_r  |   0.00266151  |
| ELG      | NGC      |     1.1 |     1.4 | external:pixweight_dark_psfsize_z  |   0.0031459   |
| ELG      | NGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_g |   0.00809749  |
| ELG      | NGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_r |   0.00704333  |
| ELG      | NGC      |     1.1 |     1.4 | external:legacy_dr9_bricks_cosky_z |  -0.0121964   |
| ELG      | NGC      |     1.4 |     1.6 | intercept                          |  -0.0107426   |
| ELG      | NGC      |     1.4 |     1.6 | photsys=N                          |   0.113829    |
| ELG      | NGC      |     1.4 |     1.6 | ntile                              |   0.0256266   |
| ELG      | NGC      |     1.4 |     1.6 | frac_tlobs_tiles                   |   0.0295864   |
| ELG      | NGC      |     1.4 |     1.6 | nx                                 |  -0.0411974   |
| ELG      | NGC      |     1.4 |     1.6 | weight_sys                         |   0.0118546   |
| ELG      | NGC      |     1.4 |     1.6 | weight_sn                          |   0.0118546   |
| ELG      | NGC      |     1.4 |     1.6 | weight_rf                          |  -0.124337    |
| ELG      | NGC      |     1.4 |     1.6 | weight_zfail                       |  -0.00187931  |
| ELG      | NGC      |     1.4 |     1.6 | weight_comp                        |  -0.0217267   |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_ebv        |   0.000722176 |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_stardens   |   0.00442865  |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_g |  -0.00196088  |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_r |  -0.017484    |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_galdepth_z |   0.00782823  |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_g  |  -0.00385466  |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_r  |  -0.00381262  |
| ELG      | NGC      |     1.4 |     1.6 | external:pixweight_dark_psfsize_z  |   0.00448816  |
| ELG      | NGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_g |   0.0326659   |
| ELG      | NGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.0143497   |
| ELG      | NGC      |     1.4 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.00622182  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
