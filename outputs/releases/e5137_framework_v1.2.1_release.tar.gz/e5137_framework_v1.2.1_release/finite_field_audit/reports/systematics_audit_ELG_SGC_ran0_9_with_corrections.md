# ELG SGC systematics audit with look-elsewhere corrections

This audit uses DESI DR1 LSS ELG_LOPnotqso SGC with random catalogs 0..9, nside=32, 1000 permutation nulls per split, 1000 Poisson mocks, 120 bootstrap samples, and 8 jackknife regions.

Scientific caution: these split tests are diagnostics for survey geometry and selection effects. Low uncorrected p-values inside split subsets are not cosmological evidence by themselves.

- Number of split tests: 36
- Minimum uncorrected p-value: 0.002997
- Minimum Bonferroni-adjusted p-value: 0.107892
- Minimum BH-FDR adjusted p-value: 0.107892

## Lowest p-value rows

| split_name     |   null_p_value |   bonferroni_p |   bh_fdr_p |
|:---------------|---------------:|---------------:|-----------:|
| 1              |       0.002997 |         0.1079 |     0.1079 |
| q1_0.167_0.617 |       0.007992 |         0.2877 |     0.1439 |
| q1_0.167_0.617 |       0.05095  |         1      |     0.6114 |
| 1              |       0.0979   |         1      |     0.8811 |
| 0_90           |       0.1459   |         1      |     0.9238 |
| 0_90           |       0.1958   |         1      |     0.9238 |
| 7              |       0.2058   |         1      |     0.9238 |
| 3              |       0.2647   |         1      |     0.9238 |
| 2              |       0.3646   |         1      |     0.9238 |
| q2_0.617_0.77  |       0.4505   |         1      |     0.9238 |
| 3              |       0.4835   |         1      |     0.9238 |
| q3_0.77_1      |       0.4935   |         1      |     0.9238 |

No diagnostic split survives Bonferroni correction at 0.05. The audit still shows selection-sensitive structure and should be treated as a warning against over-interpreting the full-sample dipole.
