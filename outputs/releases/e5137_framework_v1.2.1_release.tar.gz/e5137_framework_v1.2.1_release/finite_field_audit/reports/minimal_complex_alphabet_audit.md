# Minimal Complex Alphabet Audit

Alphabet: `{0, 1, i, pi, e}`.

Expression cost is the number of atoms used. Binary operations are
`+`, `-`, `*`, `/`, and tightly bounded exponentiation. Since targets are
real, candidates with non-negligible imaginary parts are excluded from
the nearest-hit table. The imaginary unit remains available through
real reductions such as `i^2 = -1`.

## Setup

- max atom cost: `5`
- random targets per range: `2000`
- magnitude bound: `1e+06`
- real-candidate imaginary tolerance: `1e-10`
- total generated candidates: `142589`
- real generated candidates: `67689`

## Best Real Hits

| target                        |         value | best_expression      |    best_value |   observed_ppm |   cost |
|:------------------------------|--------------:|:---------------------|--------------:|---------------:|-------:|
| alpha_inv                     |  137.036      | ((pi^e)+(pi^(1+pi))) |  137.008      |       201.324  |      5 |
| delta_alpha_inv_minus_137     |    0.0359991  | (((pi/(e*e))^e)/e)   |    0.0359774  |       603.242  |      5 |
| muon_to_electron_mass_ratio   |  206.768      | ((pi^(e*(e-1)))-pi)  |  206.789      |        98.0966 |      5 |
| tau_to_electron_mass_ratio    | 3477.23       | (((e*(e*e))^e)-pi)   | 3477.06       |        48.4082 |      5 |
| proton_to_electron_mass_ratio | 1836.15       | ((((pi-1)^pi)^pi)-1) | 1836.56       |       223.043  |      5 |
| q_operator                    |    0.00886061 | ((pi/(e+(e^e)))^e)   |    0.00886335 |       309.235  |      5 |
| T5_operator                   |    0.147152   | (((e-1)/(1+e))/pi)   |    0.147096   |       375.916  |      5 |

## Random-Target Null

| target                        |   observed_ppm |   random_targets |   empirical_p_random_as_good |   random_ppm_median |   random_ppm_p05 |   random_ppm_p01 |   random_ppm_min |
|:------------------------------|---------------:|-----------------:|-----------------------------:|--------------------:|-----------------:|-----------------:|-----------------:|
| alpha_inv                     |       201.324  |             2000 |                    0.453273  |             227.525 |          14.9651 |          2.34324 |       0.00949126 |
| delta_alpha_inv_minus_137     |       603.242  |             2000 |                    0.729635  |             320.586 |          21.5168 |          6.04943 |       0.356522   |
| muon_to_electron_mass_ratio   |        98.0966 |             2000 |                    0.325337  |             171.573 |          11.9641 |          1.85447 |       0.0174988  |
| tau_to_electron_mass_ratio    |        48.4082 |             2000 |                    0.0869565 |             575.959 |          25.7518 |          4.94334 |       0.00773093 |
| proton_to_electron_mass_ratio |       223.043  |             2000 |                    0.357321  |             359.894 |          27.7591 |          3.71768 |       0.106518   |
| q_operator                    |       309.235  |             2000 |                    0.332334  |             528.668 |          37.4529 |          7.75796 |       0.00313124 |
| T5_operator                   |       375.916  |             2000 |                    0.775112  |             170.784 |          13.5084 |          2.27066 |       0.0803485  |

## Reading Rule

- Low ppm error is only interesting if random targets are not hit as well.
- High `empirical_p_random_as_good` means the grammar is dense in that
  target range.
- This audit intentionally restricts the alphabet to avoid importing
  problem-specific constants such as 137, 26, or 5.
