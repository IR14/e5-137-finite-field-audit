# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |    ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|----------:|----------:|---------------:|
| LRG      | NGC      |     0.4 |     0.6 |   346761 |    6662611 |  0.0548598  |      0.0259971  |   2.45243 | -28.9195  |       0.207159 |
| LRG      | NGC      |     0.6 |     0.8 |   533955 |   10177952 |  0.0248201  |      0.0165155  | 345.016   | -23.9449  |       0.692861 |
| LRG      | NGC      |     0.8 |     1.1 |   595419 |   11312817 |  0.0195428  |      0.0105108  | 237.53    | -31.4801  |       0.746051 |
| LRG      | SGC      |     0.4 |     0.6 |   160150 |    3535898 |  0.0604041  |      0.0257143  |  51.5389  |  16.8271  |       0.486103 |
| LRG      | SGC      |     0.6 |     0.8 |   237939 |    5355083 |  0.0423511  |      0.0240697  | 117.025   |  72.8346  |       0.722256 |
| LRG      | SGC      |     0.8 |     1.1 |   264403 |    5986866 |  0.0547439  |      0.0303504  | 186.462   |   2.23186 |       0.446111 |
| ELG      | NGC      |     0.8 |     1.1 |   766482 |   12306203 |  0.037979   |      0.00847001 | 189.991   | -12.465   |       0.336733 |
| ELG      | NGC      |     1.1 |     1.4 |   715801 |   11438144 |  0.0240728  |      0.00686642 | 196.627   | -32.873   |       0.661668 |
| ELG      | NGC      |     1.4 |     1.6 |   339039 |    5404849 |  0.0199939  |      0.0122083  | 179.844   | -15.4826  |       0.856029 |
| ELG      | SGC      |     0.8 |     1.1 |   249883 |    6305110 |  0.0895234  |      0.0167564  | 205.204   | -50.8367  |       0.059988 |
| ELG      | SGC      |     1.1 |     1.4 |   242543 |    6047145 |  0.0712978  |      0.0179055  | 195.697   | -33.7683  |       0.202759 |
| ELG      | SGC      |     1.4 |     1.6 |   118324 |    2917069 |  0.0731271  |      0.0293608  |  33.1967  | -37.3276  |       0.357329 |
| QSO      | NGC      |     0.8 |     1.2 |   133606 |    5856626 |  0.0165115  |      0.0114304  | 328.358   |  75.5654  |       0.858228 |
| QSO      | NGC      |     1.2 |     1.6 |   191793 |    8427479 |  0.00621743 |      0.0102757  | 113.331   |  71.1937  |       0.985803 |
| QSO      | NGC      |     1.6 |     2.1 |   230514 |   10120517 |  0.011586   |      0.00934088 |  11.9418  |  36.7736  |       0.909218 |
| QSO      | NGC      |     2.1 |     3.5 |   237306 |   10420346 |  0.00843157 |      0.00791327 | 356.612   |  21.7478  |       0.94961  |
| QSO      | SGC      |     0.8 |     1.2 |    72742 |    3305720 |  0.0194748  |      0.0219684  |  12.6053  |  17.3628  |       0.929814 |
| QSO      | SGC      |     1.2 |     1.6 |   104480 |    4735179 |  0.047816   |      0.0259615  |  16.1903  | -15.8744  |       0.528694 |
| QSO      | SGC      |     1.6 |     2.1 |   123696 |    5625568 |  0.0240736  |      0.0195561  | 188.864   | -27.6195  |       0.862428 |
| QSO      | SGC      |     2.1 |     3.5 |   129254 |    5871303 |  0.0160859  |      0.0141307  | 263.811   |  -7.08596 |       0.921816 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| LRG 0.400-0.600 | LRG 0.600-0.800 |          16.367  |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         100.067  |
| LRG 0.400-0.600 | LRG 0.400-0.600 |          65.8757 |
| LRG 0.400-0.600 | LRG 0.600-0.800 |         124.713  |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         153.041  |
| LRG 0.400-0.600 | ELG 0.800-1.100 |         137.979  |
| LRG 0.400-0.600 | ELG 1.100-1.400 |         116.762  |
| LRG 0.400-0.600 | ELG 1.400-1.600 |         135.526  |
| LRG 0.400-0.600 | ELG 0.800-1.100 |          97.7485 |
| LRG 0.400-0.600 | ELG 1.100-1.400 |         116.071  |
| LRG 0.400-0.600 | ELG 1.400-1.600 |          26.9464 |
| LRG 0.400-0.600 | QSO 0.800-1.200 |         106.716  |
| LRG 0.400-0.600 | QSO 1.200-1.600 |         123.94   |
| LRG 0.400-0.600 | QSO 1.600-2.100 |          66.2949 |
| LRG 0.400-0.600 | QSO 2.100-3.500 |          50.9792 |
| LRG 0.400-0.600 | QSO 0.800-1.200 |          47.3106 |
| LRG 0.400-0.600 | QSO 1.200-1.600 |          18.1752 |
| LRG 0.400-0.600 | QSO 1.600-2.100 |         123.128  |
| LRG 0.400-0.600 | QSO 2.100-3.500 |          94.063  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |          91.2757 |
| LRG 0.600-0.800 | LRG 0.400-0.600 |          76.6427 |
| LRG 0.600-0.800 | LRG 0.600-0.800 |         124.631  |
| LRG 0.600-0.800 | LRG 0.800-1.100 |         149.977  |
| LRG 0.600-0.800 | ELG 0.800-1.100 |         136.166  |
| LRG 0.600-0.800 | ELG 1.100-1.400 |         115.684  |
| LRG 0.600-0.800 | ELG 1.400-1.600 |         137.996  |
| LRG 0.600-0.800 | ELG 0.800-1.100 |          97.2527 |
| LRG 0.600-0.800 | ELG 1.100-1.400 |         115.329  |
| LRG 0.600-0.800 | ELG 1.400-1.600 |          43.056  |
| LRG 0.600-0.800 | QSO 0.800-1.200 |         100.066  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
