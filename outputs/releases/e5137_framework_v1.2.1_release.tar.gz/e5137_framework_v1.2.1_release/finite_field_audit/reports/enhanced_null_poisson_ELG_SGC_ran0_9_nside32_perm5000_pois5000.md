# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| ELG      | SGC      |     0.8 |     1.1 |   249883 |   21022582 |   0.0898115 |       0.0167111 | 204.939  |  -51.9442 |      0.0607878 |
| ELG      | SGC      |     1.1 |     1.4 |   242543 |   20148668 |   0.0733176 |       0.0167632 | 194.738  |  -37.1618 |      0.156569  |
| ELG      | SGC      |     1.4 |     1.6 |   118324 |    9723681 |   0.0659999 |       0.027771  |  37.8017 |  -40.4783 |      0.419316  |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| ELG 0.800-1.100 | ELG 1.100-1.400 |          16.4361 |
| ELG 0.800-1.100 | ELG 1.400-1.600 |          86.9026 |
| ELG 1.100-1.400 | ELG 1.400-1.600 |          99.5321 |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
