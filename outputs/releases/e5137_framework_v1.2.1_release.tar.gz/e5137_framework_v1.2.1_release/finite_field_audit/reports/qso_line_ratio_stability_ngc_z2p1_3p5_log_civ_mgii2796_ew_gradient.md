# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 121109
- finite residual rows: 121109
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0302506
- axis RA: 294.353 deg
- axis DEC: -75.820 deg
- fitted pixels: 619
- block-null p-value: 0.9161676646706587
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    237300 |           4268 |                            111923 |                          0 |    121109 |      116191 | LOG_CIV_MGII2796_EW |       -2.24307 |        11.6571 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.0331      |
| z                     |   0.209007    |
| z2                    |  -0.322277    |
| LOGMSTAR              |  -0.0268504   |
| RCHI2_LINE            |  -0.0174225   |
| DELTA_LINECHI2        |  -0.00651027  |
| FLUX_SYNTH_G          |   0.180868    |
| FLUX_SYNTH_R          |  -0.294289    |
| FLUX_SYNTH_Z          |   0.12439     |
| FLUX_G                |   0.170781    |
| FLUX_R                |  -0.152785    |
| FLUX_Z                |  -0.0198814   |
| FLUX_W1               |   0.0408276   |
| FLUX_W2               |  -0.0193829   |
| template_0_ebv        |   0.0254423   |
| template_1_stardens   |  -0.0168122   |
| template_2_galdepth_g |  -0.0180746   |
| template_3_galdepth_r |  -0.000917243 |
| template_4_galdepth_z |   0.00850132  |
| template_5_psfsize_g  |  -0.00835894  |
| template_6_psfsize_r  |   0.00998704  |
| template_7_psfsize_z  |  -0.00876811  |
| template_8_cosky_g    |  -0.0146087   |
| template_9_cosky_r    |  -0.0056721   |
| template_10_cosky_z   |  -0.0106603   |

## Figures

- `outputs/figures/qso_line_ratio_stability_ngc_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_ngc_z2p1_3p5_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
