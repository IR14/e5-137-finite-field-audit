# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 2
- redshift range: `1.5` to `3.5`

## Sample

- joined rows on TARGETID: 761395
- finite residual rows: 761395
- observable: `CIV_1549_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.303061
- axis RA: 85.281 deg
- axis DEC: 7.464 deg
- fitted pixels: 1003
- block-null p-value: 0.9580838323353293
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_civ_1549_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|--------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    799010 |          20984 |                     16631 |                          0 |    761395 |       37615 | CIV_1549_EW         |         0.9959 |        235.173 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    33.0567    |
| z                     |   -17.1373    |
| z2                    |    15.0396    |
| LOGMSTAR              |    -5.8114    |
| RCHI2_LINE            |    -0.103185  |
| DELTA_LINECHI2        |    -0.370661  |
| FLUX_SYNTH_G          |     1.6594    |
| FLUX_SYNTH_R          |    -4.72768   |
| FLUX_SYNTH_Z          |     1.7931    |
| FLUX_G                |     2.85877   |
| FLUX_R                |    -1.57037   |
| FLUX_Z                |    -0.0731727 |
| FLUX_W1               |     2.48061   |
| FLUX_W2               |    -2.38482   |
| template_0_ebv        |     0.0236993 |
| template_1_stardens   |    -0.123432  |
| template_2_galdepth_g |     0.0294496 |
| template_3_galdepth_r |    -0.496721  |
| template_4_galdepth_z |     0.335202  |
| template_5_psfsize_g  |    -0.14599   |
| template_6_psfsize_r  |     0.380801  |
| template_7_psfsize_z  |    -0.189679  |
| template_8_cosky_g    |    -1.55681   |
| template_9_cosky_r    |     0.666211  |
| template_10_cosky_z   |     0.484132  |

## Figures

- `outputs/figures/qso_highz_line_civ_1549_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_civ_1549_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
