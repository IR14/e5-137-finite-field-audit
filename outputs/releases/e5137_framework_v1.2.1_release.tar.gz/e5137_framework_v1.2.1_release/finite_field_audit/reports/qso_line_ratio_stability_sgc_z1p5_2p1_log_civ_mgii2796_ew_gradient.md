# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 141977
- finite residual rows: 141977
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00848245
- axis RA: 27.994 deg
- axis DEC: -15.823 deg
- fitted pixels: 355
- block-null p-value: 0.9940119760479041
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    151020 |           4995 |                              4048 |                          0 |    141977 |        9043 | LOG_CIV_MGII2796_EW |       -2.49589 |        8.97831 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.0597      |
| z                     |  -0.806672    |
| z2                    |   0.739101    |
| LOGMSTAR              |  -0.064966    |
| RCHI2_LINE            |  -0.014918    |
| DELTA_LINECHI2        |  -0.00263495  |
| FLUX_SYNTH_G          |   0.0234844   |
| FLUX_SYNTH_R          |  -0.225278    |
| FLUX_SYNTH_Z          |   0.208613    |
| FLUX_G                |   0.0593245   |
| FLUX_R                |  -0.00898427  |
| FLUX_Z                |  -0.000301446 |
| FLUX_W1               |  -0.0042415   |
| FLUX_W2               |  -0.0299699   |
| template_0_ebv        |   0.0114408   |
| template_1_stardens   |   0.00697887  |
| template_2_galdepth_g |  -0.0179421   |
| template_3_galdepth_r |   0.020657    |
| template_4_galdepth_z |  -0.000139568 |
| template_5_psfsize_g  |  -0.00746388  |
| template_6_psfsize_r  |   0.00701761  |
| template_7_psfsize_z  |  -0.00423141  |
| template_8_cosky_g    |  -2.36263e-05 |
| template_9_cosky_r    |   0.00700079  |
| template_10_cosky_z   |  -0.000379846 |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
