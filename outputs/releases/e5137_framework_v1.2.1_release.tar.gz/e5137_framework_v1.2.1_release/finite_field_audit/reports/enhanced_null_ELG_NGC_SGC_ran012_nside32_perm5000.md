# Enhanced null test for ELG NGC/SGC

Configuration: DESI DR1 LSS ELG_LOPnotqso clustering catalogs, random catalogs 0/1/2 stacked, nside=32, 5000 permutation null tests, 300 bootstrap samples, 12 RA jackknife regions.

## Results

| tracer   | region   |   z_min |   z_max |   nside |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |   null_permutations |   jackknife_amplitude_min |   jackknife_amplitude_max |   jackknife_axis_median_shift_deg |   jackknife_axis_max_shift_deg |
|:---------|:---------|--------:|--------:|--------:|------------:|----------------:|---------:|----------:|---------------:|--------------------:|--------------------------:|--------------------------:|----------------------------------:|-------------------------------:|
| ELG      | NGC      |     0.8 |     1.1 |      32 |   0.037979  |      0.00892573 | 189.991  |  -12.465  |      0.344931  |                5000 |                 0.0319075 |                 0.0505326 |                           5.16637 |                        17.2636 |
| ELG      | NGC      |     1.1 |     1.4 |      32 |   0.0240728 |      0.00723409 | 196.627  |  -32.873  |      0.659868  |                5000 |                 0.0199591 |                 0.0346159 |                           8.76926 |                        26.0671 |
| ELG      | NGC      |     1.4 |     1.6 |      32 |   0.0199939 |      0.0111099  | 179.844  |  -15.4826 |      0.859028  |                5000 |                 0.0134263 |                 0.0350607 |                          17.4344  |                        77.9958 |
| ELG      | SGC      |     0.8 |     1.1 |      32 |   0.0895234 |      0.0162223  | 205.204  |  -50.8367 |      0.0557888 |                5000 |                 0.0702051 |                 0.133266  |                           4.48901 |                        64.5112 |
| ELG      | SGC      |     1.1 |     1.4 |      32 |   0.0712978 |      0.0194845  | 195.697  |  -33.7683 |      0.208358  |                5000 |                 0.0677278 |                 0.0833416 |                           3.15856 |                        12.9547 |
| ELG      | SGC      |     1.4 |     1.6 |      32 |   0.0731271 |      0.0288546  |  33.1967 |  -37.3276 |      0.34773   |                5000 |                 0.0611163 |                 0.0835806 |                           6.33308 |                        53.1112 |

## Interpretation

- The most notable bin remains SGC ELG 0.8-1.1, but the stronger permutation estimate gives p≈0.056, not a robust detection.
- NGC ELG control bins have high p-values, so the feature is region-dependent.
- Jackknife max axis shifts are large for some bins, especially SGC 0.8-1.1, which means the fitted axis is sensitive to leaving out parts of the footprint.
- This points toward survey-window/systematics follow-up rather than a cosmological claim.
