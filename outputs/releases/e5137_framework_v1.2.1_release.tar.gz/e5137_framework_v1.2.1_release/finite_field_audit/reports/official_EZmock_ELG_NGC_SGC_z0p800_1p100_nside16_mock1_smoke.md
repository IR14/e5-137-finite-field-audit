# Official DESI mock ensemble dipole calibration

This report runs the same DESI sky-map dipole estimator over downloaded
official mock clustering catalogs.

## Summary

| family   | tracer   | regions   |   z_min |   z_max |   nside | stage                              |   requested_realizations |   n_requested |   n_processed |   n_skipped |   n_templates |   mock_amplitude_median |   mock_amplitude_p68 |   mock_amplitude_p95 |   mock_amplitude_p99 |   observed_amplitude |   observed_ra_deg |   observed_dec_deg |   observed_empirical_p_value |
|:---------|:---------|:----------|--------:|--------:|--------:|:-----------------------------------|-------------------------:|--------------:|--------------:|------------:|--------------:|------------------------:|---------------------:|---------------------:|---------------------:|---------------------:|------------------:|-------------------:|-----------------------------:|
| EZmock   | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 | raw_no_template_regression         |                        1 |             1 |             1 |           0 |            11 |              0.00416212 |           0.00416212 |           0.00416212 |           0.00416212 |            0.0326834 |           204.166 |           -72.2818 |                          0.5 |
| EZmock   | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 | after_external_template_regression |                        1 |             1 |             1 |           0 |            11 |              0.00222177 |           0.00222177 |           0.00222177 |           0.00222177 |            0.0229974 |           222.055 |           -71.6975 |                          0.5 |

## Per-realization fits

| family   |   realization | tracer   | regions   |   n_data |   n_random |   raw_amplitude |   raw_ra_deg |   raw_dec_deg |   corrected_amplitude |   corrected_ra_deg |   corrected_dec_deg |
|:---------|--------------:|:---------|:----------|---------:|-----------:|----------------:|-------------:|--------------:|----------------------:|-------------------:|--------------------:|
| EZmock   |             1 | ELG      | NGC+SGC   |   953025 |    7700605 |      0.00416212 |      185.033 |       47.1152 |            0.00222177 |            320.112 |             59.5982 |

## Interpretation

- This is the preferred direction for cosmology-grade calibration because
the covariance comes from DESI-distributed mock catalogs.
- A 20-realization subset is useful as a smoke ensemble. Stable p-values
need a larger EZmock batch.
