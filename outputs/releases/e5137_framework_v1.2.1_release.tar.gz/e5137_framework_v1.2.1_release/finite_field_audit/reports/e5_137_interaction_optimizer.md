# e-5-137 horizon time-dilation gate

Status: local FRW integration around the best rows from the previous
canonical+phantom two-field scan. The kinetic-braiding branch is not used.
This pass tests the author's horizon time-dilation hypothesis as a
geometric low-redshift evolution gate.

## Lagrangian and gate layer

```text
L_dark = -1/2 (partial phi)^2 + 1/2 (partial chi)^2 - Lambda^4 U(x,y)
x = phi/M_Pl, y = chi/M_Pl

U = 1 + m_phi^2 x^2/2 + m_chi^2 y^2/2
    + g0^2 x^2 y^2/2

dt_observer = dt_local * H_gate(z,x)
H_gate(z,x) = 1 / sqrt(1 - (q / 117) exp(z) cos^2(5x))
```

The gate is applied only in the CPL comparison window `0 <= z <= 2`.
The literal formula is exponentially singular at high redshift, so the
early-universe integration keeps `H_gate = 1` outside that observer
window and still audits early dark energy separately.

## Target

| quantity | value |
|:--|--:|
| q | 0.00886061187429 |
| delta_phi | 0.0590055838384 |
| w0 | -0.751994852742 |
| wa | -0.860064969598 |
| w(z=0.5) | -1.03868317594 |
| w(z=1) | -1.18202733754 |
| phantom crossing redshift | 0.405197561097 |

## Seed rows used

|   case_id |   w_rms_z0_2 |        w0 |    w_z0p5 |      w_z1 |   omega_dark_max_z_gt_10 | early_sanity   |
|----------:|-------------:|----------:|----------:|----------:|-------------------------:|:---------------|
|       221 |     0.195155 | -0.861207 | -0.983025 | -1.00075  |               0.136094   | False          |
|       276 |     0.19709  | -0.830111 | -0.966952 | -0.989929 |               0.0128194  | False          |
|         5 |     0.200681 | -0.878403 | -0.976912 | -0.994542 |               0.00178663 | True           |
|        23 |     0.200908 | -0.868297 | -0.970814 | -0.991198 |               0.00181868 | True           |
|       291 |     0.201704 | -0.728437 | -0.93295  | -0.977464 |               0.0532009  | False          |
|        29 |     0.203241 | -0.896529 | -0.98033  | -0.995369 |               0.00176329 | True           |
|        11 |     0.203488 | -0.906473 | -0.986247 | -0.998586 |               0.00173311 | True           |
|        41 |     0.204321 | -0.820474 | -0.942592 | -0.975697 |               0.00197559 | True           |
|        47 |     0.20434  | -0.849258 | -0.952795 | -0.980379 |               0.00191166 | True           |
|       370 |     0.204379 | -0.920346 | -0.994246 | -1.00262  |               0.00991537 | True           |
|        39 |     0.212346 | -0.884112 | -0.947982 | -0.974129 |               0.00191846 | True           |
|       368 |     0.214662 | -0.968715 | -1.00538  | -1.00442  |               0.357411   | False          |
|        35 |     0.218797 | -0.993727 | -1.0148   | -1.01063  |               0.00157878 | True           |
|        27 |     0.220165 | -0.981902 | -0.996626 | -0.999248 |               0.00165726 | True           |

## Best baseline rows without horizon gate

|   case_id | mode             |   objective |   w_rms_z0_2 |        w0 |    w_z0p5 |      w_z1 |      w_z2 |   omega_dark_max_z_gt_10 |   crossing_z_est |   horizon_gate_min |   horizon_gate_max |   horizon_denominator_min | geometric_gate_positive   |
|----------:|:-----------------|------------:|-------------:|----------:|----------:|----------:|----------:|-------------------------:|-----------------:|-------------------:|-------------------:|--------------------------:|:--------------------------|
|       126 | baseline_no_gate |    0.249117 |     0.182885 | -0.920346 | -0.994007 | -1.00259  | -1.00199  |               0.00991537 |        0.707002  |                  1 |                  1 |                         1 | True                      |
|       224 | baseline_no_gate |    0.269867 |     0.203281 | -1.00757  | -0.9993   | -0.998895 | -0.999479 |               0.00827132 |        0.371562  |                  1 |                  1 |                         1 | True                      |
|       168 | baseline_no_gate |    0.284199 |     0.195779 | -0.993727 | -1.01481  | -1.01073  | -1.0043   |               0.00156501 |        0.0553525 |                  1 |                  1 |                         1 | True                      |
|        84 | baseline_no_gate |    0.288548 |     0.182268 | -0.906473 | -0.985948 | -0.998496 | -1.00077  |               0.001718   |        1.25096   |                  1 |                  1 |                         1 | True                      |
|       196 | baseline_no_gate |    0.291604 |     0.199376 | -0.99902  | -1.0055   | -1.00385  | -1.00156  |               0.00160002 |        0.0242919 |                  1 |                  1 |                         1 | True                      |
|       210 | baseline_no_gate |    0.293707 |     0.200958 | -0.999867 | -0.999982 | -1.00001  | -1.00002  |               0.00162308 |        0.789961  |                  1 |                  1 |                         1 | True                      |
|        98 | baseline_no_gate |    0.302729 |     0.185609 | -0.820474 | -0.941971 | -0.975317 | -0.992902 |               0.00195838 |      nan         |                  1 |                  1 |                         1 | True                      |
|       112 | baseline_no_gate |    0.309056 |     0.18474  | -0.849258 | -0.952273 | -0.980065 | -0.994382 |               0.00189501 |      nan         |                  1 |                  1 |                         1 | True                      |
|       228 | baseline_no_gate |    0.320691 |     0.20022  | -0.833877 | -0.911114 | -0.955212 | -0.985345 |               0.00825371 |      nan         |                  1 |                  1 |                         1 | True                      |
|       140 | baseline_no_gate |    0.325025 |     0.191995 | -0.884112 | -0.947551 | -0.973783 | -0.991444 |               0.00190175 |      nan         |                  1 |                  1 |                         1 | True                      |

## Best horizon-gated rows

|   case_id | mode              |   objective |   w_rms_z0_2 |        w0 |    w_z0p5 |      w_z1 |      w_z2 |   omega_dark_max_z_gt_10 |   crossing_z_est |   horizon_gate_min |   horizon_gate_max |   horizon_denominator_min | geometric_gate_positive   |
|----------:|:------------------|------------:|-------------:|----------:|----------:|----------:|----------:|-------------------------:|-----------------:|-------------------:|-------------------:|--------------------------:|:--------------------------|
|       133 | horizon_time_gate |    0.249116 |     0.182883 | -0.920331 | -0.994005 | -1.00259  | -1.00199  |               0.00991537 |        0.707071  |                  1 |            1.00014 |                  0.999712 | True                      |
|       231 | horizon_time_gate |    0.269866 |     0.203281 | -1.00758  | -0.9993   | -0.998895 | -0.999479 |               0.00827132 |        0.371572  |                  1 |            1.00002 |                  0.999954 | True                      |
|       175 | horizon_time_gate |    0.284192 |     0.195777 | -0.993721 | -1.01481  | -1.01073  | -1.0043   |               0.00156502 |        0.0554044 |                  1 |            1.00018 |                  0.999649 | True                      |
|        91 | horizon_time_gate |    0.288549 |     0.182266 | -0.906457 | -0.985944 | -0.998495 | -1.00077  |               0.00171803 |        1.25104   |                  1 |            1.00018 |                  0.999638 | True                      |
|       203 | horizon_time_gate |    0.291599 |     0.199375 | -0.999018 | -1.0055   | -1.00385  | -1.00156  |               0.00160002 |        0.024342  |                  1 |            1.00017 |                  0.999662 | True                      |
|       217 | horizon_time_gate |    0.293712 |     0.200958 | -0.999867 | -0.999982 | -1.00001  | -1.00002  |               0.00162308 |        0.790016  |                  1 |            1.00016 |                  0.999685 | True                      |
|       105 | horizon_time_gate |    0.302724 |     0.18561  | -0.820451 | -0.941962 | -0.975312 | -0.992902 |               0.00195844 |      nan         |                  1 |            1.00019 |                  0.999626 | True                      |
|       119 | horizon_time_gate |    0.309051 |     0.18474  | -0.849239 | -0.952265 | -0.980062 | -0.994382 |               0.00189506 |      nan         |                  1 |            1.00019 |                  0.99963  | True                      |
|       147 | horizon_time_gate |    0.325023 |     0.191996 | -0.884104 | -0.947546 | -0.97378  | -0.991444 |               0.00190179 |      nan         |                  1 |            1.00018 |                  0.999641 | True                      |
|       150 | horizon_time_gate |    0.328712 |     0.19541  | -0.885203 | -0.939457 | -0.968338 | -0.989332 |               0.00999457 |      nan         |                  1 |            1.00009 |                  0.999821 | True                      |

## Horizon-gated rows passing early sanity and crossing

|   case_id | mode              |   objective |   w_rms_z0_2 |        w0 |    w_z0p5 |      w_z1 |      w_z2 |   omega_dark_max_z_gt_10 |   crossing_z_est |   horizon_gate_min |   horizon_gate_max |   horizon_denominator_min | geometric_gate_positive   |
|----------:|:------------------|------------:|-------------:|----------:|----------:|----------:|----------:|-------------------------:|-----------------:|-------------------:|-------------------:|--------------------------:|:--------------------------|
|       133 | horizon_time_gate |    0.249116 |     0.182883 | -0.920331 | -0.994005 | -1.00259  | -1.00199  |               0.00991537 |        0.707071  |                  1 |            1.00014 |                  0.999712 | True                      |
|       231 | horizon_time_gate |    0.269866 |     0.203281 | -1.00758  | -0.9993   | -0.998895 | -0.999479 |               0.00827132 |        0.371572  |                  1 |            1.00002 |                  0.999954 | True                      |
|       175 | horizon_time_gate |    0.284192 |     0.195777 | -0.993721 | -1.01481  | -1.01073  | -1.0043   |               0.00156502 |        0.0554044 |                  1 |            1.00018 |                  0.999649 | True                      |
|        91 | horizon_time_gate |    0.288549 |     0.182266 | -0.906457 | -0.985944 | -0.998495 | -1.00077  |               0.00171803 |        1.25104   |                  1 |            1.00018 |                  0.999638 | True                      |
|       203 | horizon_time_gate |    0.291599 |     0.199375 | -0.999018 | -1.0055   | -1.00385  | -1.00156  |               0.00160002 |        0.024342  |                  1 |            1.00017 |                  0.999662 | True                      |
|       217 | horizon_time_gate |    0.293712 |     0.200958 | -0.999867 | -0.999982 | -1.00001  | -1.00002  |               0.00162308 |        0.790016  |                  1 |            1.00016 |                  0.999685 | True                      |
|        40 | horizon_time_gate |    0.332029 |     0.181912 | -0.897788 | -0.981224 | -0.996472 | -1.00011  |               0.00961534 |        1.82606   |                  1 |            1.00004 |                  0.999925 | True                      |
|       189 | horizon_time_gate |    0.376169 |     0.19694  | -0.9819   | -0.996566 | -0.999226 | -1.00001  |               0.00164282 |        1.92711   |                  1 |            1.00017 |                  0.999659 | True                      |
|        35 | horizon_time_gate |    0.385328 |     0.180115 | -0.878383 | -0.976509 | -0.994388 | -0.999559 |               0.0017711  |        2.57539   |                  1 |            1.00018 |                  0.999634 | True                      |
|        77 | horizon_time_gate |    0.386475 |     0.182235 | -0.896513 | -0.979987 | -0.995238 | -0.999647 |               0.00174796 |        2.50657   |                  1 |            1.00018 |                  0.999636 | True                      |

## Deepest horizon-gated rows by w(z=1)

|   case_id | mode              |   objective |   w_rms_z0_2 |       w0 |   w_z0p5 |     w_z1 |     w_z2 |   omega_dark_max_z_gt_10 | phantom_crosses   | early_sanity   |   m_phi_sq |   m_chi_sq |     g0_sq |   horizon_gate_max |
|----------:|:------------------|------------:|-------------:|---------:|---------:|---------:|---------:|-------------------------:|:------------------|:---------------|-----------:|-----------:|----------:|-------------------:|
|       162 | horizon_time_gate |    2.12391  |     0.459641 | -1.62525 | -1.3126  | -1.13915 | -1.04138 |               0.458652   | False             | False          |  0.881701  |  0.0333215 | 12        |            1.00014 |
|        25 | horizon_time_gate |    0.64993  |     0.299236 | -1.27899 | -1.20363 | -1.10575 | -1.03463 |               0.0496481  | False             | False          |  0.900696  |  0.284107  | 12        |            1.00003 |
|       135 | horizon_time_gate |    0.507283 |     0.265645 | -1.21344 | -1.1479  | -1.07821 | -1.02592 |               0.0187592  | False             | False          |  0.260089  |  0.399249  |  5.03289  |            1.00009 |
|        96 | horizon_time_gate |    1.18486  |     0.251302 | -1.18328 | -1.10164 | -1.05137 | -1.0168  |               0.251912   | False             | False          |  0.0687485 |  0.0846062 |  1.4101   |            1.00028 |
|       205 | horizon_time_gate |    2.16289  |     0.238525 | -1.14764 | -1.07113 | -1.03515 | -1.01144 |               0.585152   | False             | False          |  0.0663042 |  0.292549  |  0.371477 |            1.00005 |
|        13 | horizon_time_gate |    0.554079 |     0.192896 | -1.00378 | -1.05175 | -1.0341  | -1.01268 |               0.0760791  | False             | False          |  0.0493174 |  0.0932217 |  3.78461  |            1.00005 |
|        93 | horizon_time_gate |    0.484791 |     0.211694 | -1.06709 | -1.05903 | -1.03382 | -1.01195 |               0.0414407  | False             | False          |  0.0480764 |  0.472525  |  2.16634  |            1.00003 |
|       108 | horizon_time_gate |    0.935657 |     0.206215 | -1.0466  | -1.04889 | -1.02857 | -1.01015 |               0.195264   | False             | False          |  0.507744  |  0.0494632 |  2.70672  |            1.00019 |
|        80 | horizon_time_gate |    0.387735 |     0.210899 | -1.05934 | -1.04276 | -1.02366 | -1.00822 |               0.00890168 | False             | True           |  0.164046  |  0.268237  |  1.14406  |            1.00024 |
|       178 | horizon_time_gate |    0.742976 |     0.209815 | -1.05401 | -1.03776 | -1.02088 | -1.00731 |               0.129219   | False             | False          |  0.269179  |  0.57138   |  1.21248  |            1.00027 |

## Gate result

The horizon gate is numerically well behaved in the low-redshift
window, but its invariant strength is tiny:
`q/117 = 7.57317e-05`.

Best baseline row has `w(z=1) = -1.00259`.
Best horizon-gated row has `w(z=1) = -1.00259`.
The best-row shift is `Delta w(z=1) = 2.29427e-07`.

Best horizon-gated crossing row:
`w_rms_z0_2 = 0.182883`,
`w0 = -0.920331`,
`w(z=1) = -1.00259`,
`target w(z=1) = -1.18203`,
`residual = 0.179442`.

The deepest `w(z=1)` row is closer to the target, but it fails the
physical gates:
`w(z=1) = -1.13915`,
`residual = 0.0428812`,
`Omega_dark(z>10)_max = 0.458652`,
`early_sanity = False`,
`phantom_crosses = False`.

## Stability audit

The geometric denominator remains positive for accepted gated rows, so
the horizon factor itself does not introduce a denominator singularity
inside the CPL window. However, this does not automatically prove a
fundamental no-ghost/no-gradient completion: the underlying two-field
toy still contains the explicit phantom-sign component used in the
previous scan. The result is therefore a background gate audit, not a
UV-stability proof.
