# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 121092
- finite residual rows: 121092
- observable: `LOG_CIV_CIII_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0284901
- axis RA: 164.122 deg
- axis DEC: 45.051 deg
- fitted pixels: 355
- block-null p-value: 0.7245508982035929
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_ciii_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    129254 |           2873 |                          5289 |                          0 |    121092 |        8162 | LOG_CIV_CIII_EW     |       -2.52092 |        5.18229 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.813862    |
| z                     |  -0.527381    |
| z2                    |   0.490397    |
| LOGMSTAR              |  -0.0597396   |
| RCHI2_LINE            |   0.00372265  |
| DELTA_LINECHI2        |  -0.00333961  |
| FLUX_SYNTH_G          |   0.0743872   |
| FLUX_SYNTH_R          |  -0.0708639   |
| FLUX_SYNTH_Z          |   0.00479887  |
| FLUX_G                |   0.0749798   |
| FLUX_R                |  -0.0703259   |
| FLUX_Z                |  -0.0168678   |
| FLUX_W1               |   0.0372861   |
| FLUX_W2               |  -0.0332346   |
| template_0_ebv        |   0.00733734  |
| template_1_stardens   |   0.00325991  |
| template_2_galdepth_g |  -0.00895974  |
| template_3_galdepth_r |  -0.000909744 |
| template_4_galdepth_z |   0.0165362   |
| template_5_psfsize_g  |  -0.00645663  |
| template_6_psfsize_r  |   0.00862562  |
| template_7_psfsize_z  |  -0.00337678  |
| template_8_cosky_g    |  -0.00136538  |
| template_9_cosky_r    |   0.00764164  |
| template_10_cosky_z   |  -0.000864532 |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_civ_ciii_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_civ_ciii_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
