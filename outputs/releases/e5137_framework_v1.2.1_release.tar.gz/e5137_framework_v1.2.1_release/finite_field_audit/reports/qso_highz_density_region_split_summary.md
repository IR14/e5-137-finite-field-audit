# QSO high-z density region split

This diagnostic reruns the high-z QSO density dipole separately for NGC and SGC.
It is a footprint/systematics sanity check for the combined NGC+SGC density scan.

## Configuration

- redshift bins: 1.5-2.1, 2.1-3.5
- nside: 16
- null permutations: 5000
- Poisson mocks: 5000
- block-null mocks: 5000
- block-null regions: 48

## Results

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   ra_deg |    dec_deg |   null_p_value |   poisson_p_value |   block_null_p_value |   jackknife_axis_max_shift_deg | map_path                                                                                                                                |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|---------:|-----------:|---------------:|------------------:|---------------------:|-------------------------------:|:----------------------------------------------------------------------------------------------------------------------------------------|
| QSO      | NGC      |     1.5 |     2.1 |   281438 |    4119954 |  0.0099108  |  120.968 |  80.9619   |       0.977005 |          0.528694 |             0.653069 |                        67.408  | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/QSO_NGC_z1p500_2p100_nside16_qso_highz_region_split_map.npz |
| QSO      | NGC      |     2.1 |     3.5 |   237306 |    3473903 |  0.00631893 |  339.286 |  44.4053   |       0.985203 |          0.840032 |             0.876625 |                        54.2082 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/QSO_NGC_z2p100_3p500_nside16_qso_highz_region_split_map.npz |
| QSO      | SGC      |     1.5 |     2.1 |   151020 |    2287058 |  0.0189679  |  187.966 | -54.3405   |       0.978804 |          0.514097 |             0.765847 |                        89.9169 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/QSO_SGC_z1p500_2p100_nside16_qso_highz_region_split_map.npz |
| QSO      | SGC      |     2.1 |     3.5 |   129254 |    1957439 |  0.0171247  |  263.096 |  -0.889751 |       0.970006 |          0.630874 |             0.787043 |                        45.3392 | /Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/processed/QSO_SGC_z2p100_3p500_nside16_qso_highz_region_split_map.npz |

## Interpretation

- A robust cosmological axis should not depend on a single survey cap.
- High p-values remain compatible with the isotropic null.
- Discordant NGC/SGC axes are expected when the fitted dipoles are noise/footprint dominated.