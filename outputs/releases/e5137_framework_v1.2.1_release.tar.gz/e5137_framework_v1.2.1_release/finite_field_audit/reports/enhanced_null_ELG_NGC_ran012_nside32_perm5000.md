# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| ELG      | NGC      |     0.8 |     1.1 |   766482 |   12306203 |   0.037979  |      0.00892573 |  189.991 |  -12.465  |       0.344931 |
| ELG      | NGC      |     1.1 |     1.4 |   715801 |   11438144 |   0.0240728 |      0.00723409 |  196.627 |  -32.873  |       0.659868 |
| ELG      | NGC      |     1.4 |     1.6 |   339039 |    5404849 |   0.0199939 |      0.0111099  |  179.844 |  -15.4826 |       0.859028 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| ELG 0.800-1.100 | ELG 1.100-1.400 |          21.2925 |
| ELG 0.800-1.100 | ELG 1.400-1.600 |          10.2962 |
| ELG 1.100-1.400 | ELG 1.400-1.600 |          23.101  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
