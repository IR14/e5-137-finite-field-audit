# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 345404
- finite residual rows: 345404
- observable: `LOG_CIV_CIII_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00446785
- axis RA: 171.736 deg
- axis DEC: 10.948 deg
- fitted pixels: 987
- block-null p-value: 0.9800399201596807
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_ciii_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    366554 |           7141 |                         14009 |                          0 |    345404 |       21150 | LOG_CIV_CIII_EW     |       -2.40723 |         4.9839 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    0.837878   |
| z                     |   -0.509483   |
| z2                    |    0.472378   |
| LOGMSTAR              |   -0.0672197  |
| RCHI2_LINE            |    0.00416874 |
| DELTA_LINECHI2        |   -0.00378811 |
| FLUX_SYNTH_G          |    0.0662534  |
| FLUX_SYNTH_R          |   -0.0442231  |
| FLUX_SYNTH_Z          |   -0.0221714  |
| FLUX_G                |    0.0759071  |
| FLUX_R                |   -0.0831831  |
| FLUX_Z                |    0.00828409 |
| FLUX_W1               |    0.0336293  |
| FLUX_W2               |   -0.0318694  |
| template_0_ebv        |    0.00375856 |
| template_1_stardens   |    0.00225749 |
| template_2_galdepth_g |   -0.00217212 |
| template_3_galdepth_r |   -0.00406063 |
| template_4_galdepth_z |    0.00219736 |
| template_5_psfsize_g  |   -0.00771783 |
| template_6_psfsize_r  |    0.00422195 |
| template_7_psfsize_z  |   -0.00654913 |
| template_8_cosky_g    |   -0.00065659 |
| template_9_cosky_r    |   -0.00495462 |
| template_10_cosky_z   |    0.00465908 |

## Figures

- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_civ_ciii_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z2p1_3p5_log_civ_ciii_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
