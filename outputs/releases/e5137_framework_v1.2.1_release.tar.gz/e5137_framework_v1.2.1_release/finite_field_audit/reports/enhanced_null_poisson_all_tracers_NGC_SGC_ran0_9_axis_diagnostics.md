# Axis diagnostics

These diagnostics compare fitted axes with reference directions and with each other.
They are consistency checks only; a small angular separation is not significant unless
the underlying dipole measurement is itself significant under the null model.

## Reference axes

| reference       | tracer   | region   |   z_min |   z_max |   axis_separation_deg |   null_p_value |   amplitude |
|:----------------|:---------|:---------|--------:|--------:|----------------------:|---------------:|------------:|
| cmb_dipole_apex | LRG      | SGC      |     0.8 |     1.1 |               20.0944 |       0.474305 |  0.052456   |
| cmb_dipole_apex | ELG      | NGC      |     1.4 |     1.6 |               20.8191 |       0.923615 |  0.0158525  |
| cmb_dipole_apex | ELG      | NGC      |     0.8 |     1.1 |               21.0731 |       0.367726 |  0.0367808  |
| cmb_dipole_apex | QSO      | NGC      |     1.6 |     2.1 |               24.766  |       0.932414 |  0.010364   |
| cmb_dipole_apex | QSO      | NGC      |     2.1 |     3.5 |               25.4848 |       0.946611 |  0.00836338 |
| cmb_dipole_apex | QSO      | SGC      |     1.6 |     2.1 |               25.5681 |       0.833433 |  0.0267847  |
| cmb_dipole_apex | QSO      | SGC      |     0.8 |     1.2 |               25.7166 |       0.846031 |  0.0269636  |
| cmb_dipole_apex | LRG      | NGC      |     0.6 |     0.8 |               32.0284 |       0.692262 |  0.0244573  |
| cmb_dipole_apex | QSO      | SGC      |     1.2 |     1.6 |               35.2832 |       0.512298 |  0.0475859  |
| cmb_dipole_apex | ELG      | NGC      |     1.1 |     1.4 |               36.0699 |       0.613677 |  0.0253917  |
| cmb_dipole_apex | LRG      | NGC      |     0.4 |     0.6 |               38.5862 |       0.203559 |  0.0552216  |
| cmb_dipole_apex | ELG      | SGC      |     1.1 |     1.4 |               38.8153 |       0.156569 |  0.0733176  |

## Region consistency

| tracer   |   z_min |   z_max | left_region   | right_region   |   axis_separation_deg |   left_p |   right_p |   left_amplitude |   right_amplitude |
|:---------|--------:|--------:|:--------------|:---------------|----------------------:|---------:|----------:|-----------------:|------------------:|
| QSO      |     1.6 |     2.1 | NGC           | SGC            |               4.4252  | 0.932414 | 0.833433  |       0.010364   |         0.0267847 |
| ELG      |     1.1 |     1.4 | NGC           | SGC            |               7.44236 | 0.613677 | 0.156569  |       0.0253917  |         0.0733176 |
| ELG      |     0.8 |     1.1 | NGC           | SGC            |              42.5951  | 0.367726 | 0.0607878 |       0.0367808  |         0.0898115 |
| LRG      |     0.6 |     0.8 | NGC           | SGC            |              57.8381  | 0.692262 | 0.75125   |       0.0244573  |         0.0382892 |
| QSO      |     0.8 |     1.2 | NGC           | SGC            |              66.382   | 0.814637 | 0.846031  |       0.0182969  |         0.0269636 |
| LRG      |     0.8 |     1.1 | NGC           | SGC            |              67.3408  | 0.787443 | 0.474305  |       0.0182226  |         0.052456  |
| LRG      |     0.4 |     0.6 | NGC           | SGC            |              68.1761  | 0.203559 | 0.540492  |       0.0552216  |         0.0577945 |
| ELG      |     1.4 |     1.6 | NGC           | SGC            |              77.16    | 0.923615 | 0.419316  |       0.0158525  |         0.0659999 |
| QSO      |     1.2 |     1.6 | NGC           | SGC            |              77.7125  | 0.981204 | 0.512298  |       0.00656099 |         0.0475859 |
| QSO      |     2.1 |     3.5 | NGC           | SGC            |              89.471   | 0.946611 | 0.913217  |       0.00836338 |         0.0164248 |

## Cross-tracer consistency

| region   | left_tracer   | right_tracer   |   left_z_min |   left_z_max |   right_z_min |   right_z_max |   z_overlap |   axis_separation_deg |    left_p |   right_p |
|:---------|:--------------|:---------------|-------------:|-------------:|--------------:|--------------:|------------:|----------------------:|----------:|----------:|
| SGC      | LRG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               15.6582 | 0.474305  |  0.846031 |
| SGC      | ELG           | QSO            |          1.1 |          1.4 |           0.8 |           1.2 |         0.1 |               24.9766 | 0.156569  |  0.846031 |
| SGC      | ELG           | QSO            |          1.4 |          1.6 |           1.2 |           1.6 |         0.2 |               32.4597 | 0.419316  |  0.512298 |
| NGC      | ELG           | QSO            |          1.1 |          1.4 |           1.2 |           1.6 |         0.2 |               37.2549 | 0.613677  |  0.981204 |
| SGC      | ELG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               40.7975 | 0.0607878 |  0.846031 |
| NGC      | ELG           | QSO            |          1.1 |          1.4 |           0.8 |           1.2 |         0.1 |               49.072  | 0.613677  |  0.814637 |
| NGC      | LRG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               49.4816 | 0.787443  |  0.814637 |
| NGC      | ELG           | QSO            |          1.4 |          1.6 |           1.2 |           1.6 |         0.2 |               50.9198 | 0.923615  |  0.981204 |
| SGC      | ELG           | QSO            |          1.1 |          1.4 |           1.2 |           1.6 |         0.2 |               50.9511 | 0.156569  |  0.512298 |
| SGC      | ELG           | LRG            |          0.8 |          1.1 |           0.8 |           1.1 |         0.3 |               55.8963 | 0.0607878 |  0.474305 |
| NGC      | ELG           | LRG            |          0.8 |          1.1 |           0.8 |           1.1 |         0.3 |               56.7154 | 0.367726  |  0.787443 |
| NGC      | ELG           | QSO            |          0.8 |          1.1 |           0.8 |           1.2 |         0.3 |               66.7775 | 0.367726  |  0.814637 |

