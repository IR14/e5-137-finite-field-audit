# Prime Geometry Search in Base-e

## Scope

This report is an exploratory audit of greedy base-e digit expansions for primes versus composites. It is not evidence for the Riemann hypothesis and it does not attempt to prove primality from digit geometry. The success criterion requested for this run is a Mann-Whitney two-sided p-value below 0.01 for simple, predefined features.

## Encoder

For an integer X, the script computes the greedy beta-expansion in beta = e. Because floor(e) = 2, each digit lies in the alphabet {0, 1, 2}. The fractional part is truncated at 50 digits with Decimal precision 120.

Reference check: 137 -> `21100.02101020012110_e` with the first 14 fractional digits shown.

## Dataset

- Integer range scanned: [1000, 5000]
- Prime class: 500 consecutive primes from 1009 to 4993
- Composite class: 500 random composites from 1014 to 4992
- Composite sampling seed: 20260528
- Composite window matched to selected prime span: True

## Feature Tests

| metric          |   prime_median |   composite_median |   delta_median |   rank_biserial |   p_value |   bonferroni_p_value |
|:----------------|---------------:|-------------------:|---------------:|----------------:|----------:|---------------------:|
| autocorr_lag_2  |     0.0147771  |        -0.00274711 |    0.0175243   |        0.072092 | 0.0484698 |             0.823987 |
| max_run_0       |     4          |         3          |    1           |        0.046736 | 0.183861  |             1        |
| autocorr_lag_8  |    -0.00480167 |        -0.0141071  |    0.00930548  |        0.047468 | 0.193873  |             1        |
| autocorr_lag_5  |    -0.0127164  |        -0.00245478 |   -0.0102616   |       -0.043548 | 0.233298  |             1        |
| autocorr_lag_3  |    -0.0380202  |        -0.0279314  |   -0.0100888   |       -0.041532 | 0.255654  |             1        |
| max_run_any     |     4          |         4          |    0           |        0.031448 | 0.37011   |             1        |
| autocorr_lag_7  |     0.00639973 |        -0.00316497 |    0.0095647   |        0.031072 | 0.395098  |             1        |
| autocorr_lag_10 |    -0.0118382  |         0.00326333 |   -0.0151016   |       -0.0274   | 0.453317  |             1        |
| autocorr_lag_9  |    -0.0186351  |        -0.00710691 |   -0.0115282   |       -0.015848 | 0.664514  |             1        |
| count_0         |    21          |        21          |    0           |        0.008996 | 0.804783  |             1        |
| autocorr_lag_6  |    -0.0173626  |        -0.0181594  |    0.000796762 |        0.008964 | 0.806257  |             1        |
| autocorr_lag_4  |    -0.0315436  |        -0.0289564  |   -0.00258722  |       -0.005896 | 0.871874  |             1        |
| count_2         |    10          |        10          |    0           |        0.002984 | 0.934292  |             1        |
| autocorr_lag_1  |    -0.178462   |        -0.183302   |    0.00484021  |        0.002096 | 0.954336  |             1        |
| count_1         |    20          |        19          |    1           |       -0.00178  | 0.961063  |             1        |
| entropy         |     1.50889    |         1.50889    |    0           |        0.000428 | 0.990737  |             1        |
| max_run_2       |     1          |         1          |    0           |        0        | 1         |             1        |

## N=5 Resonance Check

The requested N=5 autocorrelation feature has p = 0.233298 (Bonferroni p = 1), prime median = -0.0127164, composite median = -0.00245478.

## Success Criterion

No predefined feature reached the requested uncorrected p < 0.01 threshold.

After Bonferroni correction over the tested feature family, no feature remains significant at p < 0.01. This is the conservative reading.

## Output Files

- Feature matrix: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/prime_geometry_base_e_features.csv`
- Mann-Whitney summary: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/tables/prime_geometry_base_e_mannwhitney.csv`
- Report: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/outputs/reports/prime_geometry_base_e.md`

## Interpretation Guardrail

Any positive marker in this report should be treated as a candidate for a pre-registered out-of-sample test on disjoint integer ranges and different base choices. The current run is a bounded exploratory scan.
