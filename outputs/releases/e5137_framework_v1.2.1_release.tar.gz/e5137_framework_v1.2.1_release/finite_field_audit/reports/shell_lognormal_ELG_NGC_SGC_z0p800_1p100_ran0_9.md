# Tuned shell-lognormal null: ELG NGC+SGC z=0.8-1.1

This report combines redshift-shell lognormal mock calibrations for the focused ELG low-z case.

## Inputs

- Real DESI DR1 LSS data/random catalogs already present in `data/raw`.
- Regions: NGC+SGC.
- Random catalogs: 0-9.
- Redshift shells: 6 equal-width bins from z=0.8 to z=1.1.
- External templates: 11 dust/depth/seeing/sky-brightness templates at matching nside.

## Shell-lognormal summary

|   nside |   shells |   sigma_lognormal |   radial_corr | stage                              |   n_mocks |   n_data |   n_random |   null_amplitude_median |   null_amplitude_p95 |   observed_amplitude |   observed_empirical_p_value |
|--------:|---------:|------------------:|--------------:|:-----------------------------------|----------:|---------:|-----------:|------------------------:|---------------------:|---------------------:|-----------------------------:|
|      16 |        6 |          0.112889 |          0.05 | after_external_template_regression |      1000 |  1016365 |   62044406 |               0.0260917 |            0.0595109 |            0.0229974 |                     0.592408 |
|      16 |        6 |          0.112889 |          0.05 | raw_no_template_regression         |      1000 |  1016365 |   62044406 |               0.0603492 |            0.109751  |            0.0326834 |                     0.867133 |
|      32 |        6 |          0.173871 |          0.05 | after_external_template_regression |      1000 |  1016365 |   62044406 |               0.0440794 |            0.0927193 |            0.0293449 |                     0.771229 |
|      32 |        6 |          0.173871 |          0.05 | raw_no_template_regression         |      1000 |  1016365 |   62044406 |               0.0917756 |            0.168464  |            0.0328003 |                     0.95005  |

## Null comparison

|   nside | stage                              |   observed_amplitude |   poisson_p_value |   poisson_null_p95 |   angular_lognormal_p_value |   angular_lognormal_null_p95 |   angular_lognormal_sigma |   shell_lognormal_p_value |   shell_lognormal_null_p95 |   shell_lognormal_sigma |   shell_vs_poisson_p_ratio |
|--------:|:-----------------------------------|---------------------:|------------------:|-------------------:|----------------------------:|-----------------------------:|--------------------------:|--------------------------:|---------------------------:|------------------------:|---------------------------:|
|      16 | after_external_template_regression |            0.0229974 |       0.000999001 |         0.00476705 |                    0.325674 |                    0.0383748 |                 0.0427448 |                  0.592408 |                  0.0595109 |                0.112889 |                        593 |
|      16 | raw_no_template_regression         |            0.0326834 |       0.000999001 |         0.00815362 |                    0.732268 |                    0.0737363 |                 0.0427448 |                  0.867133 |                  0.109751  |                0.112889 |                        868 |
|      32 | after_external_template_regression |            0.0293449 |       0.000999001 |         0.00547093 |                    0.569431 |                    0.0657788 |                 0.0640703 |                  0.771229 |                  0.0927193 |                0.173871 |                        772 |
|      32 | raw_no_template_regression         |            0.0328003 |       0.000999001 |         0.00828715 |                    0.91009  |                    0.109685  |                 0.0640703 |                  0.95005  |                  0.168464  |                0.173871 |                        951 |

## Interpretation

- Poisson-only p-values near 0.001 were overconfident because they did not include clustered LSS covariance.
- Angular lognormal and redshift-shell lognormal mocks both make the observed ELG low-z amplitude ordinary under H0-like clustered variance.
- The tuned shell null is stricter than the angular-only null in preserving n(z), but it is still not an official DESI covariance product.
- The next official-data step is to download a batch of EZmock or AbacusSummit clustering catalogs from the generated manifests and run the same map/dipole/template pipeline over each realization.
