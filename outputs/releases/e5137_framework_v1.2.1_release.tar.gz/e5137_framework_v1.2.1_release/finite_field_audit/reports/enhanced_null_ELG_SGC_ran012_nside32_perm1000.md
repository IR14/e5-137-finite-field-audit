# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| ELG      | SGC      |     0.8 |     1.1 |   249883 |    6305110 |   0.0895234 |       0.0164635 | 205.204  |  -50.8367 |       0.047952 |
| ELG      | SGC      |     1.1 |     1.4 |   242543 |    6047145 |   0.0712978 |       0.0187416 | 195.697  |  -33.7683 |       0.194805 |
| ELG      | SGC      |     1.4 |     1.6 |   118324 |    2917069 |   0.0731271 |       0.0275827 |  33.1967 |  -37.3276 |       0.354645 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| ELG 0.800-1.100 | ELG 1.100-1.400 |          18.424  |
| ELG 0.800-1.100 | ELG 1.400-1.600 |          91.5561 |
| ELG 1.100-1.400 | ELG 1.400-1.600 |         107.061  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- At least one bin has a low permutation p-value; inspect systematics before any physical claim.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
