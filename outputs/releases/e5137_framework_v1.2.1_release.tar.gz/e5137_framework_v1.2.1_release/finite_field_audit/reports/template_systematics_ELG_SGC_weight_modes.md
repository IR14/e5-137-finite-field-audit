# ELG SGC template-regression weight-mode summary

| template_weight_mode   |   z_min |   z_max |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   corrected_amplitude |   corrected_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |   corrected_block_null_p_value |
|:-----------------------|--------:|--------:|-----------------------:|----------------:|-------------------:|----------------------:|-------------------------:|-----------------------------------:|----------------------------------:|-------------------------------:|
| desi                   |     0.8 |     1.1 |             0.00714767 |       0.0898115 |         0.0607878  |             0.0850716 |               0.0763847  |                           0.947223 |                           8.34483 |                     0.380324   |
| desi                   |     1.1 |     1.4 |             0.00342322 |       0.0733176 |         0.163567   |             0.0775923 |               0.130374   |                           1.0583   |                           2.63864 |                     0.0179964  |
| desi                   |     1.4 |     1.6 |             0.00698961 |       0.0659999 |         0.405719   |             0.0616205 |               0.461908   |                           0.933646 |                           9.14474 |                     0.172765   |
| no_fkp                 |     0.8 |     1.1 |             0.737905   |       0.259506  |         0.00019996 |             0.0928712 |               0.0215957  |                           0.357877 |                          42.6017  |                     0.285943   |
| no_fkp                 |     1.1 |     1.4 |             0.69619    |       0.25312   |         0.00019996 |             0.0853573 |               0.0835833  |                           0.337221 |                          26.9164  |                     0.0323935  |
| no_fkp                 |     1.4 |     1.6 |             0.583084   |       0.191981  |         0.00459908 |             0.0424471 |               0.623675   |                           0.221101 |                          88.829   |                     0.363327   |
| uniform                |     0.8 |     1.1 |             0.899261   |       0.577399  |         0.00019996 |             0.299533  |               0.00019996 |                           0.518763 |                          56.5614  |                     0.00159968 |
| uniform                |     1.1 |     1.4 |             0.900161   |       0.502607  |         0.00019996 |             0.241485  |               0.00019996 |                           0.480464 |                          68.25    |                     0.00579884 |
| uniform                |     1.4 |     1.6 |             0.86151    |       0.460358  |         0.00019996 |             0.255931  |               0.00019996 |                           0.55594  |                          78.631   |                     0.00279944 |

## Interpretation

- DESI-weighted maps are only mildly affected by NTILE/FRAC_TLOBS_TILES template regression.
- no_fkp maps are strongly reduced by these templates, indicating substantial coupling to survey metadata.
- uniform maps remain strongly anisotropic after template regression, confirming that raw unweighted ELG SGC counts are not scientifically usable for this hypothesis test.
