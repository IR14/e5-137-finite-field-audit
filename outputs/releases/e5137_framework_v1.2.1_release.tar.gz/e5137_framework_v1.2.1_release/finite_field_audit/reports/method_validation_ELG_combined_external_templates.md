# Method validation: ELG combined external-template controls

This report validates the current external-template regression on the most relevant map:
`ELG NGC+SGC z=0.8-1.1`.

## Template group audit

- Source: `outputs/tables/template_group_audit_ELG_NGC_SGC_z0p800_1p100.csv`

| template_set         |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_ra_deg |   raw_dec_deg |   corrected_amplitude |   corrected_ra_deg |   corrected_dec_deg |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------------------|--------------:|-----------------------:|----------------:|-------------:|--------------:|----------------------:|-------------------:|--------------------:|-----------------------------------:|----------------------------------:|
| all                  |            11 |            0.0150558   |       0.0326834 |      204.166 |      -72.2818 |             0.0229974 |            222.055 |            -71.6975 |                           0.703641 |                          5.54116  |
| no_dust              |            10 |            0.0147906   |       0.0326834 |      204.166 |      -72.2818 |             0.0234409 |            224.533 |            -71.8598 |                           0.717211 |                          6.25396  |
| no_stellar_density   |            10 |            0.0119562   |       0.0326834 |      204.166 |      -72.2818 |             0.024164  |            218.798 |            -72.921  |                           0.739337 |                          4.41051  |
| no_depth             |             8 |            0.0108209   |       0.0326834 |      204.166 |      -72.2818 |             0.0251812 |            216.054 |            -68.1968 |                           0.77046  |                          5.71174  |
| no_seeing            |             8 |            0.00737791  |       0.0326834 |      204.166 |      -72.2818 |             0.0272477 |            203.705 |            -72.0497 |                           0.833687 |                          0.271599 |
| no_sky_brightness    |             8 |            0.0096991   |       0.0326834 |      204.166 |      -72.2818 |             0.0243611 |            225.641 |            -71.4446 |                           0.745368 |                          6.70054  |
| dust_only            |             1 |            0.000224671 |       0.0326834 |      204.166 |      -72.2818 |             0.0331419 |            206.54  |            -73.2806 |                           1.01403  |                          1.22113  |
| stellar_density_only |             1 |            0.00221974  |       0.0326834 |      204.166 |      -72.2818 |             0.0319991 |            208.923 |            -72.0703 |                           0.979062 |                          1.47119  |
| depth_only           |             3 |            0.000252081 |       0.0326834 |      204.166 |      -72.2818 |             0.0333664 |            204.866 |            -73.8357 |                           1.0209   |                          1.56725  |
| seeing_only          |             3 |            0.00613065  |       0.0326834 |      204.166 |      -72.2818 |             0.0239241 |            213.481 |            -67.9529 |                           0.731995 |                          5.35187  |
| sky_brightness_only  |             3 |            0.000656621 |       0.0326834 |      204.166 |      -72.2818 |             0.0299095 |            200.837 |            -69.6129 |                           0.915129 |                          2.88053  |

Interpretation: seeing templates (`PSFSIZE_*`) are the strongest single group in this map; removing them leaves much more residual amplitude than the full template set. Dust and depth alone do not explain the residual by themselves.

## Injection recovery

- Source: `outputs/tables/injection_recovery_ELG_NGC_SGC_z0p800_1p100.csv`

| axis_name    |   min_recovery_fraction |   max_recovery_fraction |   median_axis_error_deg |
|:-------------|------------------------:|------------------------:|------------------------:|
| fiducial     |                0.460451 |                0.460451 |                 49.7435 |
| raw_combined |                0.310753 |                0.310753 |                 16.8739 |

| axis_name    |   axis_ra_deg |   axis_dec_deg | stage                              |   injected_amplitude |   baseline_amplitude |   absolute_fit_amplitude |   recovered_amplitude |   recovery_fraction |   recovered_ra_deg |   recovered_dec_deg |   axis_error_deg |
|:-------------|--------------:|---------------:|:-----------------------------------|---------------------:|---------------------:|-------------------------:|----------------------:|--------------------:|-------------------:|--------------------:|-----------------:|
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.01 |            0.0326834 |                0.0328959 |            0.01       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.01 |            0.0229974 |                0.0258966 |            0.00460451 |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.02 |            0.0326834 |                0.036001  |            0.02       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.02 |            0.0229974 |                0.0292369 |            0.00920903 |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.03 |            0.0326834 |                0.0413522 |            0.03       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.03 |            0.0229974 |                0.032884  |            0.0138135  |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| fiducial     |       215     |        25      | raw_no_template_regression         |                 0.05 |            0.0326834 |                0.0560168 |            0.05       |            1        |            215     |             25      |           0      |
| fiducial     |       215     |        25      | after_external_template_regression |                 0.05 |            0.0229974 |                0.0407638 |            0.0230226  |            0.460451 |            241.402 |            -17.5808 |          49.7435 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.01 |            0.0326834 |                0.0426834 |            0.01       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.01 |            0.0229974 |                0.0260438 |            0.00310753 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.02 |            0.0326834 |                0.0526834 |            0.02       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.02 |            0.0229974 |                0.0291031 |            0.00621506 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.03 |            0.0326834 |                0.0626834 |            0.03       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.03 |            0.0229974 |                0.0321716 |            0.00932259 |            0.310753 |            237.775 |            -61.2246 |          16.8739 |
| raw_combined |       204.166 |       -72.2818 | raw_no_template_regression         |                 0.05 |            0.0326834 |                0.0826834 |            0.05       |            1        |            204.166 |            -72.2818 |           0      |
| raw_combined |       204.166 |       -72.2818 | after_external_template_regression |                 0.05 |            0.0229974 |                0.0383276 |            0.0155376  |            0.310753 |            237.775 |            -61.2246 |          16.8739 |

Interpretation: raw maps recover the injected vector exactly in this linear test. After external-template regression, only about 46% of a fiducial `(RA=215, DEC=25)` dipole and about 31% of a raw-axis-aligned dipole is recovered. This means the template regression is useful as a systematics diagnostic, but too aggressive to use as a standalone upper-limit estimator for a real cosmological dipole.

## Nside robustness

- Source: `outputs/tables/combined_external_template_ELG_nside_robustness.csv`

|   nside | tracer   | region   |   z_min |   z_max |   raw_amplitude |   raw_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   template_weighted_r2 |   axis_shift_raw_to_corrected_deg |
|--------:|:---------|:---------|--------:|--------:|----------------:|-------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------:|----------------------------------:|
|       8 | ELG      | NGC+SGC  |     0.8 |     1.1 |       0.0327367 |          0.282572  |            0.0158349  |                0.712096  |                     0.124063   |             0.0647204  |                          14.1187  |
|      16 | ELG      | NGC+SGC  |     0.8 |     1.1 |       0.0326834 |          0.125375  |            0.0229974  |                0.329534  |                     0.0164918  |             0.0150558  |                           5.54116 |
|      32 | ELG      | NGC+SGC  |     0.8 |     1.1 |       0.0328003 |          0.0436521 |            0.0293449  |                0.0759747 |                     0.00666112 |             0.00553621 |                           5.70944 |
|       8 | ELG      | NGC+SGC  |     1.1 |     1.4 |       0.0262821 |          0.406198  |            0.0148221  |                0.753416  |                     0.0824313  |             0.0788181  |                          16.2063  |
|      16 | ELG      | NGC+SGC  |     1.1 |     1.4 |       0.0267839 |          0.256949  |            0.021825   |                0.411718  |                     0.0209895  |             0.023599   |                          14.6514  |
|      32 | ELG      | NGC+SGC  |     1.1 |     1.4 |       0.0271119 |          0.113629  |            0.0266403  |                0.103965  |                     0.00915903 |             0.00943637 |                          13.3599  |
|       8 | ELG      | NGC+SGC  |     1.4 |     1.6 |       0.0174337 |          0.848051  |            0.00507522 |                0.997667  |                     0.929226   |             0.0995406  |                          87.5362  |
|      16 | ELG      | NGC+SGC  |     1.4 |     1.6 |       0.0178394 |          0.788642  |            0.00825    |                0.969806  |                     0.754123   |             0.016974   |                          13.2413  |
|      32 | ELG      | NGC+SGC  |     1.4 |     1.6 |       0.0173678 |          0.571476  |            0.0128166  |                0.75908   |                     0.484596   |             0.00371422 |                          12.6005  |

Interpretation: `nside=8` and `nside=16` are safely null-compatible after external templates. `nside=32` keeps a lower local p-value in the lowest ELG bin (`p≈0.076`), but it is not significant and is not stable across nside. This points to pixelization/footprint sensitivity, not a robust axis.

## Bottom line

- The external-template result should be treated as a systematics stress test, not a final correction model.
- The current DESI DR1 first-pass maps still do not show a robust directional cosmological signal.
- The next genuinely scientific step is mock calibration: inject dipoles into DESI-like mocks or official mocks and measure detection efficiency and false-positive rates with the same pipeline.
