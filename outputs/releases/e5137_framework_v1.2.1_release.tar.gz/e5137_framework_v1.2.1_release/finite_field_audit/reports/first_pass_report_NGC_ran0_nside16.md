# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |   ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|---------:|----------:|---------------:|
| LRG      | NGC      |     0.4 |     0.6 |   346761 |    2220284 |  0.0505772  |      0.0296954  |   2.497  | -27.9512  |       0.347107 |
| LRG      | NGC      |     0.6 |     0.8 |   533955 |    3393875 |  0.01987    |      0.0162872  | 339.85   | -24.8531  |       0.884298 |
| LRG      | NGC      |     0.8 |     1.1 |   595419 |    3773066 |  0.0203859  |      0.0131118  | 238.912  | -29.0384  |       0.785124 |
| ELG      | NGC      |     0.8 |     1.1 |   766482 |    4099582 |  0.0377753  |      0.0100221  | 190.265  | -13.599   |       0.322314 |
| ELG      | NGC      |     1.1 |     1.4 |   715801 |    3816063 |  0.0252528  |      0.0082907  | 195.152  | -23.7881  |       0.793388 |
| ELG      | NGC      |     1.4 |     1.6 |   339039 |    1802706 |  0.0302859  |      0.0123618  | 183.322  |  -4.16215 |       0.942149 |
| QSO      | NGC      |     0.8 |     1.2 |   133606 |    1951209 |  0.0171139  |      0.012932   | 328.479  |  81.1323  |       0.942149 |
| QSO      | NGC      |     1.2 |     1.6 |   191793 |    2809949 |  0.00812082 |      0.0124613  | 142.64   |  70.8641  |       0.983471 |
| QSO      | NGC      |     1.6 |     2.1 |   230514 |    3373439 |  0.0123972  |      0.00829229 |  28.9062 |  67.4324  |       0.900826 |
| QSO      | NGC      |     2.1 |     3.5 |   237306 |    3473903 |  0.00631893 |      0.00835911 | 339.286  |  44.4053  |       0.983471 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| LRG 0.400-0.600 | LRG 0.600-0.800 |          20.4893 |
| LRG 0.400-0.600 | LRG 0.800-1.100 |         101.52   |
| LRG 0.400-0.600 | ELG 0.800-1.100 |         137.774  |
| LRG 0.400-0.600 | ELG 1.100-1.400 |         126.842  |
| LRG 0.400-0.600 | ELG 1.400-1.600 |         147.877  |
| LRG 0.400-0.600 | QSO 0.800-1.200 |         110.503  |
| LRG 0.400-0.600 | QSO 1.200-1.600 |         131.691  |
| LRG 0.400-0.600 | QSO 1.600-2.100 |          97.4235 |
| LRG 0.400-0.600 | QSO 2.100-3.500 |          75.4033 |
| LRG 0.600-0.800 | LRG 0.800-1.100 |          86.9349 |
| LRG 0.600-0.800 | ELG 0.800-1.100 |         131.434  |
| LRG 0.600-0.800 | ELG 1.100-1.400 |         120.537  |
| LRG 0.600-0.800 | ELG 1.400-1.600 |         143.092  |
| LRG 0.600-0.800 | QSO 0.800-1.200 |         106.149  |
| LRG 0.600-0.800 | QSO 1.200-1.600 |         132.938  |
| LRG 0.600-0.800 | QSO 1.600-2.100 |          99.2015 |
| LRG 0.600-0.800 | QSO 2.100-3.500 |          69.2604 |
| LRG 0.800-1.100 | ELG 0.800-1.100 |          47.5012 |
| LRG 0.800-1.100 | ELG 1.100-1.400 |          39.3224 |
| LRG 0.800-1.100 | ELG 1.400-1.600 |          58.129  |
| LRG 0.800-1.100 | QSO 0.800-1.200 |         118.592  |
| LRG 0.800-1.100 | QSO 1.200-1.600 |         119.333  |
| LRG 0.800-1.100 | QSO 1.600-2.100 |         137.628  |
| LRG 0.800-1.100 | QSO 2.100-3.500 |         116.88   |
| ELG 0.800-1.100 | ELG 1.100-1.400 |          11.1879 |
| ELG 0.800-1.100 | ELG 1.400-1.600 |          11.6612 |
| ELG 0.800-1.100 | QSO 0.800-1.200 |         110.123  |
| ELG 0.800-1.100 | QSO 1.200-1.600 |          90.4233 |
| ELG 0.800-1.100 | QSO 1.600-2.100 |         124.79   |
| ELG 0.800-1.100 | QSO 2.100-3.500 |         139.452  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
