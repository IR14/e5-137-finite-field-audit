# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 407103
- finite residual rows: 407103
- observable: `LOG_CIV_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00274714
- axis RA: 149.263 deg
- axis DEC: -31.179 deg
- fitted pixels: 988
- block-null p-value: 0.9940119760479041
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|----------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    432456 |          13843 |                             11510 |                          0 |    407103 |       25353 | LOG_CIV_MGII2796_EW |        -2.4818 |        8.85358 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    1.0711     |
| z                     |   -0.832554   |
| z2                    |    0.768009   |
| LOGMSTAR              |   -0.0638051  |
| RCHI2_LINE            |   -0.00259736 |
| DELTA_LINECHI2        |   -0.00370706 |
| FLUX_SYNTH_G          |    0.049057   |
| FLUX_SYNTH_R          |   -0.201778   |
| FLUX_SYNTH_Z          |    0.128188   |
| FLUX_G                |    0.0381364  |
| FLUX_R                |   -0.028802   |
| FLUX_Z                |    0.0595823  |
| FLUX_W1               |   -0.0140548  |
| FLUX_W2               |   -0.0153359  |
| template_0_ebv        |    0.00822909 |
| template_1_stardens   |    0.00461513 |
| template_2_galdepth_g |   -0.00490875 |
| template_3_galdepth_r |    0.00221922 |
| template_4_galdepth_z |    0.00110156 |
| template_5_psfsize_g  |    0.00101798 |
| template_6_psfsize_r  |   -0.0038012  |
| template_7_psfsize_z  |    0.00136149 |
| template_8_cosky_g    |   -0.0122139  |
| template_9_cosky_r    |    0.00216971 |
| template_10_cosky_z   |    0.0144848  |

## Figures

- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_civ_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
