# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 2
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 396908
- finite residual rows: 396908
- observable: `LOG_CIV_CIII_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.00592724
- axis RA: 90.086 deg
- axis DEC: 13.236 deg
- fitted pixels: 986
- block-null p-value: 0.9700598802395209
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_civ_ciii_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|------------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    432456 |          13843 |                         21705 |                          0 |    396908 |       35548 | LOG_CIV_CIII_EW     |       -2.35001 |        6.06148 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   1.04775     |
| z                     |  -0.173741    |
| z2                    |   0.105009    |
| LOGMSTAR              |  -0.0717148   |
| RCHI2_LINE            |   0.000169964 |
| DELTA_LINECHI2        |  -0.00303822  |
| FLUX_SYNTH_G          |   0.196268    |
| FLUX_SYNTH_R          |  -0.292784    |
| FLUX_SYNTH_Z          |   0.115169    |
| FLUX_G                |  -0.0392182   |
| FLUX_R                |   0.107698    |
| FLUX_Z                |  -0.0603182   |
| FLUX_W1               |   0.0398678   |
| FLUX_W2               |  -0.0599639   |
| template_0_ebv        |   0.00736386  |
| template_1_stardens   |  -0.00101694  |
| template_2_galdepth_g |  -0.0059108   |
| template_3_galdepth_r |   0.00381169  |
| template_4_galdepth_z |  -0.0066094   |
| template_5_psfsize_g  |   0.00429481  |
| template_6_psfsize_r  |  -0.00536552  |
| template_7_psfsize_z  |  -0.00176841  |
| template_8_cosky_g    |  -0.0142207   |
| template_9_cosky_r    |   0.00941842  |
| template_10_cosky_z   |  -0.000540837 |

## Figures

- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_civ_ciii_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_primary_z1p5_2p1_log_civ_ciii_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
