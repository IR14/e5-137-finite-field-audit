# QSO FastSpecFit observable inventory

This report inventories emission-line observables that are more appropriate
for QSO high-z work than `DN4000_MODEL`.

## Joined Sample

- joined QSO rows: `799010`
- NGC rows: `518736`
- SGC rows: `280274`

## Candidate Observables

| observable     | ivar_column         |   n_joined |   n_finite |   n_ivar_positive |   n_usable |   n_usable_z1p5_2p1 |   n_usable_z2p1_3p5 |   usable_fraction |     median |          p01 |       p99 |
|:---------------|:--------------------|-----------:|-----------:|------------------:|-----------:|--------------------:|--------------------:|------------------:|-----------:|-------------:|----------:|
| CIV_1549_EW    | CIV_1549_EW_IVAR    |     799010 |     799010 |            779955 |     779955 |              422007 |              357948 |          0.976152 |  43.0347   |  0.849884    |  236.139  |
| CIV_1549_FLUX  | CIV_1549_FLUX_IVAR  |     799010 |     799010 |            779955 |     779955 |              422007 |              357948 |          0.976152 | 140.133    |  1.58341     | 1739.07   |
| CIII_1908_EW   | CIII_1908_EW_IVAR   |     799010 |     799010 |            776361 |     776361 |              417597 |              358764 |          0.971654 |  14.0407   |  0.099615    |   78.2942 |
| CIII_1908_FLUX | CIII_1908_FLUX_IVAR |     799010 |     799010 |            776361 |     776361 |              417597 |              358764 |          0.971654 |  35.4707   |  0.132897    |  453.886  |
| MGII_2796_EW   | MGII_2796_EW_IVAR   |     799010 |     799010 |            622832 |     622832 |              429575 |              193257 |          0.779505 |  11.845    |  0.000859241 |   80.3394 |
| MGII_2796_FLUX | MGII_2796_FLUX_IVAR |     799010 |     799010 |            622832 |     622832 |              429575 |              193257 |          0.779505 |  21.1857   |  0.000760159 |  255.157  |
| MGII_2803_EW   | MGII_2803_EW_IVAR   |     799010 |     799010 |            622830 |     622830 |              429574 |              193256 |          0.779502 |  19.1415   |  0.757424    |  105.682  |
| MGII_2803_FLUX | MGII_2803_FLUX_IVAR |     799010 |     799010 |            622830 |     622830 |              429574 |              193256 |          0.779502 |  31.4757   |  0.574691    |  391.265  |
| LYALPHA_EW     | LYALPHA_EW_IVAR     |     799010 |     799010 |            444927 |     444927 |               81476 |              363451 |          0.556848 |  71.9188   |  6.63474     |  362.806  |
| LYALPHA_FLUX   | LYALPHA_FLUX_IVAR   |     799010 |     799010 |            444927 |     444927 |               81476 |              363451 |          0.556848 | 256.18     | 20.0756      | 3774.78   |
| OII_3726_EW    | OII_3726_EW_IVAR    |     799010 |     799010 |             85310 |      85310 |               85131 |                 179 |          0.10677  |   0.940696 |  8.14797e-09 |   29.6609 |
| OII_3726_FLUX  | OII_3726_FLUX_IVAR  |     799010 |     799010 |             85310 |      85310 |               85131 |                 179 |          0.10677  |   1.03638  |  1.31017e-07 |   17.0915 |
| OII_3729_EW    | OII_3729_EW_IVAR    |     799010 |     799010 |             85291 |      85291 |               85112 |                 179 |          0.106746 |   1.76815  |  0.00565148  |   32.4581 |
| OII_3729_FLUX  | OII_3729_FLUX_IVAR  |     799010 |     799010 |             85291 |      85291 |               85112 |                 179 |          0.106746 |   1.79257  |  0.0279896   |   21.7234 |

## Recommended Next Test

Use the highest-coverage QSO emission-line observables with positive IVAR
as population residuals, controlling for redshift and luminosity proxies.
The first candidates are the rows with the largest `n_usable` in this table.
