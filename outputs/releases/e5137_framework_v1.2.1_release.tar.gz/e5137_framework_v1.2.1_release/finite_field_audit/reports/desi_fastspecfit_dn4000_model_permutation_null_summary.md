# DESI FastSpecFit DN4000_MODEL permutation null summary

This uses a mask-preserving pixel permutation null: residual means are shuffled among valid sky pixels while the observed survey mask and pixel weights are held fixed. This is a first H0 diagnostic for angular association of population residuals; it is not a replacement for full survey-systematics modeling.

- observable: `DN4000_MODEL`
- permutations per bin: `500`
- summary CSV: `outputs/tables/desi_fastspecfit_dn4000_model_permutation_null_summary.csv`
- p-value plot: `outputs/figures/desi_fastspecfit_dn4000_model_permutation_pvalues.png`

| tracer   | region   |   z_min |   z_max |   n_joined |   amplitude |    ra_deg |   dec_deg |   p_value |   null_amp_median |   null_amp_p95 |
|:---------|:---------|--------:|--------:|-----------:|------------:|----------:|----------:|----------:|------------------:|---------------:|
| LRG      | NGC      |     0.4 |     0.6 |     346759 |  0.0155719  | 346.626   |  74.6462  | 0.11976   |        0.00813164 |     0.0182863  |
| LRG      | NGC      |     0.6 |     0.8 |     533954 |  0.00374655 |   2.27188 |  19.7909  | 0.778443  |        0.00570336 |     0.0128829  |
| LRG      | NGC      |     0.8 |     1.1 |     595418 |  0.00600394 | 168.704   |  48.8918  | 0.345309  |        0.00488268 |     0.0106084  |
| LRG      | SGC      |     0.4 |     0.6 |     160150 |  0.0241498  |  14.9389  |  86.3022  | 0.0259481 |        0.0100386  |     0.0220007  |
| LRG      | SGC      |     0.6 |     0.8 |     237939 |  0.0106073  |  43.61    |  78.9407  | 0.331337  |        0.00840255 |     0.0177238  |
| LRG      | SGC      |     0.8 |     1.1 |     264403 |  0.0149726  |  14.2216  | -31.4774  | 0.161677  |        0.00878816 |     0.0196344  |
| ELG      | NGC      |     0.8 |     1.1 |     766480 |  0.00199377 | 300.962   |  73.5989  | 0.339321  |        0.00157911 |     0.00360538 |
| ELG      | NGC      |     1.1 |     1.3 |     490230 |  0.00239694 | 220.342   |  68.5849  | 0.52495   |        0.00249419 |     0.00622452 |
| ELG      | NGC      |     1.3 |     1.6 |     564607 |  0.00173559 | 272.177   |  70.809   | 0.774451  |        0.0029553  |     0.00906433 |
| ELG      | SGC      |     0.8 |     1.1 |     249879 |  0.00309617 | 196.384   |  -6.34484 | 0.233533  |        0.00208876 |     0.0046064  |
| ELG      | SGC      |     1.1 |     1.3 |     164598 |  0.00450122 | 197.127   |  29.512   | 0.153693  |        0.00256349 |     0.00571021 |
| ELG      | SGC      |     1.3 |     1.6 |     196263 |  0.00509285 | 192.396   |  33.2879  | 0.215569  |        0.00333606 |     0.00829866 |
