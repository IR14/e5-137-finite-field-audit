# ELG SGC weight-mode robustness

This check reruns the ELG SGC first-pass dipole fit with three weighting modes: DESI default weights, DESI weights without FKP, and uniform weights.

A cosmological directional interpretation would need approximate stability under reasonable weighting choices. Strong changes in amplitude, p-value, or axis direction are treated as evidence for survey/selection sensitivity.

## Summary table

|   z_min |   z_max | weight_mode   |   amplitude |   ra_deg |   dec_deg |   null_p_value |   poisson_p_value |   axis_sep_from_desi_deg |   jackknife_axis_max_shift_deg |
|--------:|--------:|:--------------|------------:|---------:|----------:|---------------:|------------------:|-------------------------:|-------------------------------:|
|     0.8 |     1.1 | desi          |   0.0898115 | 204.939  |  -51.9442 |     0.0607878  |        0.00019996 |              0           |                        66.2156 |
|     0.8 |     1.1 | no_fkp        |   0.259506  | 169.98   |  -19.9105 |     0.00019996 |        0.00019996 |             41.9989      |                        56.8973 |
|     0.8 |     1.1 | uniform       |   0.577399  | 160.571  |  -30.5326 |     0.00019996 |        0.00019996 |             38.7775      |                        38.6102 |
|     1.1 |     1.4 | desi          |   0.0733176 | 194.738  |  -37.1618 |     0.156569   |        0.00039992 |              8.53774e-07 |                        13.2065 |
|     1.1 |     1.4 | no_fkp        |   0.25312   | 167.997  |  -14.864  |     0.00019996 |        0.00019996 |             32.5585      |                        33.7089 |
|     1.1 |     1.4 | uniform       |   0.502607  | 154.425  |  -26.7025 |     0.00019996 |        0.00019996 |             35.4801      |                        32.7124 |
|     1.4 |     1.6 | desi          |   0.0659999 |  37.8017 |  -40.4783 |     0.419316   |        0.0029994  |              0           |                        57.3935 |
|     1.4 |     1.6 | no_fkp        |   0.191981  | 148.191  |  -15.6157 |     0.00579884 |        0.00019996 |             94.6162      |                        58.1584 |
|     1.4 |     1.6 | uniform       |   0.460358  | 145.819  |  -28.3116 |     0.00019996 |        0.00019996 |             84.2176      |                        35.4706 |

## Interpretation

- The DESI-weighted result is the scientifically preferred first-pass configuration for these catalogs.
- Removing or simplifying weights greatly increases ELG SGC amplitudes and shifts axes by tens of degrees in the first two bins and more than eighty degrees in the highest ELG bin.
- This is a strong warning that the apparent ELG SGC anisotropy is coupled to selection/weighting choices, so it should not be interpreted as a robust cosmological axis at this stage.
