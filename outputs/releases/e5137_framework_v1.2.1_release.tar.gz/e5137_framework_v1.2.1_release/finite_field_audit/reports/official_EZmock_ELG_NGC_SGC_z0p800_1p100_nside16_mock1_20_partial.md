# Official DESI mock ensemble dipole calibration

This report runs the same DESI sky-map dipole estimator over downloaded
official mock clustering catalogs.

## Summary

| family   | tracer   | regions   |   z_min |   z_max |   nside | stage                              | requested_realizations                             |   n_requested |   n_processed |   n_skipped |   n_templates |   mock_amplitude_median |   mock_amplitude_p68 |   mock_amplitude_p95 |   mock_amplitude_p99 |   observed_amplitude |   observed_ra_deg |   observed_dec_deg |   observed_empirical_p_value |
|:---------|:---------|:----------|--------:|--------:|--------:|:-----------------------------------|:---------------------------------------------------|--------------:|--------------:|------------:|--------------:|------------------------:|---------------------:|---------------------:|---------------------:|---------------------:|------------------:|-------------------:|-----------------------------:|
| EZmock   | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 | raw_no_template_regression         | 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20 |            20 |            11 |           9 |            11 |              0.00825156 |           0.00962284 |           0.0106352  |           0.0109117  |            0.0326834 |           204.166 |           -72.2818 |                    0.0833333 |
| EZmock   | ELG      | NGC+SGC   |     0.8 |     1.1 |      16 | after_external_template_regression | 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20 |            20 |            11 |           9 |            11 |              0.00466008 |           0.00529117 |           0.00760857 |           0.00762322 |            0.0229974 |           222.055 |           -71.6975 |                    0.0833333 |

## Per-realization fits

| family   |   realization | tracer   | regions   |   n_data |   n_random |   raw_amplitude |   raw_ra_deg |   raw_dec_deg |   corrected_amplitude |   corrected_ra_deg |   corrected_dec_deg |
|:---------|--------------:|:---------|:----------|---------:|-----------:|----------------:|-------------:|--------------:|----------------------:|-------------------:|--------------------:|
| EZmock   |             1 | ELG      | NGC+SGC   |   953025 |    7700605 |      0.00416212 |     185.033  |       47.1152 |            0.00222177 |           320.112  |            59.5982  |
| EZmock   |             2 | ELG      | NGC+SGC   |   953136 |    7708608 |      0.00860914 |     218.674  |      -32.6699 |            0.00386451 |           254.631  |           -27.6037  |
| EZmock   |             3 | ELG      | NGC+SGC   |   947495 |    7684953 |      0.00497722 |     202.636  |      -12.5182 |            0.00267136 |           192.427  |           -33.4598  |
| EZmock   |             4 | ELG      | NGC+SGC   |   944219 |    7647787 |      0.00659241 |      27.9758 |       53.9961 |            0.00315333 |           341.261  |            36.5813  |
| EZmock   |             5 | ELG      | NGC+SGC   |   949519 |    7688681 |      0.00186621 |     332.627  |      -27.0675 |            0.00270608 |           152.28   |           -59.362   |
| EZmock   |             6 | ELG      | NGC+SGC   |   946111 |    7660559 |      0.0102896  |      40.1813 |       48.0421 |            0.00762689 |            89.2675 |            44.7882  |
| EZmock   |             7 | ELG      | NGC+SGC   |   950075 |    7688215 |      0.0100524  |     332.165  |       56.2024 |            0.00538016 |           258.258  |           -57.2439  |
| EZmock   |             8 | ELG      | NGC+SGC   |   948206 |    7687291 |      0.00436735 |     308.668  |       22.308  |            0.00759026 |           292.413  |           -33.2875  |
| EZmock   |             9 | ELG      | NGC+SGC   |   947057 |    7673651 |      0.00825156 |     310.625  |       10.5531 |            0.00466008 |           289.696  |            -4.32465 |
| EZmock   |            10 | ELG      | NGC+SGC   |   948624 |    7683514 |      0.0109808  |     210.152  |       59.4651 |            0.00706423 |           278.983  |            54.6277  |
| EZmock   |            11 | ELG      | NGC+SGC   |   946811 |    7671984 |      0.00987627 |     315.201  |       61.7574 |            0.00493522 |           279.604  |            55.2702  |

## Skipped realizations

- mock12: unreadable or incomplete FITS files (FITSIO status = 107: tried to move past end of file
FITSIO status = 107: tried to move past end of file
)
- mock13: missing 4 files
- mock14: missing 4 files
- mock15: missing 4 files
- mock16: missing 4 files
- mock17: missing 4 files
- mock18: missing 4 files
- mock19: missing 4 files
- mock20: missing 4 files

## Interpretation

- This is the preferred direction for cosmology-grade calibration because
the covariance comes from DESI-distributed mock catalogs.
- A 20-realization subset is useful as a smoke ensemble. Stable p-values
need a larger EZmock batch.
