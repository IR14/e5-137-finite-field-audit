# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 2
- redshift range: `1.5` to `3.5`

## Sample

- joined rows on TARGETID: 758337
- finite residual rows: 758337
- observable: `CIII_1908_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.14825
- axis RA: 132.129 deg
- axis DEC: -42.987 deg
- fitted pixels: 1004
- block-null p-value: 0.9041916167664671
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_ciii_1908_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|---------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    799010 |          20984 |                      19689 |                          0 |    758337 |       40673 | CIII_1908_EW        |       0.118456 |        77.8566 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    12.8501    |
| z                     |    -1.19151   |
| z2                    |     1.5579    |
| LOGMSTAR              |    -0.769976  |
| RCHI2_LINE            |    -0.0114014 |
| DELTA_LINECHI2        |     0.0262183 |
| FLUX_SYNTH_G          |     0.307218  |
| FLUX_SYNTH_R          |    -1.85422   |
| FLUX_SYNTH_Z          |     0.597964  |
| FLUX_G                |     1.02864   |
| FLUX_R                |    -0.810388  |
| FLUX_Z                |     0.520161  |
| FLUX_W1               |     0.0168863 |
| FLUX_W2               |     0.124898  |
| template_0_ebv        |    -0.0563927 |
| template_1_stardens   |    -0.0114402 |
| template_2_galdepth_g |    -0.0645249 |
| template_3_galdepth_r |    -0.172023  |
| template_4_galdepth_z |     0.152133  |
| template_5_psfsize_g  |    -0.0950418 |
| template_6_psfsize_r  |     0.040106  |
| template_7_psfsize_z  |    -0.0796577 |
| template_8_cosky_g    |    -0.158171  |
| template_9_cosky_r    |    -0.0379587 |
| template_10_cosky_z   |     0.0801479 |

## Figures

- `outputs/figures/qso_highz_line_ciii_1908_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_ciii_1908_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
