# Phase 5 Tau-Prime Final Appendix

## Formula

The proposed fourth-generation benchmark is

```text
m_tau_prime / m_e = alpha^-1 * [D^2 + q * (D * N)]
q = N(N - 2) / (e^4 pi^3)
N = 5
D = 26
```

The previously empirical digit moment is rewritten as

```text
I5 = 2 * (D - N) = 42
```

and the fourth-generation coefficient is

```text
D * N = 130
```

## Numerical Result

| quantity | value |
|---|---:|
| q | 0.008860611874291 |
| bracket D^2 + qDN | 677.151879543658 |
| m_tau_prime / m_e | 92794.184344873574 |
| m_tau_prime [MeV] | 47417.730830365 |
| m_tau_prime [GeV] | 47.417730830365 |

## Threshold Check

| reference threshold | threshold [GeV] | passes |
|---|---:|---:|
| LEP Z-width-scale reference used in this project | 45.0 | True |
| PDG sequential charged heavy lepton mass limit | 100.8 | False |

## Interpretation Guardrail

The value is above the project-level 45 GeV threshold, but it is below the
current PDG sequential charged-heavy-lepton limit of about 100.8 GeV. Therefore
this benchmark should not be described as an allowed ordinary charged fourth
generation lepton. If retained, it must be framed as a sterile, weakly coupled,
or otherwise non-standard benchmark requiring a dedicated collider and
cosmology reinterpretation.

Reference links used for the threshold guardrail:

- PDG Live, sequential charged heavy lepton mass limits:
  https://pdglive.lbl.gov/view/S025MS
- PDG Live, stable neutral heavy lepton mass limits:
  https://pdglive.lbl.gov/view/S077MNS

Status: ARCHIVED/SHUTDOWN for this speculative extension unless a new
pre-registered experimental test is defined.
