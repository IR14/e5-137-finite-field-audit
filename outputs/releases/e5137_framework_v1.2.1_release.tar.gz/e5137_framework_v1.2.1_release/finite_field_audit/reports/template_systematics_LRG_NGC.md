# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| LRG      | NGC      |     0.4 |     0.6 |            18 |              0.0220995 |       0.0515915 |           0.39972  |                 0.156422 |            0.00794501 |                 0.992002 |                       0.965017 |                           0.153998 |                           49.2362 |
| LRG      | NGC      |     0.6 |     0.8 |            18 |              0.0578523 |       0.0227314 |           0.833633 |                 0.581209 |            0.00404535 |                 0.9984   |                       0.971514 |                           0.177963 |                           44.2989 |
| LRG      | NGC      |     0.8 |     1.1 |            18 |              0.0497409 |       0.0181385 |           0.857029 |                 0.662169 |            0.00628164 |                 0.993601 |                       0.948526 |                           0.346315 |                           17.87   |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| LRG      | NGC      |     0.4 |     0.6 | intercept                          |  -0.00467912  |
| LRG      | NGC      |     0.4 |     0.6 | photsys=N                          |   0.000943666 |
| LRG      | NGC      |     0.4 |     0.6 | ntile                              |   0.0186436   |
| LRG      | NGC      |     0.4 |     0.6 | frac_tlobs_tiles                   |   0.0612141   |
| LRG      | NGC      |     0.4 |     0.6 | nx                                 |  -0.0744194   |
| LRG      | NGC      |     0.4 |     0.6 | weight_sys                         |   0.00416259  |
| LRG      | NGC      |     0.4 |     0.6 | weight_zfail                       |   0.00877386  |
| LRG      | NGC      |     0.4 |     0.6 | weight_comp                        |  -0.014591    |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_ebv        |  -0.00823488  |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_stardens   |   0.0108263   |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_g |   0.000193521 |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_r |  -0.0037704   |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_galdepth_z |   0.00873195  |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_g  |   0.01384     |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_r  |   0.00612878  |
| LRG      | NGC      |     0.4 |     0.6 | external:pixweight_dark_psfsize_z  |  -0.00266506  |
| LRG      | NGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_g |  -0.0177857   |
| LRG      | NGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_r |   0.0129361   |
| LRG      | NGC      |     0.4 |     0.6 | external:legacy_dr9_bricks_cosky_z |  -0.00282715  |
| LRG      | NGC      |     0.6 |     0.8 | intercept                          |  -0.0038683   |
| LRG      | NGC      |     0.6 |     0.8 | photsys=N                          |   0.0280108   |
| LRG      | NGC      |     0.6 |     0.8 | ntile                              |   0.00340877  |
| LRG      | NGC      |     0.6 |     0.8 | frac_tlobs_tiles                   |   0.0726611   |
| LRG      | NGC      |     0.6 |     0.8 | nx                                 |  -0.0645937   |
| LRG      | NGC      |     0.6 |     0.8 | weight_sys                         |  -0.00521511  |
| LRG      | NGC      |     0.6 |     0.8 | weight_zfail                       |   0.0277399   |
| LRG      | NGC      |     0.6 |     0.8 | weight_comp                        |  -0.0771866   |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_ebv        |   0.00827915  |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_stardens   |  -0.000421594 |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_g |  -0.0468379   |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_r |   0.0088859   |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_galdepth_z |  -0.00590944  |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_g  |   0.00508504  |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_r  |   0.0109123   |
| LRG      | NGC      |     0.6 |     0.8 | external:pixweight_dark_psfsize_z  |  -0.00270679  |
| LRG      | NGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_g |   0.00660027  |
| LRG      | NGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_r |   0.0251742   |
| LRG      | NGC      |     0.6 |     0.8 | external:legacy_dr9_bricks_cosky_z |  -0.0059951   |
| LRG      | NGC      |     0.8 |     1.1 | intercept                          |  -0.00526978  |
| LRG      | NGC      |     0.8 |     1.1 | photsys=N                          |   0.130726    |
| LRG      | NGC      |     0.8 |     1.1 | ntile                              |   0.00130054  |
| LRG      | NGC      |     0.8 |     1.1 | frac_tlobs_tiles                   |   0.0298763   |
| LRG      | NGC      |     0.8 |     1.1 | nx                                 |  -0.0257315   |
| LRG      | NGC      |     0.8 |     1.1 | weight_sys                         |  -0.0166657   |
| LRG      | NGC      |     0.8 |     1.1 | weight_zfail                       |   0.065599    |
| LRG      | NGC      |     0.8 |     1.1 | weight_comp                        |  -0.042113    |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_ebv        |   0.00200101  |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_stardens   |  -0.00462598  |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_g |  -0.00191148  |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_r |   0.00564235  |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_galdepth_z |   0.000228415 |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_g  |  -0.0254907   |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_r  |   0.0117341   |
| LRG      | NGC      |     0.8 |     1.1 | external:pixweight_dark_psfsize_z  |   0.00425979  |
| LRG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_g |  -0.0677276   |
| LRG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_r |   0.0486338   |
| LRG      | NGC      |     0.8 |     1.1 | external:legacy_dr9_bricks_cosky_z |   0.00711468  |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
