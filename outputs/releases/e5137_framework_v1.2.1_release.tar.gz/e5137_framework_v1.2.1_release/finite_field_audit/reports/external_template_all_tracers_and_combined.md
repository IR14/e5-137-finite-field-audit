# External-template regression: all tracers and combined maps

This report summarizes the external-template control pass after adding DESI pixweight and Legacy Survey sky-brightness templates.

## Regional NGC/SGC results

- Source table: `outputs/tables/template_systematics_all_tracers_NGC_SGC_external_template_summary.csv`
- Look-elsewhere table: `outputs/tables/template_systematics_all_tracers_NGC_SGC_external_template_look_elsewhere.csv`
- Tested regional bins: 20
- Minimum corrected permutation p-value: 0.546491
- Minimum regional Bonferroni p-value: 1
- Minimum regional BH-FDR p-value: 0.9998

| tracer   | region   |   z_min |   z_max |   raw_amplitude |   raw_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_bonferroni_p |   corrected_bh_fdr_p |   corrected_block_null_p_value |
|:---------|:---------|--------:|--------:|----------------:|-------------------:|----------------------:|-------------------------:|-------------------------:|---------------------:|-------------------------------:|
| ELG      | SGC      |     0.8 |     1.1 |      0.0887852  |           0.29774  |            0.0660569  |                 0.546491 |                        1 |               0.9998 |                      0.181409  |
| ELG      | SGC      |     1.1 |     1.4 |      0.0729452  |           0.386123 |            0.0510521  |                 0.643871 |                        1 |               0.9998 |                      0.0834583 |
| QSO      | SGC      |     2.1 |     3.5 |      0.0164375  |           0.970406 |            0.027418   |                 0.889022 |                        1 |               0.9998 |                      0.417291  |
| QSO      | SGC      |     1.2 |     1.6 |      0.0485589  |           0.809238 |            0.0224971  |                 0.966007 |                        1 |               0.9998 |                      0.29985   |
| LRG      | SGC      |     0.4 |     0.6 |      0.0575672  |           0.782244 |            0.025737   |                 0.972206 |                        1 |               0.9998 |                      0.603698  |
| ELG      | NGC      |     1.1 |     1.4 |      0.0252578  |           0.75165  |            0.00795293 |                 0.984803 |                        1 |               0.9998 |                      0.782109  |
| ELG      | SGC      |     1.4 |     1.6 |      0.0627376  |           0.586683 |            0.0138038  |                 0.989402 |                        1 |               0.9998 |                      0.86007   |
| QSO      | NGC      |     1.2 |     1.6 |      0.00678197 |           0.991002 |            0.00738992 |                 0.990802 |                        1 |               0.9998 |                      0.826587  |
| LRG      | SGC      |     0.6 |     0.8 |      0.0368132  |           0.834433 |            0.0107976  |                 0.991802 |                        1 |               0.9998 |                      0.978011  |
| LRG      | NGC      |     0.4 |     0.6 |      0.0515915  |           0.39972  |            0.00794501 |                 0.992002 |                        1 |               0.9998 |                      0.965017  |
| LRG      | NGC      |     0.8 |     1.1 |      0.0181385  |           0.857029 |            0.00628164 |                 0.993601 |                        1 |               0.9998 |                      0.948526  |
| ELG      | NGC      |     0.8 |     1.1 |      0.0370462  |           0.391722 |            0.00455422 |                 0.994801 |                        1 |               0.9998 |                      0.952524  |
| QSO      | NGC      |     0.8 |     1.2 |      0.0194676  |           0.878624 |            0.0046078  |                 0.997401 |                        1 |               0.9998 |                      0.975512  |
| LRG      | SGC      |     0.8 |     1.1 |      0.0486999  |           0.663067 |            0.00687437 |                 0.9982   |                        1 |               0.9998 |                      0.98001   |
| LRG      | NGC      |     0.6 |     0.8 |      0.0227314  |           0.833633 |            0.00404535 |                 0.9984   |                        1 |               0.9998 |                      0.971514  |
| ELG      | NGC      |     1.4 |     1.6 |      0.0156957  |           0.978204 |            0.00579143 |                 0.9986   |                        1 |               0.9998 |                      0.98051   |
| QSO      | SGC      |     0.8 |     1.2 |      0.0272225  |           0.912418 |            0.0054243  |                 0.999    |                        1 |               0.9998 |                      0.990005  |
| QSO      | SGC      |     1.6 |     2.1 |      0.0257643  |           0.974405 |            0.00801913 |                 0.9992   |                        1 |               0.9998 |                      0.986507  |
| QSO      | NGC      |     2.1 |     3.5 |      0.00850963 |           0.973005 |            0.00177431 |                 0.9996   |                        1 |               0.9998 |                      0.987506  |
| QSO      | NGC      |     1.6 |     2.1 |      0.0101251  |           0.954409 |            0.00256707 |                 0.9998   |                        1 |               0.9998 |                      0.984508  |

## Combined NGC+SGC external-template regression

- Source table: `outputs/tables/combined_external_template_systematics_NGC_SGC.csv`
- Look-elsewhere table: `outputs/tables/combined_external_template_systematics_NGC_SGC_look_elsewhere.csv`
- Tested combined bins: 10
- Minimum combined corrected permutation p-value: 0.329534
- Minimum combined Bonferroni p-value: 1
- Minimum combined BH-FDR p-value: 0.9998

| tracer   | region   |   z_min |   z_max |   raw_amplitude |   raw_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_bonferroni_p |   corrected_bh_fdr_p |   corrected_block_null_p_value |
|:---------|:---------|--------:|--------:|----------------:|-------------------:|----------------------:|-------------------------:|-------------------------:|---------------------:|-------------------------------:|
| ELG      | NGC+SGC  |     0.8 |     1.1 |      0.0326834  |           0.125375 |            0.0229974  |                 0.329534 |                        1 |               0.9998 |                      0.0164918 |
| ELG      | NGC+SGC  |     1.1 |     1.4 |      0.0267839  |           0.256949 |            0.021825   |                 0.411718 |                        1 |               0.9998 |                      0.0209895 |
| QSO      | NGC+SGC  |     0.8 |     1.2 |      0.0169211  |           0.615077 |            0.00749427 |                 0.942412 |                        1 |               0.9998 |                      0.605197  |
| LRG      | NGC+SGC  |     0.4 |     0.6 |      0.00765366 |           0.964607 |            0.00912375 |                 0.946411 |                        1 |               0.9998 |                      0.842579  |
| LRG      | NGC+SGC  |     0.6 |     0.8 |      0.00792218 |           0.943211 |            0.00660526 |                 0.965407 |                        1 |               0.9998 |                      0.876062  |
| QSO      | NGC+SGC  |     1.2 |     1.6 |      0.00624834 |           0.973605 |            0.0062314  |                 0.967806 |                        1 |               0.9998 |                      0.487756  |
| ELG      | NGC+SGC  |     1.4 |     1.6 |      0.0178394  |           0.788642 |            0.00825    |                 0.969806 |                        1 |               0.9998 |                      0.754123  |
| LRG      | NGC+SGC  |     0.8 |     1.1 |      0.0159111  |           0.589482 |            0.00464025 |                 0.977804 |                        1 |               0.9998 |                      0.833583  |
| QSO      | NGC+SGC  |     2.1 |     3.5 |      0.00862052 |           0.856629 |            0.00317136 |                 0.991402 |                        1 |               0.9998 |                      0.897551  |
| QSO      | NGC+SGC  |     1.6 |     2.1 |      0.00486161 |           0.964607 |            0.00059115 |                 0.9998   |                        1 |               0.9998 |                      0.9995    |

## Interpretation

- Regional LRG and QSO bins are all high-p after external-template correction.
- Regional ELG SGC remains the largest residual, but its corrected permutation p-values are not low after external-template regression.
- Combined NGC+SGC maps do not show a significant corrected permutation p-value after look-elsewhere correction.
- Two ELG combined rows still have low block sign-flip p-values, while permutation p-values are moderate; this flags residual footprint/block sensitivity rather than a detection.
- The current result remains compatible with the isotropic null under these first-pass controls.
