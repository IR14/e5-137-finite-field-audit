# QSO high-z density external-template scan

This is a density-overdensity dipole test, not a FastSpecFit population-residual test.
It uses QSO NGC+SGC LSS clustering catalogs, random catalogs for the survey mask,
and external imaging templates for a regression diagnostic.

## Configuration

- tracer: QSO
- regions: NGC+SGC
- redshift bins: 1.5-2.1, 2.1-3.5
- nside: 16
- null permutations: 5000
- block-null mocks: 5000
- block-null regions: 48
- external templates: EBV, stellar density, galdepth g/r/z, psfsize g/r/z, COSKY g/r/z

## Results

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_ra_deg |   raw_dec_deg |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_ra_deg |   corrected_dec_deg |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|---------:|-----------:|--------------:|-----------------------:|----------------:|-------------:|--------------:|-------------------:|-------------------------:|----------------------:|-------------------:|--------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| QSO      | NGC+SGC  |     1.5 |     2.1 |   432458 |    6407012 |            11 |             0.00397583 |      0.00378379 |      46.9462 |       51.7561 |           0.991602 |                 0.834633 |            0.00370284 |            87.9613 |           -78.0021  |                 0.992801 |                       0.840432 |                           0.978605 |                           47.8453 |
| QSO      | NGC+SGC  |     2.1 |     3.5 |   366560 |    5431342 |            11 |             0.0113641  |      0.00860659 |     324.673  |       15.9656 |           0.85123  |                 0.240952 |            0.00398731 |           329.996  |            -4.00984 |                 0.980404 |                       0.780044 |                           0.463285 |                           20.6578 |

## Interpretation

- Minimum permutation p-value across raw/corrected high-z bins: `0.85123`.
- Minimum block-null p-value across raw/corrected high-z bins: `0.240952`.
- Low p-values here would be a trigger for mock calibration, not a detection by themselves.
- A large raw-to-corrected axis shift or amplitude reduction indicates coupling to imaging templates.
