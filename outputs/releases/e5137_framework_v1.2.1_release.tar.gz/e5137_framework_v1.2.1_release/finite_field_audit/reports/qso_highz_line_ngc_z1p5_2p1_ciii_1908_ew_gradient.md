# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_ngc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_vac.parquet`
- random catalogs: 1
- redshift range: `1.5` to `2.1`

## Sample

- joined rows on TARGETID: 264221
- finite residual rows: 264221
- observable: `CIII_1908_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.129588
- axis RA: 62.562 deg
- axis DEC: -53.136 deg
- fitted pixels: 632
- block-null p-value: 0.9720558882235529
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_ciii_1908_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column   |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|---------------------------:|---------------------------:|----------:|------------:|:--------------------|---------------:|---------------:|
| enabled        |    281436 |           8848 |                       8367 |                          0 |    264221 |       17215 | CIII_1908_EW        |      0.0770324 |        80.1154 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |    12.1254    |
| z                     |    -4.35156   |
| z2                    |     3.90816   |
| LOGMSTAR              |    -0.68143   |
| RCHI2_LINE            |    -0.0255629 |
| DELTA_LINECHI2        |    -0.0922752 |
| FLUX_SYNTH_G          |    -0.155022  |
| FLUX_SYNTH_R          |    -1.20488   |
| FLUX_SYNTH_Z          |     0.499116  |
| FLUX_G                |     0.416027  |
| FLUX_R                |    -0.94999   |
| FLUX_Z                |     1.38588   |
| FLUX_W1               |    -0.273681  |
| FLUX_W2               |     0.226695  |
| template_0_ebv        |    -0.103524  |
| template_1_stardens   |     0.0277076 |
| template_2_galdepth_g |     0.0533804 |
| template_3_galdepth_r |     0.0589789 |
| template_4_galdepth_z |     0.0595038 |
| template_5_psfsize_g  |    -0.0527798 |
| template_6_psfsize_r  |     0.0515286 |
| template_7_psfsize_z  |    -0.114578  |
| template_8_cosky_g    |    -0.055713  |
| template_9_cosky_r    |    -0.0804389 |
| template_10_cosky_z   |     0.176194  |

## Figures

- `outputs/figures/qso_highz_line_ngc_z1p5_2p1_ciii_1908_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_highz_line_ngc_z1p5_2p1_ciii_1908_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
