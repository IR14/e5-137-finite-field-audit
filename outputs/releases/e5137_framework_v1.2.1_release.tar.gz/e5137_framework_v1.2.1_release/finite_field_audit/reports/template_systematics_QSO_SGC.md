# Template systematics regression

This diagnostic regresses per-pixel survey templates from the overdensity map and
then refits the dipole on the residual map. A strong reduction or axis shift means
the candidate dipole is entangled with known survey metadata.

## Raw vs template-corrected dipoles

| tracer   | region   |   z_min |   z_max |   n_templates |   template_weighted_r2 |   raw_amplitude |   raw_null_p_value |   raw_block_null_p_value |   corrected_amplitude |   corrected_null_p_value |   corrected_block_null_p_value |   amplitude_ratio_corrected_to_raw |   axis_shift_raw_to_corrected_deg |
|:---------|:---------|--------:|--------:|--------------:|-----------------------:|----------------:|-------------------:|-------------------------:|----------------------:|-------------------------:|-------------------------------:|-----------------------------------:|----------------------------------:|
| QSO      | SGC      |     0.8 |     1.2 |            18 |              0.0267013 |       0.0272225 |           0.912418 |                0.608696  |            0.0054243  |                 0.999    |                       0.990005 |                           0.199258 |                           89.0581 |
| QSO      | SGC      |     1.2 |     1.6 |            18 |              0.0341008 |       0.0485589 |           0.809238 |                0.0414793 |            0.0224971  |                 0.966007 |                       0.29985  |                           0.463295 |                           86.5125 |
| QSO      | SGC      |     1.6 |     2.1 |            18 |              0.0444202 |       0.0257643 |           0.974405 |                0.734133  |            0.00801913 |                 0.9992   |                       0.986507 |                           0.31125  |                           81.8848 |
| QSO      | SGC      |     2.1 |     3.5 |            18 |              0.0295673 |       0.0164375 |           0.970406 |                0.882559  |            0.027418   |                 0.889022 |                       0.417291 |                           1.66801  |                           59.5906 |

## Template coefficients

| tracer   | region   |   z_min |   z_max | term                               |   coefficient |
|:---------|:---------|--------:|--------:|:-----------------------------------|--------------:|
| QSO      | SGC      |     0.8 |     1.2 | intercept                          |   0.000493002 |
| QSO      | SGC      |     0.8 |     1.2 | ntile                              |  -0.00305957  |
| QSO      | SGC      |     0.8 |     1.2 | frac_tlobs_tiles                   |   0.00283447  |
| QSO      | SGC      |     0.8 |     1.2 | nx                                 |   0.00539861  |
| QSO      | SGC      |     0.8 |     1.2 | weight_sys                         |  -0.0146123   |
| QSO      | SGC      |     0.8 |     1.2 | weight_rf                          |  -0.0146123   |
| QSO      | SGC      |     0.8 |     1.2 | weight_zfail                       |  -0.00635473  |
| QSO      | SGC      |     0.8 |     1.2 | weight_comp                        |  -0.0296776   |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_ebv        |  -0.00010303  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_stardens   |   0.000217556 |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_g |   0.00632411  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_r |   0.00585364  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_galdepth_z |  -0.00738421  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_g  |  -0.00426716  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_r  |   0.00698623  |
| QSO      | SGC      |     0.8 |     1.2 | external:pixweight_dark_psfsize_z  |   0.0106576   |
| QSO      | SGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_g |  -0.00935233  |
| QSO      | SGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_r |  -0.00601146  |
| QSO      | SGC      |     0.8 |     1.2 | external:legacy_dr9_bricks_cosky_z |   0.0120408   |
| QSO      | SGC      |     1.2 |     1.6 | intercept                          |   0.000514431 |
| QSO      | SGC      |     1.2 |     1.6 | ntile                              |  -0.00627532  |
| QSO      | SGC      |     1.2 |     1.6 | frac_tlobs_tiles                   |  -0.00669593  |
| QSO      | SGC      |     1.2 |     1.6 | nx                                 |   0.00615605  |
| QSO      | SGC      |     1.2 |     1.6 | weight_sys                         |  -0.00197162  |
| QSO      | SGC      |     1.2 |     1.6 | weight_rf                          |  -0.00197162  |
| QSO      | SGC      |     1.2 |     1.6 | weight_zfail                       |   0.00189704  |
| QSO      | SGC      |     1.2 |     1.6 | weight_comp                        |   0.00609663  |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_ebv        |   0.00297566  |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_stardens   |  -0.0162648   |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_g |   0.000138657 |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_r |  -0.0232795   |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_galdepth_z |  -0.0104683   |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_g  |   0.0014569   |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_r  |   0.00644266  |
| QSO      | SGC      |     1.2 |     1.6 | external:pixweight_dark_psfsize_z  |  -0.00908691  |
| QSO      | SGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_g |  -0.0169782   |
| QSO      | SGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_r |   0.0198227   |
| QSO      | SGC      |     1.2 |     1.6 | external:legacy_dr9_bricks_cosky_z |  -0.012267    |
| QSO      | SGC      |     1.6 |     2.1 | intercept                          |   0.00526938  |
| QSO      | SGC      |     1.6 |     2.1 | ntile                              |   0.0052165   |
| QSO      | SGC      |     1.6 |     2.1 | frac_tlobs_tiles                   |  -0.00568454  |
| QSO      | SGC      |     1.6 |     2.1 | nx                                 |  -0.0125008   |
| QSO      | SGC      |     1.6 |     2.1 | weight_sys                         |   0.00618307  |
| QSO      | SGC      |     1.6 |     2.1 | weight_rf                          |   0.00618307  |
| QSO      | SGC      |     1.6 |     2.1 | weight_zfail                       |   0.0070894   |
| QSO      | SGC      |     1.6 |     2.1 | weight_comp                        |   0.0180868   |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_ebv        |  -0.00741722  |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_stardens   |   0.00890313  |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_g |  -0.000485217 |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_r |   0.00276681  |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_galdepth_z |   0.000672754 |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_g  |  -0.0141371   |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_r  |   0.00340165  |
| QSO      | SGC      |     1.6 |     2.1 | external:pixweight_dark_psfsize_z  |  -0.00276843  |
| QSO      | SGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_g |   0.0238265   |
| QSO      | SGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_r |   0.00150361  |
| QSO      | SGC      |     1.6 |     2.1 | external:legacy_dr9_bricks_cosky_z |  -0.00688827  |
| QSO      | SGC      |     2.1 |     3.5 | intercept                          |   0.000860418 |
| QSO      | SGC      |     2.1 |     3.5 | ntile                              |  -0.0129674   |
| QSO      | SGC      |     2.1 |     3.5 | frac_tlobs_tiles                   |   0.00106733  |
| QSO      | SGC      |     2.1 |     3.5 | nx                                 |   0.0158188   |
| QSO      | SGC      |     2.1 |     3.5 | weight_sys                         |   0.022492    |
| QSO      | SGC      |     2.1 |     3.5 | weight_rf                          |   0.022492    |
| QSO      | SGC      |     2.1 |     3.5 | weight_zfail                       |   0.00356482  |
| QSO      | SGC      |     2.1 |     3.5 | weight_comp                        |  -0.034984    |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_ebv        |   0.00473155  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_stardens   |   0.00769452  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_g |  -0.00199942  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_r |  -0.00778694  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_galdepth_z |   0.00908709  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_g  |  -0.00416512  |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_r  |  -0.000948079 |
| QSO      | SGC      |     2.1 |     3.5 | external:pixweight_dark_psfsize_z  |   0.0146522   |
| QSO      | SGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_g |   0.000736782 |
| QSO      | SGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_r |  -0.0140256   |
| QSO      | SGC      |     2.1 |     3.5 | external:legacy_dr9_bricks_cosky_z |   0.0132615   |

## Interpretation

Template regression is a diagnostic, not a final correction model. It can reveal
whether a candidate axis is aligned with known survey metadata, but final claims
need validated survey mocks and external imaging-systematics maps.
