# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/ELG_LOPnotqso_NGC_clustering.dat.fits`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 1
- redshift range: `0.8` to `1.6`

## Sample

- joined rows on TARGETID: 1821317
- finite residual rows: 1821317
- observable: `DN4000`
- controls: `z; z2; LOGMSTAR`

## Dipole Fit

- amplitude: 0.0514194
- axis RA: 24.615 deg
- axis DEC: -34.747 deg
- fitted pixels: 644

## Residual Model Coefficients

| term      |   coefficient |
|:----------|--------------:|
| intercept |     1.23169   |
| z         |     2.52537   |
| z2        |    -2.85927   |
| LOGMSTAR  |     0.0234011 |

## Figures

- `outputs/figures/desi_fastspecfit_gradient_validation_elg_ngc_dn4000_residual_vs_z.png`
- `outputs/figures/desi_fastspecfit_gradient_validation_elg_ngc_dn4000_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
