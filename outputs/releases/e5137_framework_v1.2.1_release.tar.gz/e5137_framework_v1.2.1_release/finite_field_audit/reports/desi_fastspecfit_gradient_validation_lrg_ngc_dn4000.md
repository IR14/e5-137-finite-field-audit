# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/LRG_NGC_clustering.dat.fits`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/raw/vac/fastspecfit/iron/v2.1/catalogs/fastspec-iron-main-dark.fits`
- random catalogs: 1
- redshift range: `0.4` to `1.1`

## Sample

- joined rows on TARGETID: 1476131
- finite residual rows: 1476131
- observable: `DN4000`
- controls: `z; z2; LOGMSTAR`

## Dipole Fit

- amplitude: 0.0147759
- axis RA: 199.464 deg
- axis DEC: -3.056 deg
- fitted pixels: 648

## Residual Model Coefficients

| term      |   coefficient |
|:----------|--------------:|
| intercept |    1.71664    |
| z         |    0.0894755  |
| z2        |   -0.10935    |
| LOGMSTAR  |   -0.00319635 |

## Figures

- `outputs/figures/desi_fastspecfit_gradient_validation_lrg_ngc_dn4000_residual_vs_z.png`
- `outputs/figures/desi_fastspecfit_gradient_validation_lrg_ngc_dn4000_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
