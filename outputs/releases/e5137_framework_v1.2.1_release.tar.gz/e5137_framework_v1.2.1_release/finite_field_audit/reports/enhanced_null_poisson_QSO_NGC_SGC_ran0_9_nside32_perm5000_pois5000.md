# First-pass directional-gradient report

## Scope

This report tests whether tracer density maps are compatible with an isotropic null model
after correcting the angular footprint with random catalogs. It does not claim evidence
for a genesis-gradient model or any alternative to Lambda-CDM.

## Data mode

- Mode: real DESI-style catalog inputs.

## Fitted dipoles

| tracer   | region   |   z_min |   z_max |   n_data |   n_random |   amplitude |   amplitude_std |    ra_deg |   dec_deg |   null_p_value |
|:---------|:---------|--------:|--------:|---------:|-----------:|------------:|----------------:|----------:|----------:|---------------:|
| QSO      | NGC      |     0.8 |     1.2 |   133606 |   19526917 |  0.0182969  |      0.0123599  | 349.031   |   77.3898 |       0.814637 |
| QSO      | NGC      |     1.2 |     1.6 |   191793 |   28090342 |  0.00656099 |      0.0094448  |  53.7285  |   57.7521 |       0.981204 |
| QSO      | NGC      |     1.6 |     2.1 |   230514 |   33738763 |  0.010364   |      0.00856275 |   5.16799 |   25.4611 |       0.932414 |
| QSO      | NGC      |     2.1 |     3.5 |   237306 |   34740210 |  0.00836338 |      0.00815254 | 358.632   |   30.3715 |       0.946611 |
| QSO      | SGC      |     0.8 |     1.2 |    72742 |   11016448 |  0.0269636  |      0.0231146  |  13.4851  |   12.2104 |       0.846031 |
| QSO      | SGC      |     1.2 |     1.6 |   104480 |   15788596 |  0.0475859  |      0.0260379  |  16.7271  |  -13.7549 |       0.512298 |
| QSO      | SGC      |     1.6 |     2.1 |   123696 |   18745654 |  0.0267847  |      0.0195551  | 188.904   |  -22.6415 |       0.833433 |
| QSO      | SGC      |     2.1 |     3.5 |   129254 |   19573058 |  0.0164248  |      0.0136587  | 276.418   |  -14.0358 |       0.913217 |

## Cross-bin and cross-tracer axis separations

| left            | right           |   separation_deg |
|:----------------|:----------------|-----------------:|
| QSO 0.800-1.200 | QSO 1.200-1.600 |         28.9393  |
| QSO 0.800-1.200 | QSO 1.600-2.100 |         52.4918  |
| QSO 0.800-1.200 | QSO 2.100-3.500 |         47.2246  |
| QSO 0.800-1.200 | QSO 0.800-1.200 |         66.382   |
| QSO 0.800-1.200 | QSO 1.200-1.600 |         92.5375  |
| QSO 0.800-1.200 | QSO 1.600-2.100 |        124.414   |
| QSO 0.800-1.200 | QSO 2.100-3.500 |         99.9847  |
| QSO 1.200-1.600 | QSO 1.600-2.100 |         46.9663  |
| QSO 1.200-1.600 | QSO 2.100-3.500 |         46.2883  |
| QSO 1.200-1.600 | QSO 0.800-1.200 |         54.7636  |
| QSO 1.200-1.600 | QSO 1.200-1.600 |         77.7125  |
| QSO 1.200-1.600 | QSO 1.600-2.100 |        132.444   |
| QSO 1.200-1.600 | QSO 2.100-3.500 |        125.846   |
| QSO 1.600-2.100 | QSO 2.100-3.500 |          7.57746 |
| QSO 1.600-2.100 | QSO 0.800-1.200 |         15.4     |
| QSO 1.600-2.100 | QSO 1.200-1.600 |         40.8012  |
| QSO 1.600-2.100 | QSO 1.600-2.100 |        175.575   |
| QSO 1.600-2.100 | QSO 2.100-3.500 |         94.8847  |
| QSO 2.100-3.500 | QSO 0.800-1.200 |         22.7784  |
| QSO 2.100-3.500 | QSO 1.200-1.600 |         47.4401  |
| QSO 2.100-3.500 | QSO 1.600-2.100 |        168.001   |
| QSO 2.100-3.500 | QSO 2.100-3.500 |         90.529   |
| QSO 0.800-1.200 | QSO 1.200-1.600 |         26.1634  |
| QSO 0.800-1.200 | QSO 1.600-2.100 |        168.693   |
| QSO 0.800-1.200 | QSO 2.100-3.500 |         99.6686  |
| QSO 1.200-1.600 | QSO 1.600-2.100 |        142.805   |
| QSO 1.200-1.600 | QSO 2.100-3.500 |         96.371   |
| QSO 1.600-2.100 | QSO 2.100-3.500 |         82.4038  |

## Warnings and null-model discipline

- This is a first-pass density-gradient analysis, not evidence for or against a new cosmology.
- Survey mask, selection function, extinction, depth, and redshift failures must be audited before interpretation.
- A robust DESI analysis must audit survey geometry, extinction, depth, target selection, redshift failures, stellar contamination, and local-motion effects.
- A stable axis must be tested across independent tracer classes and redshift bins before physical interpretation.

## First-pass conclusion

Real-data first pass completed. Treat any low p-values as prompts for systematics checks, not discoveries.
