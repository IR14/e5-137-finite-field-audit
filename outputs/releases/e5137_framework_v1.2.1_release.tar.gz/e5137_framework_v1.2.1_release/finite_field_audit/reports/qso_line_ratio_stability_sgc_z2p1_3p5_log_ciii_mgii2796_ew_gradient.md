# DESI FastSpecFit gradient validation

This is an observational validation report. It does not introduce new analytic constants.

## Inputs

- LSS catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_sgc_highz_1p5_3p5_lss.parquet`
- VAC/population catalog: `/Users/i.mikhailov/Desktop/work/cosmo/cosmo_genesis_gradient/data/interim/qso_highz_1p5_3p5_fastspecfit_line_ratio_vac.parquet`
- random catalogs: 1
- redshift range: `2.1` to `3.5`

## Sample

- joined rows on TARGETID: 64809
- finite residual rows: 64809
- observable: `LOG_CIII_MGII2796_EW`
- controls: `z; z2; LOGMSTAR; RCHI2_LINE; DELTA_LINECHI2; FLUX_SYNTH_G; FLUX_SYNTH_R; FLUX_SYNTH_Z; FLUX_G; FLUX_R; FLUX_Z; FLUX_W1; FLUX_W2; template_0_ebv; template_1_stardens; template_2_galdepth_g; template_3_galdepth_r; template_4_galdepth_z; template_5_psfsize_g; template_6_psfsize_r; template_7_psfsize_z; template_8_cosky_g; template_9_cosky_r; template_10_cosky_z`

## Dipole Fit

- amplitude: 0.0602062
- axis RA: 129.319 deg
- axis DEC: 59.561 deg
- fitted pixels: 349
- block-null p-value: 0.8862275449101796
- block-null mocks: 500

## Quality Cuts

| quality_cuts   |   n_input |   n_fail_zwarn |   n_fail_log_ciii_mgii2796_ew_ivar |   n_fail_observable_finite |   n_after |   n_removed | winsorized_column    |   winsor_lower |   winsor_upper |
|:---------------|----------:|---------------:|-----------------------------------:|---------------------------:|----------:|------------:|:---------------------|---------------:|---------------:|
| enabled        |    129254 |           2873 |                              61572 |                          0 |     64809 |       64445 | LOG_CIII_MGII2796_EW |       -4.18394 |        10.7265 |

## Residual Model Coefficients

| term                  |   coefficient |
|:----------------------|--------------:|
| intercept             |   0.167285    |
| z                     |   1.26861     |
| z2                    |  -1.36866     |
| LOGMSTAR              |   0.0955721   |
| RCHI2_LINE            |  -0.0167926   |
| DELTA_LINECHI2        |   0.00647294  |
| FLUX_SYNTH_G          |  -0.0271956   |
| FLUX_SYNTH_R          |   0.0620523   |
| FLUX_SYNTH_Z          |  -0.0600607   |
| FLUX_G                |   0.104315    |
| FLUX_R                |  -0.139557    |
| FLUX_Z                |   0.0403561   |
| FLUX_W1               |   0.053763    |
| FLUX_W2               |  -0.0331844   |
| template_0_ebv        |  -0.00588003  |
| template_1_stardens   |  -0.00600243  |
| template_2_galdepth_g |   0.0302613   |
| template_3_galdepth_r |  -0.0394905   |
| template_4_galdepth_z |   0.00334571  |
| template_5_psfsize_g  |   0.000188922 |
| template_6_psfsize_r  |  -0.00796145  |
| template_7_psfsize_z  |   0.00533459  |
| template_8_cosky_g    |   0.0154506   |
| template_9_cosky_r    |   0.00863284  |
| template_10_cosky_z   |  -0.0096979   |

## Figures

- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_vs_z.png`
- `outputs/figures/qso_line_ratio_stability_sgc_z2p1_3p5_log_ciii_mgii2796_ew_gradient_residual_hist.png`

## Caveats

- This first local run fits a population-residual dipole only.
- Mock-calibrated p-values require rerunning the same estimator on the EZmock ensemble.
- A scientifically interpretable result requires stability across tracers, redshift bins, and systematics templates.
