# Look-elsewhere summary

Simple multiple-testing correction over selected test families.

| family                     |   n_tests |   min_permutation_p |   bonferroni_global_p |   sidak_global_p | row_with_min_p                                                 |
|:---------------------------|----------:|--------------------:|----------------------:|-----------------:|:---------------------------------------------------------------|
| ran012_nside16_all_regions |        20 |           0.231405  |             1         |        0.994825  | {'tracer': 'ELG', 'region': 'SGC', 'z_min': 0.8, 'z_max': 1.1} |
| enhanced_elg_sgc_perm5000  |         3 |           0.0557888 |             0.167367  |        0.158203  | {'tracer': 'ELG', 'region': 'SGC', 'z_min': 0.8, 'z_max': 1.1} |
| enhanced_elg_ngc_perm5000  |         3 |           0.344931  |             1         |        0.7189    | {'tracer': 'ELG', 'region': 'NGC', 'z_min': 0.8, 'z_max': 1.1} |
| systematics_audit_elg_sgc  |        33 |           0.001998  |             0.0659341 |        0.0638692 | {'tracer': 'ELG', 'region': 'SGC', 'z_min': 0.8, 'z_max': 1.1} |

Bonferroni/Sidak are conservative approximations here; they are useful guardrails, not a substitute for full correlated mocks.
