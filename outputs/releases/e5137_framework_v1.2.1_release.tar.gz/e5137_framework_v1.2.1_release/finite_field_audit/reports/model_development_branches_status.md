# Model development branches status

Created: 2026-05-27

This report records the three development branches opened after the DESI
LRG/QSO active-null results.

## Branch A: Adversarial Number-Theory Lab

Artifacts:

- `scripts/phase4_adversarial_evaluator.py`
- `outputs/reports/phase4_adversarial_report.md`
- `outputs/tables/phase4_adversarial_summary.csv`

Result:

| target | observed ppm | threshold ppm | empirical p vs observed | random hit rate at threshold |
|---|---:|---:|---:|---:|
| alpha local delta | 0.000148 | 0.01 | 0.163 | 0.980 |
| Kp strict local | 0.531 | 0.50 | 0.989 | 0.985 |
| Kp wide local | 0.0128 | 0.50 | 0.962 | 1.000 |

Interpretation:

The current modular grammar is too dense. It hits random targets with high
frequency, so ppm-level hits are not yet strong evidence. Future formula search
must narrow the grammar before looking at targets.

## Branch B: Physical Finite-Group Program

Artifacts:

- `scripts/phase4_gf137_structure.py`
- `outputs/reports/phase4_gf137_structure_report.md`
- `outputs/reports/e5_137_physical_model_program.md`
- `outputs/tables/phase4_gf137_orders.csv`
- `outputs/tables/phase4_gf137_subgroups.csv`

Key constraint:

`GF(137)^*` is cyclic with order `136`, but `D*N = 26*5 = 130` is not a divisor
of `136`. Therefore, `130 + 6` cannot be a direct subgroup decomposition of the
multiplicative group. A physical model must define a representation, state
space, and operator whose spectrum or rank naturally gives that split.

Interpretation:

The finite-field idea is still usable as a research program, but it needs an
explicit `(G, V, rho, O, M)` mechanism before any formula can be called a
derivation.

## Branch C: Observational Astrophysics

Artifacts:

- `scripts/qso_vac_observable_inventory.py`
- `outputs/reports/qso_vac_observable_inventory.md`
- `outputs/tables/qso_vac_observable_inventory.csv`
- `outputs/reports/qso_highz_forge_density_followup.md`

QSO FastSpecFit inventory:

| observable | usable rows | usable fraction | z=1.5..2.1 | z=2.1..3.5 |
|---|---:|---:|---:|---:|
| CIV_1549_EW / FLUX | 779955 | 0.976 | 422007 | 357948 |
| CIII_1908_EW / FLUX | 776361 | 0.972 | 417597 | 358764 |
| MGII_2796_EW / FLUX | 622832 | 0.780 | 429575 | 193257 |
| LYALPHA_EW / FLUX | 444927 | 0.557 | 81476 | 363451 |

Interpretation:

QSO `DN4000_MODEL` is the wrong population observable for high-z quasars under
the current quality cuts. The next observational population-residual test should
use QSO emission-line observables, with `CIV_1549` and `CIII_1908` first.

## Recommended Next Actions

1. Freeze a narrower symbolic grammar and rerun Branch A.
2. Build a toy representation/operator search for Branch B.
3. Extend `fastspecfit-gradient` or add a QSO-line residual command for Branch C,
   using `CIV_1549_EW`, `CIII_1908_EW`, and IVAR weighting.

## Current Scientific Position

The observational branch remains an active null for the tested density and
DN4000 cells. The theory-number branch is interesting but currently overflexible
under adversarial random-target tests.
