# Look-elsewhere summary

Input: LRG over NGC and SGC using DESI DR1 LSS catalogs, random catalogs 0..9, nside=32, 5000 permutation nulls, 5000 Poisson mocks, 300 bootstrap samples, and 12 jackknife regions.

- Number of tested tracer/region/redshift bins: 6
- Minimum permutation p-value: 0.203559
- Minimum Bonferroni-adjusted p-value: 1
- Minimum BH-FDR adjusted p-value: 0.787443

## Lowest p-value bins

|   test_rank | tracer   | region   | z_bin   |   n_data |   n_random |   amplitude |   ra_deg |   dec_deg |   null_p_value |   bonferroni_p |   bh_fdr_p |   poisson_p_value |   jackknife_axis_max_shift_deg |
|------------:|:---------|:---------|:--------|---------:|-----------:|------------:|---------:|----------:|---------------:|---------------:|-----------:|------------------:|-------------------------------:|
|           1 | LRG      | NGC      | 0.4-0.6 |   346761 |   22210337 |   0.0552216 |   2.71   | -28.9237  |       0.203559 |              1 |   0.787443 |        0.00019996 |                        11.5075 |
|           2 | LRG      | SGC      | 0.8-1.1 |   264403 |   19956471 |   0.052456  | 186.144  |   1.64661 |       0.474305 |              1 |   0.787443 |        0.00059988 |                        27.7551 |
|           3 | LRG      | SGC      | 0.4-0.6 |   160150 |   11783429 |   0.0577945 |  54.3351 |  17.5944  |       0.540492 |              1 |   0.787443 |        0.0039992  |                        19.6748 |
|           4 | LRG      | NGC      | 0.6-0.8 |   533955 |   33933628 |   0.0244573 | 344.195  | -24.8758  |       0.692262 |              1 |   0.787443 |        0.00419916 |                        36.0895 |
|           5 | LRG      | SGC      | 0.6-0.8 |   237939 |   17850617 |   0.0382892 | 101.676  |  71.3771  |       0.75125  |              1 |   0.787443 |        0.0155969  |                        34.3719 |
|           6 | LRG      | NGC      | 0.8-1.1 |   595419 |   37718685 |   0.0182226 | 245.084  | -38.5796  |       0.787443 |              1 |   0.787443 |        0.0309938  |                        43.7867 |

## Interpretation

No directional claim should be made from local p-values without accounting for the
number of tracer, region, redshift, resolution, weight, and split tests that were tried.
Poisson p-values are shot-noise diagnostics only; the permutation p-value is the
first-pass null statistic used for this correction table.
